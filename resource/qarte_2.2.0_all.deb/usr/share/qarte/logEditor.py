# -*- coding: utf-8 -*-

# logEditor.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2012-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Text editor for crontab mails

import os
import sys


from threading import Thread

from PyQt4 import QtCore, QtGui

class LogEditor(QtGui.QPlainTextEdit):
    def __init__(self, ui, parent=None):
        super(LogEditor, self).__init__(parent)
        self.ui = ui
        self.parent = parent
        self.setUndoRedoEnabled(True)
        font = QtGui.QFont()
        font.setFamily("Mono")
        self.setFont(font)
        self.filename = None
        self.is_modified = False
        self.file_size = 0
        self.cursor = QtGui.QTextCursor()
        self.copyAvailable.connect(self.copy_available)
        self.selectionChanged.connect(self.selection_changed)
        self.textChanged.connect(self.text_changed)
        self.modificationChanged.connect(self.state_changed)

    def set_log_filename(self, filename):
        self.filename = filename

    def set_plainText(self, text):
        self.blockSignals(True)
        self.clear()
        self.setPlainText(text)
        self.is_modified = False 
        self.enable_buttons(False)
        self.blockSignals(False)
        self.ui.log_file_lbl.setText(self.filename)
        self.ui.select_txt_btn.setEnabled(len(text))
        self.show_warning(False)

    def text_changed(self):
        if not self.is_modified:
            self.ui.log_file_lbl.setText(u"*" + self.filename)

        self.is_modified = True
        self.ui.save_btn.setEnabled(True)

    def copy_available(self, b):
        self.ui.copy_btn.setEnabled(b)
        self.ui.erase_btn.setEnabled(b)

    def selection_changed(self):
        pass

    def state_changed(self, b):
        pass

    def load_log(self):
        try:
            with open(self.filename, 'r') as logf:
                txt = unicode(logf.read())
        except Exception as why:
            txt = u"Read log error:\n{0}".format(why)
            txt += u"\n\nIf your mailbox isn't '{0}'\n please, define it in"\
                    " the settings dialog box.".format(self.filename)
            self.set_plainText(txt)

        else:
            self.set_plainText(txt)
            self.size_file = self.get_size_file()
            self.set_observer()

    def copy_(self):
        self.copy()

    def select_all(self):
        self.selectAll()
        self.setFocus(True)

    def erase_selected_text(self):
        self.cut()

    def save_log(self):
        txt = unicode(self.toPlainText())
        try:
            with open(self.filename, "w") as f:
                f.write(txt.encode('utf-8', 'ignore'))
        except IOError, why:
            print "Error :", why 

        except UnicodeEncodeError, why:
            print "Error :", why
            return

        self.ui.log_file_lbl.setText(self.filename)
        self.is_modified = False
        self.ui.save_btn.setEnabled(False)
        self.size_file = self.get_size_file()
        self.set_observer()

    def set_observer(self):
        """Run a timer for checking of changes in log file on disk.

        """
        if self.ui.closed:
            return

        timer = QtCore.QTimer()
        timer.singleShot(3000, self.check_size)
        timer.start()

    def check_size(self):
        """Check the log's size on disk.

        """
        if self.size_file != self.get_size_file():
            self.show_warning(True)

        else:
            self.set_observer()

    def get_size_file(self):
        return os.path.getsize(self.filename)

    def show_warning(self, b):
        self.ui.warning_wdg.setVisible(b)

    def enable_buttons(self, b):
        self.ui.copy_btn.setEnabled(b)
        self.ui.erase_btn.setEnabled(b)
        self.ui.save_btn.setEnabled(b)
