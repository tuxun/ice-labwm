#!/usr/bin/env python
# -*- coding: utf-8 -*-

# qarte.py
# Version: 2.2.0
# This file is part of Qarte
#    
# Author: Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2011-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
#
# Qarte is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Qarte is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Qarte.  If not, see <http://www.gnu.org/licenses/>.
#
# arte TV recorder

import os
import sys
import pickle
import time
import logging
import platform
import locale
# To avoid a 'RuntimeWarning: PyOS_InputHook ...' pynotify must be 
# imported here
try:
    import pynotify
    NOTIFY = True
except:
    NOTIFY = False
import gettext
LOC_PATH = '/usr/share/locale'
gettext.install('qarte', LOC_PATH, True)
import logging
logger = logging.getLogger(__name__)

from threading import Thread, current_thread
from threading import enumerate as enumerate_

from PyQt4 import QtCore, QtGui

import data

from utils import Utils
from ui_main import Ui_MainWindow
from artePlus import ArtePlus
from arteLiveWeb import ArteLiveWeb
from arteLiveExtra import ArteLiveExtra
from ui_config import Settings
from differedTask import DifferedTask

VERSION = data.VERSION
VERSION_STR = data.VERSION_STR

class Qarte(object):
    def __init__(self):
        """Instanciate main class of Qarte

        Args:
        No arguments required
        """
        self.utils = Utils()
        paths = self.utils.get_common_paths()
        self.user_fld = paths[0]
        self.config_file = paths[1]
        self.prev_fld = paths[2]
        self.thumb_fld = paths[3]
        self.old_list = paths[4]
        self.is_interact_with_dialog = False
        self.all_is_parsed = 0
        
        if not os.path.isdir(self.user_fld):
            try:
                os.mkdir(self.user_fld)
            except Exception as why:
                self.show_warning(1, why)
                sys.exit()

        if not os.path.isdir(self.thumb_fld):
            os.mkdir(self.thumb_fld)

        if not os.path.isdir(self.prev_fld):
            os.mkdir(self.prev_fld)
        
        # Set config parameters
        self.cfg = self.utils.get_user_config()

        self.stop = False
        self.is_loading = False
        self.abort_download = False
        self.index = None
        sizes = self.cfg["size"]

        logger.info(u"Main thread: {0}".format(current_thread()))
        
        # Set ui
        MainWindow = QtGui.QMainWindow()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(MainWindow, self)

        MainWindow.closeEvent = self.close_event
        MainWindow.resize(sizes[0], sizes[1])

        self.ui.preview.setIconSize(QtCore.QSize(self.cfg["thumb1"], 
                                    self.cfg["thumb1"]))
        self.ui.basket_plus.setIconSize(QtCore.QSize(self.cfg["thumb2"], 
                                    self.cfg["thumb2"]))
        self.ui.sizer_wdg.set_value(self.cfg["thumb1"])
        self.save_config()
        QtCore.QCoreApplication.processEvents()

        self.ui.filter_led.commandTriggered.connect(self.set_filter)
        #self.ui.filter_led.editingFinished.connect(self.set_filter)
        self.ui.showall_btn.clicked.connect(self.remove_filter)
        self.ui.sizer_wdg.valueChanged.connect(self.resize_thumbnails)

        self.utils.update_data()

        self.apl = ArtePlus(self)
        self.alw = ArteLiveWeb(self)
        self.aex = ArteLiveExtra(self)

        self.alw.urls_fr = self.utils.urls_fr
        self.alw.urls_de = self.utils.urls_de

        f = False
        f = os.path.isdir(self.cfg["plus_folder"])
        f = os.path.isdir(self.cfg["live_folder"])
        if not f:
            # First usage of Qarte
            self.edit_settings()

        # Pages to load at startup
        pages = self.cfg['load_pages']
        if pages[0]:
            # Load arte+7
            self.apl.get_arte_page()

        if pages[1]:
            # Load arteLiveWeb
            self.alw.get_live_page()

            if not pages[0]:
                # Show live page
                self.all_is_parsed += 1
                self.ui.live_state_btn.click()
                self.ui.live_state_btn.setChecked(True)

        else:
            self.all_is_parsed += 1

    def reload_artePlus(self):
        """Reset the connection to arte+7.

        """ 
        self.ui.preview.clear()
        self.apl.get_arte_page()

    def reload_arteLive(self):
        """Reset the connection to arteLiveWeb.

        """
        self.alw.get_live_page()

    def reload_extras(self):
        """Reset the connection to arteLiveWeb partner's page.

        """
        self.aex.get_pages()

    def download_plus(self):
        """Call downloading function for arte+7.

        """
        self.apl.download()

    def download_live(self):
        """Call downloading function for arteLiveWeb.

        """
        self.alw.fetch_video()

    def download_extra(self):
        """Call downloading function for arteLiveWeb extra.

        """
        self.aex.fetch_video()    

    def cancel_plus(self):
        """Call cancel downloading function for arte+7.

        """
        self.apl.cancel()

    def cancel_live(self):
        """Call cancel downloading function for arteLiveWeb.

        """
        self.alw.abort_loading()

    def cancel_extra(self):
        """Call cancel downloading function for arteLiveWeb extra.

        """
        self.aex.abort_loading()

    def on_custom_clicked(self):
        """Search for personnal link video.

        """
        self.aex.get_personal_link()

    def edit_settings(self):
        """Call setting dialogbox."""
        logger.info(u"Call setting dialogbox")
        self.sizes = (self.cfg['thumb1'], self.cfg['mini'])
        Dialog = QtGui.QDialog()
        sett = Settings()
        sett.setupUi(Dialog, self)
        reply = Dialog.exec_()
        self.update_config()

    def set_differed_tasks(self, item=None):
        """Call differed task dialog.

        Args:
        item -- item video, when called from contextual menu on a video
        """
        logger.info(u"Call crontab settings dialogbox")
        self.dtk = DifferedTask(self, item)

    def send_item_to_download_later(self, item):
        if not self.dtk:
            raise "deffered task dialog doesn't exists"
            return

        self.is_interact_with_dialog = False
        self.dtk.select_item(item)

    def update_config(self):
        """Update user's preferences"""
        self.apl.lang = self.alw.lang = self.cfg['lang']
        if self.cfg['thumb1'] != self.sizes[0]:
            self.ui.preview.setIconSize(QtCore.QSize(self.cfg["thumb1"], 
                                    self.cfg["thumb1"]))

        self.alw.dwlnd_fld = self.cfg['live_folder']
        self.save_config()

    def resize_thumbnails(self, size):
        if self.cfg['thumb1'] != size:
            self.ui.preview.setIconSize(QtCore.QSize(size, size))
            self.cfg['thumb1'] = size

    def check_parsing(self):
        self.all_is_parsed += 1
        if self.all_is_parsed == 2:
            self.ui.set_busy_cursor(False)
            if self.cfg['load_pages'][2]:
                self.aex.get_pages()

    def set_filter(self, key=None):
        if key is None:
            key = self.ui.filter_led.text()

        keys = [k.lower() for k in unicode(key).split(' ')]
        selected = []
        for v in self.apl.all_videos:
            title = v.title.lower()
            for k in keys:
                if k in title:
                    selected.append(v)
                    break

        if selected:
            self.ui.filter_led.blockSignals(True)
            self.ui.filter_led.setText('')
            self.ui.editor_plus.setFocus(True)
            self.ui.filter_led.blockSignals(False)
            self.apl.display_videos(selected, False)
            self.ui.showall_btn.setEnabled(True)

        self.update_filter_label(len(selected))

    def remove_filter(self):
        self.update_filter_label()
        self.ui.showall_btn.setEnabled(False)
        self.ui.filter_led.blockSignals(True)
        self.ui.filter_led.setText('')
        self.ui.filter_led.blockSignals(False)
        self.apl.display_videos(None, False)

    def update_filter_label(self, num=None):
        if num is None:
            text = ''
        elif num == 0:
            text = u'No such videos'
        elif num == 1:
            text = u'One video found'
        else:
            text = u'{0} videos found'.format(str(num))
        self.ui.result_lbl.setText(text)

    def show_warning(self, warn, msg=None):
        """Show a warning dialog box.

        Args:
        warn -- index of warning
        msg -- message, context, ...
        """
        obj = QtCore.QObject()
        mssg = QtGui.QMessageBox()
        # Warnings
        mssg.setWindowTitle('Qarte')
        mssg.setIcon(QtGui.QMessageBox.Warning)
        mssg.resize(600, 200)
        def close_warning(*args):
            time.sleep(4)
            try:
                mssg.reject()
            except Exception as why:
                logger.warning('close warning: %s' % why)

        if warn == 1:
            mssg.setText(_("Qarte is unable to create the folder\n'{0}.'"
                        .format(self.user_fld)))
            mssg.setInformativeText(_("Reason:\n{0}".format(msg)))

        elif warn == 2:
            mssg.setText(_("Qarte is unable to save config file."))
            mssg.setInformativeText(_("Reason:\n{0}".format(msg)))

        elif warn == 3:
            mssg.setText(_("Parsing arte+7 has failed\n in stage '{0}.'"
                        .format(msg[1])))
            mssg.setInformativeText(_("Reason:\n{0}".format(msg[2])))

        elif warn == 4:
            mssg.setText(_("Qarte is unable to save the summary."))
            mssg.setInformativeText(_("Reason:\n{0}".format(msg)))

        elif warn == 5:
            mssg.setText(_("Unable to find the stream's URL."))
            mssg.setInformativeText(_("Reason:\n{0}".format(msg)))

        elif warn == 6:
            mssg.setText(_("The video {0} is no longer available."
                        .format(msg)))

        elif warn == 7:
            mssg.setText(_("Parsing arteLiveWeb has failed\n"))
            mssg.setInformativeText(_("Reason:\n{0}".format(msg)))

        elif warn == 8:
            mssg.setText(_("Unable to save tasks file\n{0}".format(msg[0])))
            mssg.setInformativeText(_("Reason:\n{0}".format(msg[1])))

        elif warn == 9:
            mssg.setText(_("Unable to save list of arteLiveWeb movies"))
            mssg.setInformativeText(_("Reason:\n{0}".format(msg)))

        elif warn == 10:
            mssg.setText(_("Qarte is unable to create the folder\n'{0}.'"
                        .format(msg[0])))
            mssg.setInformativeText(_("Reason:\n{0}".format(msg[1])))

        elif warn == 11:
            mssg.setText(_("This video can only be viewed between 23:00 and 05:00"))
            mssg.setInformativeText(msg)

        elif warn == 12:
            mssg.setText(_("No reply from rtmp://artestras, retry later."))
            Thread(target=close_warning, args=(None,)).start()

        mssg.exec_()

    def save_config(self):
        try:
            with open(self.config_file, "w") as objf:
                pickle.dump(self.cfg, objf)
        except Exception, why:
            self.show_warning(2, why)

    def close_event(self, event=None):
        """Quiet exit. """
        print u"\nExit Qarte, Check downloading... ",
        if self.apl.is_loading or self.alw.is_loading:
            mssg = QtGui.QMessageBox()
            mssg.setIcon(QtGui.QMessageBox.Question)
            mssg.setText(_("Download is not complete."))
            mssg.setInformativeText(_("Do you want to stop the loading  ?"))
            can = QtGui.QPushButton(_("Cancel"))
            mssg.addButton(can, QtGui.QMessageBox.ActionRole)
            qut = QtGui.QPushButton(_("Quit"))
            mssg.addButton(qut, QtGui.QMessageBox.ActionRole)
            mssg.setDefaultButton(can)
            reply = mssg.exec_()

            if reply == 0:
                if event:
                    event.ignore()
                    return

            self.cancel_plus()
            self.cancel_live()
            time.sleep(1)

        print u"\tOK\n  close updating thread... ",
        try:
            while self.apl.pprs.is_updating:
                self.apl.pprs.close_app = True
                time.sleep(0.5)
        except AttributeError:
            # Arte+7 not loaded in user's pref
            pass

        print "\tOK\n  Save config file...",
        self.save_config()
        QtCore.QCoreApplication.processEvents()
        time.sleep(0.1)
        print "OK\n  ...Quiet close."
        sys.exit()

    def _print_config(self):
        """Debug function"""
        for k, v in self.cfg.iteritems():
            print k, v

def print_infos():
    PY_VERSION = sys.version.split()[0]
    PLATFORM = platform.platform()
    logger.info(u"Qarte-{0}".format(data.VERSION_STR))
    logger.info(u"Python {0} on {1}".format(PY_VERSION, PLATFORM))
    logger.info(u"File system encoding: {0}".format(sys.getfilesystemencoding()))
    logger.info(u"System encoding: {0}".format(sys.getdefaultencoding()))
    logger.info(u"Locale encoding: {0}".format(locale.getdefaultlocale()))

            
if __name__ == "__main__":
    LOG_FORMAT = "%(asctime)-6s: %(levelname)s - %(name)s %(message)s"
    logging.basicConfig(format=LOG_FORMAT, level=logging.DEBUG, datefmt='%H:%M:%S')
    print_infos()
    logger = logging.getLogger(__name__)

    if len(sys.argv) > 1:
        args = sys.argv[1:]

        if args[0] == '-a':
            qarte = CronJobs(task=args[1])
            reply = qarte.read_task()
            sys.exit()

    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    app = QtGui.QApplication(sys.argv)

    qarte = Qarte()
    sys.exit(app.exec_())
