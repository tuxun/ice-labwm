# -*- coding: utf-8 -*-

# daemon.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2011-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Download scheduled with crontab
#
# Warning gtk in mail, see:
# http://bugs.debian.org/cgi-bin/bugreport.cgi?bug=601052

import sys
import os
import subprocess
import time
import pwd
import pickle
import platform
import locale

import data

from loaders import PlusLoader, LiveLoader
from parsers import ArteTVParser
from crontab.crontab import CronTab
from differedTask import TaskEditor, TaskObject
from utils import Utils

QUALITIES = [u'RTMP_EQ_1', u'RTMP_MQ_1', u'RTMP_SQ_1', u'RTMP_LQ_1']

class Daemon(object):
    def __init__(self, task):
        self.utils = Utils()
        self.task_id = task
        paths = self.utils.get_common_paths()
        self.user_fld = paths[0]
        self.config_file = paths[1]
        self.prev_fld = paths[2]
        self.thumb_fld = paths[3]
        self.old_list = paths[4]
        self.root = self.utils.root
        self.tasks_file = os.path.join(self.user_fld, "difTasksList")
        self.cfg = self.utils.get_user_config()
        self.lang = self.cfg['lang']
        self.single_load = True
        self.videos = []
        self.pprs = ArteTVParser(self, self.lang, self.videos)
        self.parsed = False
        self.load_tasks()
        self.print_(u"File system encoding: {0}"
                                        .format(sys.getfilesystemencoding()))
        self.print_(u"System encoding: {0}".format(sys.getdefaultencoding()))
        self.print_(u"Locale encoding: {0}".format(locale.getdefaultlocale()))

    def read_task(self):
        """Get the current task.

        """
        t = None
        for idx, task in enumerate(self.tasks):
            if str(task['ID']) == self.task_id:
                t = task
                break

        if t is not None:
            self.prepare_task(self.tasks.pop(idx))

        else:
            self.print_("Task {0} not found, exit.".format(self.task_id))

    def prepare_task(self, task):
        """Get the type of task.

        Args:
        task -- current task
        """
        self.print_('Begin differed downloading, read tasks:%s, site: %s' % 
                                                (task['type'], task['site']))
        self.task = task
        movies = None

        if task['type'] == 0:
            self.print_('Found task type 0')
            # Grouped tasks, not yet implemented
            pass

        elif task['type'] == 1:
            self.print_('Found task type 1')
            # Stream link provided
            if not task['filename']:
                task['filename'] = self.get_filename(task)

            if self.task['site'] == 'plus':
                url = self.set_stream_url(task)
                self.print_('url: %s' % url)
                if url:
                    task['stream'] = url

                else:
                    self.print_('Stream url not found, closing task.')
                    return
            self.download_movie()

        elif task['type'] == 2:
            self.print_('Found task type 2, seek for movies in "{0}"'
                                            .format(task['serial']))
            # Serial name provided, need to seek for movie
            movies = self.find_movies(task)
            if not movies:
                self.print_('No movies found, closing task')
                return

        elif task['type'] == 3:
            self.print_('Found task type 3, search for movies with keywords')
            # Search with keywords
            movies = self.seek_for_name(task)
            if not movies:
                self.print_('No movies found, closing task')
                return

        elif task['type'] == 4:
            self.print_('Found task type 4, search for movies with keywords')
            # Search with keywords + date
            movies = self.seek_for_name(task)
            if not movies:
                self.print_('No movies found, closing task')
                return

            found = False
            self.print_('Found {0} movies, check for date: {1}'.format(len(movies), 
                        task['moviedate']))
            if len(movies) == 1:
                found = movies[0]

            else:
                for movie in movies:
                    if movie.date == task['moviedate']:
                        found = movie
                        break

            if not found:
                self.print_('No movies found, close task')
                return

            movies = [found]

                
        self.single_load = task['single']
        if movies is not None:
            self.movies = movies
            while len(self.movies):
                self.next_movie()

    def download_movie(self):
        """Select the right downloader.

        """
        self.stop = False
        self.is_loading = True
        self.abort_download = False
        
        if self.task['site'] == 'plus':
            self.get_plus_summary()
            self.fetch_plus_movie(self.task)

        else:
            self.get_live_summary()
            self.fetch_live_movie(self.task)

    def fetch_plus_movie(self, task):
        """Download an arte+7 movie.

        Args:
        task -- task instance
        """
        self.print_('download arte+7 movie {0}'.format(task['filename']))
        tmp = self.get_temp_filename()
        tmp = os.path.join(self.cfg['plus_folder'], tmp)
        self.fname = os.path.join(self.cfg['plus_folder'], task['filename'])
        ldr = PlusLoader(self)
        ldr.is_daemon = True
        ldr.loadingFailed.connect(self.on_loading_failed)
        ldr.loadingComplete.connect(self.on_loading_complete)
        ldr.set_url(task['stream'].split('mp4:'))
        ldr.set_destination(self.fname)
        ldr.set_target(tmp)
        ldr.load()

    def fetch_live_movie(self, task):
        """Download an arteLiveWeb movie.

        Args:
        task -- task instance
        """
        tmp = self.get_temp_filename()
        tmp = os.path.join(self.cfg['live_folder'], tmp)
        self.fname = os.path.join(self.cfg['live_folder'], task['filename'] +
                                    '.flv')
        self.is_loading = True
        ldr = LiveLoader(self)
        ldr.is_daemon = True
        ldr.loadComplete.connect(self.on_live_loading_complete)
        ldr.set_url(task['stream'])
        ldr.set_destination(self.fname)
        ldr.set_target(tmp)
        ldr.load()

    def next_movie(self):
        """Prepare the next download.

        """
        if not len(self.movies):
            return

        movie = self.movies.pop(0)
        name = self.clean_filename(movie.title)
        self.task['filename'] = "".join([name, '-', movie.date, '.flv'])
        self.print_('Next movie: %s' % name)

        try:
            self.task['link'] = movie.link
        except KeyError:
            self.print_("Movie don't have a valid link, next movie.")
            return

        # Keyword task don't have key 'streams'
        if 'streams' not in self.task:
            self.task['streams'] = None

        if self.task['site'] == 'plus':
            url = self.set_stream_url(self.task)
            if not url:
                return

            self.task['stream'] = url

        self.get_pitch(movie)
        self.download_movie()

    def set_stream_url(self, movie):
        if not isinstance(movie['streams'], dict):
            urls = self.get_stream_link(movie)
            if urls is None:
                self.print_("Unable to find stream link!")
                return False

            movie['streams'] = urls

        if movie['stream'] not in QUALITIES:
            movie['stream'] = u'RTMP_EQ_1'

        try:
            # Subtitles, new key in vers. 1.8.1
            if movie['subtitles']:
                st = movie['stream'].replace('1', '8')
                if st in movie['streams']:
                    movie['stream'] = st
        except:
            pass

        frmt = movie['streams'][movie['stream']]
        rtmp = frmt[u'streamer']
        url = frmt[u'url']
        stream = ''.join([rtmp, 'mp4:', url])
        return stream

    def get_stream_link(self, movie):
        """Return the stream url.

        Args:
        movie -- the movie object
        """
        lnk = movie['link']
        self.print_("get_stream_link: {0}".format(lnk))
        try:
            streams = self.pprs.get_stream_urls(lnk)
        except Exception as exc:
            self.print_("Unable to find stream link!\n  {0}".format(exc)) 
            return

        if streams  == 'restricted':
            self.print_("This video is restricted from 23 h to 05 h.")
            return 

        qualities = [u'RTMP_MQ_1', u'RTMP_EQ_1', u'RTMP_SQ_1', u'RTMP_LQ_1']
        strs = self.parse_streams(streams)

        if movie['stream'] not in strs:
            # Set the quality from the user config, if exist
            qlt = self.cfg['quality']
            if qlt is not None and qlt in streams:
                movie['stream'] = streams[qlt]

            else:
                # Choose the format into medium, medium+, hight and low qualities
                for k in qualities:
                    if k in streams:
                        movie['stream'] = streams[k]
                        break

        return streams

    def parse_streams(self, streams):
        for k in streams.keys():
            # Streams wich ends with '2' are german version in french page
            # or french version in german page
            if not 'RTMP' in k or k.endswith('2'):
                del streams[k]

        return streams

    def find_movies(self, task):
        """Search for amovie with his title.

        Args:
        task -- task instance
        """
        if not self.parsed:
            self.get_movies()

        if not len(self.videos):
            return

        movies = []
        for video in self.videos:
            if video.title == task['serial']:
                movies.append(video)

                if task['single']:
                    break

        return movies

    def seek_for_name(self, task):
        """Search for amovie with keywords.

        Args:
        task -- task instance
        """
        self.print_('Keywords: "{0}"'.format(task['keyword']))

        if not self.parsed:
            self.get_movies()

        if not len(self.videos):
            return

        movies = []
        for video in self.videos:
            title = video.title.lower()
            movies.append(video)

            for word in task['keyword'].split():
                if word.lower() not in title:
                    movies.pop(-1)
                    break

        return movies

    def get_movies(self):
        """Get the movies available in arte+7.

        """
        parsed = self.pprs.parse()

    def on_loading_failed(self, err, why):
        self.print_('Loading failure: {0} {1}'.format(err, why))
        if self.task['retry']:
            # value for 'retry' is always 5, new in version 1.6.0
            delay, nb = self.task['retry']
            if nb > 5:
                return

            self.task['retry'] = delay, nb + 1
            h, m = self.task['time']
            hour, mn = divmod((h * 60) + m + delay, 60)
            self.task['time'] = [hour, mn]

            if hour > 23:
                hour -= 24
                self.task['date'][0] += 1

            self.set_new_cron()

    def on_loading_complete(self):
        self.print_('Loading complete: {0}'.format(self.fname))
        self.write_summary()
        if not self.single_load:
            self.next_movie()

    def on_live_loading_complete(self, error):
        if not error:
            self.is_loading = False
            self.write_summary()

        else:
            if not self.is_loading:
                # Avoid remanant signal
                return

            self.print_('Loading {0} failed!'.format(self.fname))
            self.print_('Reason: {0}'.format(error))
            self.is_loading = False

        if not self.single_load:
            self.next_movie()

    def get_temp_filename(self):
        """Return a temp file name build with time.time().

        """
        d = str(time.time()).replace(".", "")
        return u"".join([u"plus", d])

    def get_filename(self, task):
        """Create file name for download.

        Args:
        task -- task instance
        """
        date = video.date.replace(' ', '_').replace(',', '')
        for video in self.videos:
            self.print_("Video name: {0}".format(task['movie']))
            if video.title == task['movie']:
                n = self.clean_filename(video.title)
                break

        return "".join([n, "-", date, u'.flv'])

    def clean_filename(self, name):
        """Replace illicite symbols in file name.

        Args:
        name -- file name
        """
        for c in [u'»', u'«', u'/', u'\\', u'"']:
            name = name.replace(c, "_")

        return name

    def get_pitch(self, mov):
        if self.task['pitch']:
            return

        if not mov.summary or mov.summary is none:
            try:
                pitch, desc, mov.orig = self.pprs.fetch_summary(mov.link)
            except:
                mov.summary = "No informations"
                mov.orig = ""
            else:
                if desc:
                    mov.summary = desc
                else:
                    mov.summary = pitch
        self.print_('title: %s, orig: %s, date: %s, summ: %s' %(mov.title, mov.orig, mov.date, mov.summary))
        self.task['pitch'] = u"".join([mov.title, "  ", mov.orig, "\n",
                            mov.date, "\n\n", mov.summary])

    def load_tasks(self):
        """Load tasks list.

        """
        try:
            with open(self.tasks_file, 'r') as tskf:
                self.tasks = pickle.load(tskf)
        except Exception as why:
            self.print_(u"Error: unable to read {0}\n"
                        "Reason: {1}\nExit"
                        .format(self.tasks_file, why))
            sys.exit()

    def get_plus_summary(self):
        if not self.cfg['pitch_plus']:
            self.task['save_pitch'] = False
            return

        self.task['save_pitch'] = 1 + self.cfg['pitch_plus_unique']

    def get_live_summary(self):
        if not self.cfg['pitch_live']:
            self.task['save_pitch'] = False
            return

        self.task['save_pitch'] = 1 + self.cfg['pitch_live_unique']

    def write_summary(self):
        """Write the summary of video downloaded on disk.

        """
        if not self.task['save_pitch'] or not self.task['pitch']:
            return

        if self.task['save_pitch'] == 1:
            filename = self.fname.replace(".flv", "")

        else:
            if self.task['site'] == 'plus':
                filename = os.path.join(self.cfg['plus_folder'], 'index')

            else:
                filename = os.path.join(self.cfg['live_folder'], 'index')

        try:
            summ = u"".join([self.task['pitch'], u"\n\n"])
            with open(filename, 'a') as objf:
                objf.write(summ.encode('utf-8', 'replace'))

        except Exception as why:
            self.print_(u"Unable to write summary, reason: {0}".format(why))

        else:
            self.print_(u"Summary saved: {0}".format(filename))

    def save_tasks(self):
        """Save remaining tasks list.

        """
        try:
            with open(self.tasks_file, 'w') as tskf:
                pickle.dump(self.tasks, tskf)
        except Exception as why:
            txt = u"Task: {0}\n".format(self.task_id)
            txt += u"Report: Qarte has encounter an error in reading "\
                                                        "tasks file\n"
            txt += u"\t<{0}>".format(why)
            self.print_(txt) 
            sys.exit()

    def set_new_cron(self):
        """Created a new crontab for the current task.

        This called when the download has failed.
        """
        job = TaskObject(self.task['ID'], self.task)
        tsked = TaskEditor(self)
        tsked.cmd = job.command
        tsked.make_cron_job(job)
        self.tasks.append(self.task)
        self.print_("Task reported: {0} min.".format(self.task['retry'][0]))
        self.save_tasks()

    def print_(self, msg):
        print u"{0}  {1}".format(time.time(), msg)

    def print_task_param(self, tsk):
        """Debugging function"""
        for key, value in tsk.iteritems():
            print "%s: %s" % (key, value)

    def get_formated_time(self):
        return time.strftime('%a, %d %b %Y %H:%M:%S', time.localtime())
                
                
        
