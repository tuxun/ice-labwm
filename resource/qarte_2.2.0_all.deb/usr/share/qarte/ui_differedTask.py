# -*- coding: utf-8 -*-

# ui_differedTask.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2012-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte+7
#
# Crontab maker gui

from datetime import datetime, timedelta
import gettext

from PyQt4 import QtCore, QtGui

from logEditor import LogEditor
from themes import Themes

DAYS_FR = [u'Dimanche', u'Lundi', u'Mardi', u'Mercredi', u'Jeudi',
                    u'Vendredi', u'Samedi', u'Tous les jours']
DAYS_DE = [u'Sonntag', u'Montag', u'Dienstag', u'Mittwoch',
                    u'Donnerstag', u'Freitag', u'Samstag',
                    u'Alle Tage']
QUALITIES = [u'RTMP_EQ_1', u'RTMP_MQ_1', u'RTMP_SQ_1', u'RTMP_LQ_1']

class Ui_DifferedTaskDialog(object):
    def setupUi(self, dtk, DifferedTaskDialog):
        self.dtk = dtk
        DifferedTaskDialog.setObjectName("DifferedTaskDialog")
        DifferedTaskDialog.resize(600, 550)
        DifferedTaskDialog.setModal(False)
        DifferedTaskDialog.setSizeGripEnabled(True)
        self.gridLayout_3 = QtGui.QGridLayout(DifferedTaskDialog)
        self.gridLayout_3.setContentsMargins(2, 0, 2, 0)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.verticalLayout_7 = QtGui.QVBoxLayout()
        self.verticalLayout_7.setObjectName("verticalLayout_7")
        self.groupBox = QtGui.QGroupBox(DifferedTaskDialog)
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setWeight(75)
        font.setBold(True)
        self.groupBox.setFont(font)
        self.groupBox.setObjectName("groupBox")
        self.verticalLayout_6 = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout_6.setContentsMargins(2, 4, 2, 0)
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.verticalLayout_5 = QtGui.QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.plus_rdo = QtGui.QRadioButton(self.groupBox)
        self.plus_rdo.setFont(font)
        self.plus_rdo.setChecked(True)
        self.plus_rdo.setObjectName("plus_rdo")
        self.sites_grp = QtGui.QButtonGroup(DifferedTaskDialog)
        self.sites_grp.setObjectName("sites_grp")
        self.sites_grp.addButton(self.plus_rdo)
        self.horizontalLayout_4.addWidget(self.plus_rdo)
        self.live_rdo = QtGui.QRadioButton(self.groupBox)
        self.live_rdo.setFont(font)
        self.live_rdo.setObjectName("live_rdo")
        self.sites_grp.addButton(self.live_rdo)
        self.horizontalLayout_4.addWidget(self.live_rdo)
        spacerItem = QtGui.QSpacerItem(258, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem)
        self.verticalLayout_5.addLayout(self.horizontalLayout_4)
        self.horizontalLayout_5 = QtGui.QHBoxLayout()
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        font_1 = QtGui.QFont()
        font_1.setPointSize(10)
        font_1.setWeight(50)
        font_1.setBold(False)
        self.movie_rdo = QtGui.QRadioButton(self.groupBox)
        self.movie_rdo.setFont(font_1)
        self.movie_rdo.setChecked(True)
        self.movie_rdo.setObjectName("movie_rdo")
        self.name_grp = QtGui.QButtonGroup(DifferedTaskDialog)
        self.name_grp.setObjectName("name_grp")
        self.name_grp.addButton(self.movie_rdo)
        self.horizontalLayout_5.addWidget(self.movie_rdo)
        self.mov_name_led = QtGui.QLineEdit(self.groupBox)
        self.mov_name_led.setMinimumSize(QtCore.QSize(200, 0))
        self.mov_name_led.setFont(font_1)
        self.mov_name_led.setMaximumSize(QtCore.QSize(600, 25))
        self.mov_name_led.setObjectName("mov_name_led")
        self.horizontalLayout_5.addWidget(self.mov_name_led)
        self.select_btn = QtGui.QPushButton(self.groupBox)
        self.select_btn.setFont(font_1)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("medias/picker.png"), 
                                    QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.select_btn.setIcon(icon)
        self.select_btn.setMaximumSize(QtCore.QSize(25, 25))
        self.select_btn.setObjectName("select_btn")
        self.horizontalLayout_5.addWidget(self.select_btn)
        self.verticalLayout_5.addLayout(self.horizontalLayout_5)
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.serial_rdo = QtGui.QRadioButton(self.groupBox)
        self.serial_rdo.setFont(font_1)
        self.serial_rdo.setObjectName("serial_rdo")
        self.name_grp.addButton(self.serial_rdo)
        self.gridLayout.addWidget(self.serial_rdo, 0, 0, 1, 1)
        self.serial_cmb = QtGui.QComboBox(self.groupBox)
        self.serial_cmb.setMinimumSize(QtCore.QSize(200, 0))
        self.serial_cmb.setFont(font_1)
        self.serial_cmb.setEnabled(False)
        self.serial_cmb.setObjectName("serial_cmb")
        self.gridLayout.addWidget(self.serial_cmb, 0, 1, 1, 1)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                    QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem3, 0, 2, 1, 1)
        self.kword_rdo = QtGui.QRadioButton(self.groupBox)
        self.kword_rdo.setFont(font_1)
        self.kword_rdo.setObjectName("kword_rdo")
        self.name_grp.addButton(self.kword_rdo)
        self.gridLayout.addWidget(self.kword_rdo, 1, 0, 1, 1)
        self.kword_led = QtGui.QLineEdit(self.groupBox)
        self.kword_led.setFont(font_1)
        self.kword_led.setEnabled(False)
        self.kword_led.setMaximumSize(QtCore.QSize(300, 25))
        self.kword_led.setObjectName("kword_led")
        self.gridLayout.addWidget(self.kword_led, 1, 1, 2, 1)
        spacerItem4 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                    QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem4, 1, 2, 1, 1)
        self.verticalLayout_5.addLayout(self.gridLayout)
        self.horizontalLayout_7 = QtGui.QHBoxLayout()
        self.horizontalLayout_7.setObjectName("horizontalLayout_7")
        spacerItem5 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Fixed, 
                                    QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_7.addItem(spacerItem5)
        self.all_rdo = QtGui.QRadioButton(self.groupBox)
        self.all_rdo.setFont(font_1)
        self.all_rdo.setObjectName("all_rdo")
        self.release_grp = QtGui.QButtonGroup(DifferedTaskDialog)
        self.release_grp.setObjectName("release_grp")
        self.release_grp.addButton(self.all_rdo)
        self.horizontalLayout_7.addWidget(self.all_rdo)
        self.recent_rdo = QtGui.QRadioButton(self.groupBox)
        self.recent_rdo.setFont(font_1)
        self.recent_rdo.setChecked(True)
        self.recent_rdo.setObjectName("recent_rdo")
        self.release_grp.addButton(self.recent_rdo)
        self.horizontalLayout_7.addWidget(self.recent_rdo)
        self.verticalLayout_5.addLayout(self.horizontalLayout_7)
        self.gridLayout_2 = QtGui.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.day_rdo = QtGui.QRadioButton(self.groupBox)
        self.day_rdo.setFont(font_1)
        self.day_rdo.setChecked(True)
        self.day_rdo.setObjectName("day_rdo")
        self.day_grp = QtGui.QButtonGroup(DifferedTaskDialog)
        self.day_grp.setObjectName("day_grp")
        self.day_grp.addButton(self.day_rdo)
        self.gridLayout_2.addWidget(self.day_rdo, 0, 0, 1, 1)
        self.date_spb = QtGui.QDateEdit(self.groupBox)
        self.date_spb.setFont(font_1)
        self.date_spb.setMinimumDate(QtCore.QDate(2012, 3, 1))
        self.date_spb.setCalendarPopup(True)
        self.date_spb.setObjectName("date_spb")
        self.gridLayout_2.addWidget(self.date_spb, 0, 1, 1, 1)
        self.time_spb = QtGui.QTimeEdit(self.groupBox)
        self.time_spb.setFont(font_1)
        self.time_spb.setObjectName("time_spb")
        self.gridLayout_2.addWidget(self.time_spb, 0, 2, 1, 1)
        spacerItem6 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem6, 0, 3, 1, 1)
        self.week_rdo = QtGui.QRadioButton(self.groupBox)
        self.week_rdo.setFont(font_1)
        self.week_rdo.setObjectName("week_rdo")
        self.day_grp.addButton(self.week_rdo)
        self.gridLayout_2.addWidget(self.week_rdo, 1, 0, 1, 1)
        self.week_cmb = QtGui.QComboBox(self.groupBox)
        self.week_cmb.setMinimumSize(QtCore.QSize(150, 25))
        self.week_cmb.setEnabled(False)
        self.week_cmb.setFont(font_1)
        self.week_cmb.setObjectName("week_cmb")
        self.gridLayout_2.addWidget(self.week_cmb, 1, 1, 1, 1)
        self.time_spb_2 = QtGui.QTimeEdit(self.groupBox)
        self.time_spb_2.setFont(font_1)
        self.time_spb_2.setEnabled(False)
        self.time_spb_2.setObjectName("time_spb_2")
        self.gridLayout_2.addWidget(self.time_spb_2, 1, 2, 1, 1)
        spacerItem7 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem7, 1, 3, 1, 1)
        self.verticalLayout_5.addLayout(self.gridLayout_2)
        self.qualityLayout = QtGui.QHBoxLayout()
        self.quality_lbl = QtGui.QLabel(self.groupBox)
        self.qualityLayout.addWidget(self.quality_lbl)
        self.quality_cmb = QtGui.QComboBox(self.groupBox)
        self.qualityLayout.addWidget(self.quality_cmb)
        spacerItem8 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.qualityLayout.addItem(spacerItem8)
        self.verticalLayout_5.addLayout(self.qualityLayout)
        self.horizontalLayout_9 = QtGui.QHBoxLayout()
        self.horizontalLayout_9.setObjectName("horizontalLayout_9")
        self.create_btn = QtGui.QPushButton(self.groupBox)
        self.create_btn.setFont(font_1)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("medias/spindown.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.create_btn.setIcon(icon2)
        self.create_btn.setObjectName("create_btn")
        self.horizontalLayout_9.addWidget(self.create_btn)
        self.warn_lbl = QtGui.QLabel(self.groupBox)
        self.warn_lbl.setFont(font_1)
        self.warn_lbl.setObjectName("warn_lbl")
        self.horizontalLayout_9.addWidget(self.warn_lbl)
        self.ok_warn_btn = QtGui.QToolButton(self.groupBox)
        self.ok_warn_btn.setFont(font_1)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("medias/scroll_spindown.png"), 
                                    QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.ok_warn_btn.setIcon(icon1)
        self.ok_warn_btn.setObjectName("ok_warn_btn")
        self.horizontalLayout_9.addWidget(self.ok_warn_btn)
        spacerItem9 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_9.addItem(spacerItem9)
        self.verticalLayout_5.addLayout(self.horizontalLayout_9)
        self.verticalLayout_6.addLayout(self.verticalLayout_5)
        self.verticalLayout_7.addWidget(self.groupBox)
        self.toolBox = QtGui.QToolBox(DifferedTaskDialog)
        self.toolBox.setObjectName("toolBox")
        self.tasks_pg = QtGui.QWidget()
        self.tasks_pg.setGeometry(QtCore.QRect(0, 0, 665, 240))
        self.tasks_pg.setObjectName("tasks_pg")
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.tasks_pg)
        self.verticalLayout_2.setContentsMargins(2, 0, 2, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.tasks_tree = TasksTree(self, self.tasks_pg)
        self.tasks_tree.setObjectName("tasks_tree")
        self.horizontalLayout.addWidget(self.tasks_tree)
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.task_edit_btn = QtGui.QPushButton(self.tasks_pg)
        self.task_edit_btn.setObjectName("task_edit_btn")
        self.verticalLayout.addWidget(self.task_edit_btn)
        self.task_group_btn = QtGui.QPushButton(self.tasks_pg)
        self.task_group_btn.setObjectName("task_group_btn")
        self.task_group_btn.hide()
        self.verticalLayout.addWidget(self.task_group_btn)
        self.remove_task_btn = QtGui.QPushButton(self.tasks_pg)
        self.remove_task_btn.setObjectName("remove_task_btn")
        self.verticalLayout.addWidget(self.remove_task_btn)
        spacerItem10 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, 
                                        QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem10)
        self.horizontalLayout.addLayout(self.verticalLayout)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        self.toolBox.addItem(self.tasks_pg, "")
        self.log_pg = QtGui.QWidget()
        self.log_pg.setGeometry(QtCore.QRect(0, 0, 665, 240))
        self.log_pg.setObjectName("log_pg")
        self.verticalLayout_4 = QtGui.QVBoxLayout(self.log_pg)
        self.verticalLayout_4.setContentsMargins(2, 0, 2, 0)
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.verticalLayout_3 = QtGui.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.copy_btn = QtGui.QToolButton(self.log_pg)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap("medias/clipboard.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.copy_btn.setIcon(icon3)
        self.copy_btn.setShortcut("Ctrl+C")
        self.copy_btn.setObjectName("copy_btn")
        self.horizontalLayout_2.addWidget(self.copy_btn)
        self.select_txt_btn = QtGui.QToolButton(self.log_pg)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap("medias/select-all.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.select_txt_btn.setIcon(icon4)
        self.select_txt_btn.setShortcut("Ctrl+A")
        self.select_txt_btn.setObjectName("select_txt_btn")
        self.horizontalLayout_2.addWidget(self.select_txt_btn)
        self.erase_btn = QtGui.QToolButton(self.log_pg)
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap("medias/eraser.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.erase_btn.setIcon(icon5)
        self.erase_btn.setShortcut("Delete")
        self.erase_btn.setObjectName("erase_btn")
        self.horizontalLayout_2.addWidget(self.erase_btn)
        self.save_btn = QtGui.QToolButton(self.log_pg)
        icon6 = QtGui.QIcon()
        icon6.addPixmap(QtGui.QPixmap("medias/save.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.save_btn.setIcon(icon6)
        self.save_btn.setShortcut("Ctrl+S")
        self.save_btn.setObjectName("save_btn")
        self.horizontalLayout_2.addWidget(self.save_btn)
        self.log_file_lbl = QtGui.QLabel(self.log_pg)
        self.horizontalLayout_2.addWidget(self.log_file_lbl)
        spacerItem11 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem11)
        self.verticalLayout_3.addLayout(self.horizontalLayout_2)
        self.log_editor = LogEditor(self, self.log_pg)
        self.log_editor.setObjectName("log_editor")
        self.horizontalLayout_10 = QtGui.QHBoxLayout()
        self.horizontalLayout_10.setObjectName("horizontalLayout_10")
        self.warning_wdg = WarningWidget(self)
        #self.warning_wdg.hide()
        self.horizontalLayout_10.addWidget(self.warning_wdg)
        self.verticalLayout_3.addLayout(self.horizontalLayout_10)
        self.verticalLayout_3.addWidget(self.log_editor)
        self.verticalLayout_4.addLayout(self.verticalLayout_3)
        self.toolBox.addItem(self.log_pg, "")
        self.verticalLayout_7.addWidget(self.toolBox)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        spacerItem12 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem12)
        self.close_btn = QtGui.QPushButton(DifferedTaskDialog)
        icon8 = QtGui.QIcon()
        icon8.addPixmap(QtGui.QPixmap("medias/close.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.close_btn.setIcon(icon8)
        self.close_btn.setObjectName("close_btn")
        self.horizontalLayout_3.addWidget(self.close_btn)
        spacerItem13 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem13)
        self.verticalLayout_7.addLayout(self.horizontalLayout_3)
        self.gridLayout_3.addLayout(self.verticalLayout_7, 0, 0, 1, 1)
        self.set_combo_items()
        self.set_current_datetime()
        self.dial = DifferedTaskDialog
        self.retranslateUi(self.dial)
        self.set_style()
        self.toolBox.setCurrentIndex(0)
        self.ok_warn_btn.hide()
        self.closed = False

        self.current_site = 'plus'
        self.plus_rdo.toggled.connect(self.set_current_site)
        self.movie_rdo.toggled.connect(self.enable_movie_entry)
        self.select_btn.clicked.connect(self.select_item)
        self.serial_rdo.toggled.connect(self.enable_movie_entry)
        self.day_rdo.toggled.connect(self.enable_day_entry)
        self.create_btn.clicked.connect(self.create_task)
        self.task_edit_btn.clicked.connect(self.edit_task)
        self.remove_task_btn.clicked.connect(self.remove_task)
        self.copy_btn.clicked.connect(self.log_editor.copy_)
        self.select_txt_btn.clicked.connect(self.log_editor.select_all)
        self.erase_btn.clicked.connect(self.log_editor.erase_selected_text)
        self.save_btn.clicked.connect(self.log_editor.save_log)
        self.close_btn.clicked.connect(self.on_close_request)
        QtCore.QMetaObject.connectSlotsByName(DifferedTaskDialog)

        self.enable_tree_buttons(False)
        self.current_tree_item = None

    def set_current_site(self):
        if self.plus_rdo.isChecked():
            self.current_site = 'plus'
            self.serial_rdo.setEnabled(True)
            self.all_rdo.setEnabled(True)
            self.recent_rdo.setChecked(True)
            self.day_rdo.setChecked(True)
            self.week_rdo.setEnabled(True)

        else:
            self.current_site = 'live'
            self.movie_rdo.setChecked(True)
            self.serial_rdo.setEnabled(False)
            self.all_rdo.setEnabled(False)
            self.recent_rdo.setChecked(True)
            self.day_rdo.setChecked(True)
            self.week_rdo.setEnabled(False)
            
    def enable_movie_entry(self):
        self.mov_name_led.setEnabled(self.movie_rdo.isChecked())
        self.select_btn.setEnabled(self.movie_rdo.isChecked())
        self.serial_cmb.setEnabled(self.serial_rdo.isChecked())
        self.kword_led.setEnabled(self.kword_rdo.isChecked())

    def select_item(self):
        self.dtk.set_selection_mode() 
      
    def enable_day_entry(self):
        self.date_spb.setEnabled(self.day_rdo.isChecked())
        self.time_spb.setEnabled(self.day_rdo.isChecked())
        self.week_cmb.setEnabled(self.week_rdo.isChecked())
        self.time_spb_2.setEnabled(self.week_rdo.isChecked())

    def create_task(self):
        self.dtk.create_new_task()

    def edit_task(self):
        select = self.tasks_tree.set_editable()
        if not select:
            return

        self.dtk.edit_task(select)

    def group_tasks(self):
        pass

    def remove_task(self):
        sel =  self.tasks_tree.get_selection()
        if not sel:
            return
        
        self.dtk.delete_tasks(self.tasks_tree.get_selected_tasks())
        self.tasks_tree.remove_selection()
        QtCore.QCoreApplication.processEvents()
        self.enable_tree_buttons(False)

    def set_tasks(self, tasks):
        for task in tasks:
            if task.type == 0:
                self.tasks_tree.set_multi_tasks(task)

            else:
                self.tasks_tree.set_single_task(task)

    def get_datetime(self, dct):
        if dct.dayofweek is not None:
            if dct.dayofweek == '0-6':
                d = 7

            else:
                d = int(dct.dayofweek)

            if self.dtk.lang == 'fr':
                date = DAYS_FR[d]

            else:
                date = DAYS_DE[d]

        else:
            date = "/".join([str(dct.date[0]), str(dct.date[1])])

        time = ":".join([str(dct.time[0]), str(dct.time[1])])
        return " ".join([date, time])

    def get_description(self, dct):
        if dct.movie:
            return " ".join(["Movie:", dct.movie])

        if dct.serial:
            return " ".join(["Serial:", dct.serial])

        if dct.keyword:
            return " ".join(["Keywords:", dct.keyword])

    def set_combo_items(self):
        obj = QtCore.QObject().__init__()
        if self.dtk.lang == 'fr':
            series = [u'28 minutes', u'360 - GEO', u'ARTE Journal', 
                    u'ARTE Reportage', u'ce qui me manque 2', u'Court-Circuit',
                    u'Karambolage', u"L'Art et la Manière", u'Le Blogueur',
                    u'Le Dessous des Cartes', u"Les mercredis de l'histoire",
                    u'Metropolis', u'One Shot Not', u'Personne ne bouge',
                    u'Philosophie', u'Square', u'Tracks', u'X:enius',
                    u'Yourope']
            days = DAYS_FR
            self.schedule = [(7, 21), (6, 21), (7, 13), (6, 20), None, None,
                            (0, 21), (0, 18), (0, 21), (3, 0), (3, 0),
                            (7, 16), None, (0, 19), (0, 14), (0, 13),
                            None, (7, 10), (7, 16)]
            
        else:
            series = [u'28 Minuten', u'360° - GEO-Reportage', 
                    u'Abgedreht', u'ARTE Journal', u'ARTE Reportage',
                    u'Der Blogger', u'Geschichte am Mittwoch', u'Karambolage', 
                    u'Künstler hautnah', u'Kurzschluss', u'Metropolis', 
                    u'Mit offenen Karten', u'One Shot Not', u'Philosophie', 
                    u'Square', u'Tracks', u'was mir fehlt 2',
                    u'X:enius', u'Yourope'] 
            days = DAYS_DE
            self.schedule = [(7, 21), (6, 21), (0, 19), (7, 13), (6, 20), 
                            (0, 21), (3, 0), (0, 21), (0, 18), None,
                            (7, 16), (3, 0), None, (0, 13), (0, 14),
                            None, None, (7, 10), (7, 16)]

        self.serial_cmb.addItems(series)
        self.week_cmb.addItems(days)
        self.set_qualities('plus')

    def set_qualities(self, site):
        self.quality_cmb.clear()
        if site == 'plus':
            qls = ["SD  Medium quality (720 x 406)", 
                    "MD  Good quality (720 x 406)",
                    "HD  Hight quality (1280 x 720)", 
                    "LD  Low quality (320 x 200)"]
        else:
            qls = ["HD  Hight quality",
                    "SD  Medium quality"]
        self.quality_cmb.addItems(qls)

    def set_current_datetime(self):
        val = datetime.now()
        val = val + timedelta(minutes=4)
        date = QtCore.QDate()
        date.setDate(val.year, val.month, val.day)
        self.date_spb.setMinimumDate(date)
        self.date_spb.setDate(date)
        time = QtCore.QTime()
        time.setHMS(val.hour, val.minute + 2, 0)
        self.time_spb.setTime(time)

    def on_invalid_datetime(self):
        self.warn_lbl.setText(_("Warning: time for cron job is too short!"))

    def on_restricted_time(self):
        self.warn_lbl.setText(_("Warning: time for this video is restricted"
                                " from 23:00 to 05:00!"))

    def on_unvalid_keywords(self):
        self.warn_lbl.setText(_(u"Warning: video not found with keywords!"))

    def enable_tree_buttons(self, b):
        self.task_edit_btn.setEnabled(b)
        self.task_group_btn.setEnabled(b)
        self.remove_task_btn.setEnabled(b)

    def rename_create_button(self, b):
        if b:
            self.create_btn.setText(_("Create"))
        else:
            self.create_btn.setText(_("Modify"))

    def on_close_request(self):
        self.closed = True
        self.dial.accept()

    def set_style(self):
        theme = Themes(self)
        theme.set_theme_dark()
        self.plus_rdo.setStyleSheet(theme.radioButton_style)
        self.live_rdo.setStyleSheet(theme.radioButton_style)
        self.movie_rdo.setStyleSheet(theme.radioButton_style)
        self.mov_name_led.setStyleSheet(theme.lineEdit_style)
        self.select_btn.setStyleSheet(theme.pushButton_style)
        self.ok_warn_btn.setStyleSheet(theme.pushButton_style)
        self.serial_rdo.setStyleSheet(theme.radioButton_style)
        self.serial_cmb.setStyleSheet(theme.comboBox_style)
        self.kword_led.setStyleSheet(theme.lineEdit_style)
        self.kword_rdo.setStyleSheet(theme.radioButton_style)
        self.all_rdo.setStyleSheet(theme.radioButton_style)
        self.recent_rdo.setStyleSheet(theme.radioButton_style)
        self.day_rdo.setStyleSheet(theme.radioButton_style)
        self.date_spb.setStyleSheet(theme.dateEdit_style)
        self.time_spb.setStyleSheet(theme.timeEdit_style)
        self.week_rdo.setStyleSheet(theme.radioButton_style)
        self.week_cmb.setStyleSheet(theme.comboBox_style)
        self.time_spb_2.setStyleSheet(theme.timeEdit_style)
        self.quality_cmb.setStyleSheet(theme.comboBox_style)
        self.create_btn.setStyleSheet(theme.pushButton_style)
        self.task_edit_btn.setStyleSheet(theme.pushButton_style)
        self.task_group_btn.setStyleSheet(theme.pushButton_style)
        self.remove_task_btn.setStyleSheet(theme.pushButton_style)
        self.copy_btn.setStyleSheet(theme.pushButton_style)
        self.select_txt_btn.setStyleSheet(theme.pushButton_style)
        self.save_btn.setStyleSheet(theme.pushButton_style)
        self.close_btn.setStyleSheet(theme.pushButton_style)

    def retranslateUi(self, dial):
        dial.setWindowTitle(_("Differed Downloading Configuration - Qarte "))
        self.groupBox.setTitle(_("New task"))
        self.plus_rdo.setText(_("arte+7"))
        self.live_rdo.setText(_("arteLiveWeb + Extras"))
        self.movie_rdo.setToolTip(_("Choose by movie name"))
        self.movie_rdo.setText(_("Movie name"))
        self.mov_name_led.setToolTip(_("Enter the movie name "))
        self.select_btn.setToolTip(_("Click to select a video in the viewer"))
        self.warn_lbl.setText("")
        self.ok_warn_btn.setToolTip(_("Apply proposed name"))
        self.ok_warn_btn.setText(_("OK"))
        self.serial_rdo.setText(_("Name of series"))
        self.serial_cmb.setToolTip(_("Choose a serial name"))
        self.kword_led.setToolTip(_("Enter keywords separated by space"))
        self.kword_rdo.setText(_("Keywords"))
        self.all_rdo.setText(_("All releases"))
        self.recent_rdo.setText(_("Most recent release"))
        self.day_rdo.setToolTip(_("Unique downloading"))
        self.day_rdo.setText(_("Day"))
        self.date_spb.setDisplayFormat("dd/MM/yyyy")
        self.week_rdo.setToolTip(_("Multiple downloading"))
        self.week_rdo.setText(_("By week"))
        self.quality_lbl.setText(_("Quality:"))
        self.create_btn.setToolTip(_("Create the new task"))
        self.create_btn.setText(_("Create"))
        self.task_edit_btn.setToolTip(_("Edit selected task"))
        self.task_edit_btn.setText(_("Edit"))
        self.task_group_btn.setToolTip(_("Group selected tasks"))
        self.task_group_btn.setText(_("Group"))
        self.remove_task_btn.setToolTip(_("Remove selected tasks"))
        self.remove_task_btn.setText(_("Delete"))
        self.toolBox.setItemText(0, _("Tasks"))
        self.copy_btn.setToolTip(_("Copy selected text into the clipboard Ctrl+C"))
        self.select_txt_btn.setToolTip(_("Select all text Ctrl+A"))
        self.erase_btn.setToolTip(_("Delete selected text Delete"))
        self.save_btn.setToolTip(_("Save"))
        self.toolBox.setItemText(1, _("Log file"))
        self.close_btn.setText(_("Close"))

class TasksTree(QtGui.QTreeWidget):
    def __init__(self, gui, parent=None):
        super(TasksTree, self).__init__(parent)
        self.gui = gui
        self.main = gui.dtk
        self.setColumnCount(3)
        self.headerItem().setText(0, "ID")
        self.headerItem().setText(1, "Date")
        self.headerItem().setText(2, "Movie")
        self.setColumnWidth(0, 60)
        self.setColumnWidth(1, 150)
        self.header().setCascadingSectionResizes(True)
        self.setAlternatingRowColors(True)
        self.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.currentItemChanged.connect(self.on_item_changed)
        self.itemClicked.connect(self.on_item_clicked)
        self.editable = False

    def set_single_task(self, item):
        wdg = QtGui.QTreeWidgetItem(self)
        self.set_values(wdg, item)

    def set_values(self, tw, item):
        tw.setText(0, str(item.ID))
        dt = self.gui.get_datetime(item)
        tw.setText(1, dt)
        desc = self.gui.get_description(item)
        tw.setText(2, desc)

    def set_editable(self):
        sel = self.get_selection()
        if not sel:
            return False

        self.editable = sel[0]
        return int(sel[0].text(0))

    def update_task(self, item):
        self.set_values(self.editable, item)
        self.clearSelection()
        self.gui.enable_tree_buttons(False)

    def get_selection(self):
        return self.selectedItems()

    def get_selected_tasks(self):
        sel = self.get_selection()
        if not sel:
            return None

        tasks = []
        for s in sel:
            tasks.append(int(s.text(0)))

        return tasks

    def remove_selection(self):
        for item in self.get_selection():
            idx = self.indexOfTopLevelItem(item)
            self.takeTopLevelItem(idx)

    def on_item_changed(self, new, old):
        pass

    def on_item_clicked(self, item, idx):
        self.gui.enable_tree_buttons(True)
        self.gui.task_edit_btn.setEnabled(len(self.get_selection()) == 1)

class WarningWidget(QtGui.QWidget):
    def __init__(self, ui, parent=None):
        super(WarningWidget, self).__init__(parent)
        self.layout = QtGui.QHBoxLayout(self)
        self.label = QtGui.QLabel(self)
        self.label.setText(_("Log file has been modified on disk!"))
        font = QtGui.QFont("sans", 10)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet("QLabel {background: #FFBB00};")
        self.layout.addWidget(self.label)
        spacer = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.layout.addItem(spacer)
        self.reload_btn = QtGui.QPushButton(self)
        self.reload_btn.setText(_("Reload"))
        self.layout.addWidget(self.reload_btn)
        self.ignore_btn = QtGui.QPushButton(self)
        self.ignore_btn.setText(_("Ignore"))
        self.layout.addWidget(self.ignore_btn)
        self.reload_btn.clicked.connect(ui.log_editor.load_log)
        self.ignore_btn.clicked.connect(self.hide)


