# -*- coding: utf-8 -*-

# parsers.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2011-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Parser for pages arte TV and arteLiveWeb

import os, re
import time
import urllib2, xml.dom.minidom
import json
import sys
import pickle
import copy
import datetime
import logging
logger = logging.getLogger(__name__)

from threading import Thread, current_thread
from threading import enumerate as enumerate_
from email.utils import parsedate

from PyQt4.QtCore import QObject, pyqtSignal

from data import CATEGORIES

class ArteTVParser(QObject):
    parsingFinished = pyqtSignal(list)
    updatingFinished = pyqtSignal()
    URL_ALL = "http://www.arte.tv/guide/fr/plus7.json"

    ALL_FORMATS = re.compile('(?<=<div class="video-container")(.*?)'
                            '(?=<div class="overlay">)', re.DOTALL)
    ALL_FORMATS_2 = re.compile('(?<=<div class="video-container")(.*?)'
                            '(?=</div>)', re.DOTALL)
    ALL_FORMATS_3 = re.compile("(?<=<span class='badge-arte7'>)(.*?)(?=video-container)", re.DOTALL)
    ALL_JSON = re.compile('(?<=arte_vp_url=")(.*?)(?=ALL.json">)', re.DOTALL)
    ALL_JSON_2 = re.compile("(?<=arte_vp_url=')(.*?)(?=ALL.json)", re.DOTALL)
    RESTRICTED = re.compile('(?<=<p class="time-row">)(.*?)(?=</p>)', re.DOTALL)
    SUMMARY = re.compile('(?<=<meta name="description" content=")(.*?)(?=/>)', 
                            re.DOTALL)
    LONG_DESC = re.compile('(?<=<p itemprop="description" id="content-description"'
                            ' class="collapse">)(.*?)(?=</p>)', re.DOTALL)
    METADATA = re.compile('(?<=<section class="sidebar span2 hidden-phone" '
                            'id="details-metadata">)(.*?)'
                            '(?=<a href="#"><span class="meta-label">)', 
                            re.DOTALL)
    METADATUM = re.compile('(?<=<span class="meta-label">)(.*?)(?=</span>)', 
                            re.DOTALL)
    MONTHS = [u"ja", u"f", u"mar", u"av", u"mai", u"juin", u"juil", u"ao", 
                u"se", u"oc", u"no", u"d", u"Ja", u"F", u"Mä", u"Ap", u"Mai", 
                u"Jun", u"Jul", u"Au", u"Se", u"Ok", u"No", u"De"]

    def __init__(self, main, lang, videos):
        """Instanciate the arte.tv parser.

        Args:
        main -- ArtePlus instance
        lang -- 'fr' or 'de'
        video -- reference of main's video list (empty)
        """
        super(ArteTVParser, self).__init__()
        self.main = main
        self.videos = videos
        self.lang = lang
        self.findex = os.path.join(main.user_fld, 'summaries')
        self.is_updating = False
        self.close_app = False
        self.is_daemon = False

    def parse(self):
        """Get www.arte.tv/ page and run parsing.

        """
        # Stage 1
        url = self.URL_ALL.replace('fr', self.lang)
        logger.info(u"Run arte+7 parser: {0}".format(current_thread()))
        logger.info(u"Get page: {0}".format(url))
        content, err = self.get_page_content(url)

        if content is None:
            logger.info(u"Read Error: {0}".format(err))
            self.parsingFinished.emit(['error', 'Stage 1', err])
            return

        if not len(content):
            logger.info(u"Read Error: 'Page empty'")
            self.parsingFinished.emit(['error', 'Stage 1', 'Page empty'])
            return

        # Stage 2
        # The page is a json format, we need just to parse the dict.
        dct = json.loads(content.decode('utf8', 'replace'))
        logger.info(u"json loaded")

        for vid in dct["videos"]:
            item = []
            try:
                url = "http://www.arte.tv" + vid['url'] + "?autoplay=1"
            except Exception as why:
                logger.info(u'Read url error: {0}, rejected'.format(why))
                continue

            for key in ['title', 'airdate_long', 'duration', 'image_url', 'desc']:
                try:
                    item.append(vid[key])
                except Exception as why:
                    logger.info(u'Read {0} error: {1}'.format(key, why))
                    item.append(None)

            item.insert(3, url)
            nd = self.normalise_date(item[1])
            item.append(nd)
            video = VideoPlusItem(item)
            self.videos.append(video)

        logger.info(u'Parsed %s videos' % len(self.videos))
        self.parsingFinished.emit([None])


    def get_page_content(self, url):
        """Fetch a html or xml page.

        Args:
        url -- page URL

        Returns:
        page as text or None if fail
        """
        try:
            content = urllib2.urlopen(url).read()
        except IOError as why:
            logger.info(u'urllib2 error: %s' % why)
            return None, why

        return content, None

    def normalise_date(self, value):
        td = datetime.date.today()
        ldate = value.split()
        mnt = m = ldate[2]
        for idx, month in enumerate(self.MONTHS):
            if mnt.startswith(month):
                m = str(idx+1)

        if len(m) == 1:
            m = '0' + m

        try:
            sdate = " ".join([str(td.year), m, '%s, %s' % (ldate[1], ldate[4])])
        except Exception as why:
            sdate = value
            logger.info(u'date error:', ldate, why)

        return sdate

    def update_all(self):
        """Called after the viewer is completed for update the video infos.

        """
        self.is_updating = True
        Thread(target=self.update_videos_infos, args=(None,)).start()

    def update_videos_infos(self, *args):
        """Update the summary with file 'summaries'.

        """
        logger.info(u"Update arte+7 summaries list")
        logger.info(u"Threads enum: {0}".format(enumerate_()))
        begin = time.time()
        self.load_summaries()
        summaries = {}

        if not self.summaries:
            # First use, we need to create the file 'summaries'
            self.get_new_infos()
            return

        for idx, video in enumerate(self.videos):
            # summaries is a dict where the keys are the video's datetime
            orig = ''
            if video.date in self.summaries:
                try:
                    summ = self.summaries[video.date][0]
                except IndexError:
                     summ = ''

                if not summ:
                    summ, orig = self.fetch_summary(video.link)
                    if summ is None:
                        summ = ''

                video.summary = summ

                try: 
                    # orig is '(country, anno)'
                    video.orig = self.summaries[video.date][1]
                except IndexError:
                    video.orig = orig

            else:
                video.summary, video.orig = self.fetch_summary(video.link)

            summaries[video.date] = [video.summary, video.orig]

        self.summaries = summaries
        self.main.summaries = self.summaries
        self.save_videos_infos()
        self.is_updating = False
        self.updatingFinished.emit()

    def get_new_infos(self):
        """Create the file summaries at first use.

        """
        for video in self.videos:
            if self.close_app:
                # exit requested by the user
                self.is_updating = False
                break

            video.pitch = video.title
            video.orig = ""
            if video.summary is None:
                infos = self.fetch_summary(video.link)
                if len(infos) > 1:
                    video.summary = infos[0]
                    o = infos[1]
                    if o is None:
                        o = ""
                    else:
                        for s in ('Als Live verfügbar: ja ', 
                                  'Als Live verfügbar: nein ',
                                  'Disponible en direct: oui ', 
                                  'Disponible en direct: non '):
                            o = o.replace(s, '')
                            video.orig = o

                self.summaries[video.date] = infos[0], o

        self.main.summaries = self.summaries
        self.save_videos_infos()
        self.is_updating = False
        self.updatingFinished.emit()

    def fetch_summary(self, link):
        """Extract from the video page the description and metadata.

        There's two descriptions, one short and one long.
        The metadata are Country, Year, Sound, version, ...

        Args:
        link -- page URL

        Returns:
        (short description, long description, metadata)
        """
        reply = self.get_page_content(link)

        if reply[0] is None:
            return None, None, None

        content = reply[0]
        pitch = desc = orig = ''
        ldesc = self.SUMMARY.search(content)
        meta = self.METADATA.search(content)

        if ldesc is not None:
            desc = ldesc.group(0).strip()
            try:
                desc = desc.decode('utf-8', 'replace')
                desc.replace('&#x27;', "'")
            except:
                pass

        if meta is not None:
            data = self.METADATUM.findall(meta.group(0))
            if data:
                for dt in data:
                    dt = dt.decode('utf-8', 'replace')
                    orig = orig + ' ' + dt.replace(' :', ':')

        return desc, orig

    def load_summaries(self):
        """Summaries are saved in a dictionnary where keys are the video's dates.

        """
        try:
            with open(self.findex, "r") as objfile:
                self.summaries = pickle.load(objfile)
        except:
            # Assume is first use
            self.summaries = {}

    def save_videos_infos(self):
        try:
            with open(self.findex, 'w') as objf:
                pickle.dump(self.summaries, objf)
        except Exception as why:
            logger.warning(u"Unable to save summaries list, reason: \n\t{0}"
                                .format(why))
        logger.info(u"arte+7 summaries updated")

    def get_stream_urls(self, page):
        # load file ... le-saint?autoplay=1
        # returns dict or 'restricted' or None if fail
        logger.info(u'Get stream URLs for: {0}'.format(page))
        content = self.get_page_content(page)
        if content[0] is not None:
            af = self.ALL_FORMATS_3.search(content[0])
            if af is not None:
                res = af.group(0)
            else:
                af = self.ALL_FORMATS_2.search(content[0])
                if af is not None:
                    res = af.group(0)
                else:
                    af = self.ALL_FORMATS.search(content[0])
                    if af is None:
                        logger.info(u'Reading autoplay: all_format not Found')
                        return 'unvalid'
                    res = af.group(0)

            lnk = self.ALL_JSON_2.search(res)
            if lnk is not None:
                all_json = lnk.group(0) + 'ALL.json'
                streams = self.sort_video_stream(all_json)
                return streams

            else:
                lnk = self.ALL_JSON.search(res)
                if lnk is not None:
                    all_json = lnk.group(0) + 'ALL.json'
                    streams = self.sort_video_stream(all_json)
                    return streams

                else:
                    res = self.RESTRICTED.search(content[0])
                    if res is not None:
                        txt = res.group(0)
                        if '23h' in txt or '23:00' in txt:
                            return 'restricted'

        logger.info(u'Get stream URLs error: %s' % content[1])

    def sort_video_stream(self, page):
        # load file ...F/048475-121_PLUS7-F/ALL/ALL.json
        content = self.get_page_content(page)
        if content[0] is not None:
            dct = json.loads(content[0].decode('utf8', 'replace'))
            try:
                pl = dct["videoJsonPlayer"]
            except Exception as why:
                logger.info(u'stream not found:\n{0}\n{1}'.format(page, why))
                return

            try:
                vsr = pl["VSR"]
            except Exception as why:
                logger.info(u'vsr not found:\n{0}\n{1}'.format(page, why))
                return 

            return vsr


class LiveParser(QObject):
    loadingPageFailed = pyqtSignal(int, str)
    loadingCategoryFinished = pyqtSignal(str)
    loadingCategoryFailed = pyqtSignal(str)
    def __init__(self, alw, URLS_FR, URLS_DE):
        """Instanciate the arteLiveWeb parser.

        Args:
        alw -- ArteLiveWeb instance
        """
        super(LiveParser, self).__init__()
        self.alw = alw
        self.lang = alw.lang
        self.urls = URLS_FR
        if self.lang == 'de':
            self.urls = URLS_DE

        self.concert_re = re.compile('(<div class="header-article ">(.*?).jpg?)', re.DOTALL)
        self.sum_re = re.compile('(property="content:encoded">(.*?)</div>)', re.DOTALL)
        self.json_re = re.compile('(arte_vp_url="(.*?)")', re.DOTALL)
        self.date_re = re.compile('(<p class="arte-video-time">(.*?)</p>)', re.DOTALL)

    def parse(self):
        ARTE_WEB_ROOT = 'http://liveweb.arte.tv/{0}'.format(self.lang)
        cat_re = re.compile("".join(['<li><a href="http://liveweb.arte.tv/',
                                    self.lang,
                                    '/cat/(?P<lien>.*?)" class="accueil"',
                                    '>(?P<nom>.*?)</a></li>']), re.DOTALL)
        count = 0
        self.categories = {}

        # Stage 1
        logger.info(u"Get page: {0}".format(ARTE_WEB_ROOT))
        reply = self.get_page(ARTE_WEB_ROOT)
        if reply[0] is None:
            if isinstance(reply[1], urllib2.URLError):
                rs = unicode(reply[1].reason)

            else:
                rs = str(reply[1])

            self.loadingPageFailed.emit(7, rs)
            return False

        # Stage 2
        for item in re.finditer(cat_re, reply[0]):
            self.categories[item.group('nom').decode('utf-8', 'replace')] \
                                                    = item.group('lien')

        self.categories[u'La Blogothèque'] = 'blogo'
        self.alw.set_categories(self.categories)

        return True

    def get_videos_list(self, cat):
        # Stage 3
        logger.info(u"Get arteLiveWeb video's data in '{0}'".format(cat))
        logger.info(u"Threads enum: {0}".format(enumerate_()))

        re_items = re.compile("(<item>.*?</item>)", re.DOTALL)
        #videos = {}
        #value = self.categories[cat]
        #url = "http://liveweb.arte.tv/{0}/cat/{1}".format(self.lang, value)
        urls = self.urls[cat]
        vids = {}
        for url in urls:
            page = self.get_page(url)

            if page[0] is None:
                logger.info(u"Loading category {0} failed".format(cat))
                logger.info(u"Reason: {0}".format(str(page[1])))
                #self.loadingCategoryFailed.emit(str(page[1]))
                continue

            if not len(page[0]):
                logger.info(u'Page {0} is empty'.format(cat))
                #self.loadingCategoryFailed.emit('page is empty')
                continue

            if url.startswith('http://concert'):
                self.find_item_at_concert(cat, vids, page[0])

            else:
                items = re.findall(re_items, page[0])
                #videos[cat] = items

                # Stage 4
                for item in items:
                    it = self.get_element(item)

                    if it is None:
                        continue

                    if it['ID'] in vids:
                        # Duplicate
                        continue

                    try:
                        rfc_date = parsedate(it['date'])
                        lt = time.localtime(time.mktime(rfc_date))
                        it['date'] = time.strftime('%c', lt).decode('utf-8', 'ignore')
                        if time.mktime(rfc_date) - float(time.time()) > 0:
                            it['soon'] = True
                    except:
                        it['date'] = 'Date ?'

                    itm = VideoItem(cat, it)
                    vids[it['ID']] = itm

        logger.info('category {0} has {1} videos'.format(cat, len(vids)))
        self.alw.videos[cat] = vids
        self.loadingCategoryFinished.emit(CATEGORIES[self.lang][cat])

    def find_item_at_concert(self, category, dct, page):
        """This parse the new site arte concert.

        Args:
        category -- the name of the category
        dct -- dictionnary for the current category
        page -- the content of the category.
        
        In this page we need to ind all occurrences of:
        <div class="header-article ">
        <a href="/fr/agnes-obel-au-grand-rex" title="Agnes Obel au Grand Rex"><figure>
        """
        elem = self.concert_re.findall(page)
        if elem is not None:
            for ele in elem:
                if isinstance(ele, tuple):
                    try:
                        it = ele[1].split('"')
                    except Exception as why:
                        continue

                    if len(it) > 3:
                        link, title, thumb = it[1], it[3], it[-1]
                        link = 'http://concert.arte.tv' + link
                        if not thumb.startswith('http://www.'):
                            thumb = None
                        else:
                            thumb = thumb + '.jpg'

                        summary, jsonlink, date = self.get_concert_summary(link)

                        if jsonlink is None:
                            continue

                    item = {}
                    item['ID'] = jsonlink.split('/')[-1]
                    item['title'] = self.clean_title(title)
                    item['link'] = jsonlink
                    item['date'] = date
                    item['pitch'] = summary
                    item['pict'] = thumb
                    item['author'] = 'Unknow'
                    item['soon'] = False
                    itm = VideoItem(category, item)
                    dct[item['ID']] = itm

        else:
            logger.info("Page empty")

    def get_concert_summary(self, url):
        page = self.get_page(url)
        if page[0] is None or not len(page[0]):
            return None, None, None

        try:
            summary = self.sum_re.search(page[0]).group(0)
        except Exception as why:
            summary = "No description"
        else:
            summary = summary.replace('property="content:encoded">', '')
            summary = summary.replace('</div>', '').strip()
            summary = summary.decode('utf-8', 'replace')

        try:
            jsn = self.json_re.search(page[0]).group(0)
        except:
            # The json file link is mandatory to find the stream links
            return None, None, None
        else:
            jsn = jsn.replace('arte_vp_url="', '').replace('"', '').strip()

        try:
            date = self.date_re.search(page[0]).group(0)
        except:
            date = "No date"
        else:
            date = date.decode('utf-8', 'replace')
            date = date.replace('<p class="arte-video-time">', '').replace('</p>', '')
            date = date.replace('&agrave;', '').strip()

        return summary, jsn, date

    def get_element(self, chain):
        ele = {'HD': None, 'SD': None, 'Live': None, 'soon': False}
        count = 0
        tt = re.compile("(?<=<title>)(.*?)(?=</title>)", re.DOTALL)
        lk = re.compile("(?<=<link>)(http://liveweb.arte.tv/{0}/video/.*?)"
                        "(?=</link>)".format(self.lang), re.DOTALL)
        dt = re.compile("(?<=<pubDate>)(.*?)(?=</pubDate>)", re.DOTALL)
        pt = re.compile("(?<=<description>)(.*?)(?=</description>)", re.DOTALL)
        at = re.compile("(?<=<author>)(.*?)(?=</author>)", re.DOTALL)
        en = re.compile("<enclosure.*?/event/.*?/(.*?)-.*?/>", re.DOTALL)
        pix = re.compile('(?<=<enclosure url=")(.*?)(?=" type="image/)')
      
        try:
            s = tt.search(chain).group(0)
            ele['title'] = s.decode('utf-8', 'replace')
        except:
            return None

        try:
            ele['link']  = lk.search(chain).group(0)
        except Exception, why:
            ele['link']  = "No link"

        try:
            s = (dt.search(chain).group(0))
            ele['date'] = s.decode('utf-8', 'replace')
        except:
            ele['date'] = "No date"

        try:
            s = (pt.search(chain).group(0))
            ele['pitch'] = s.decode('utf-8', 'replace')
        except:
            ele['pitch'] = "No description"

        try:
            s = (at.search(chain).group(0))
            ele['author'] = s.decode('utf-8', 'replace')
        except:
            ele['author'] = "Unknow"

        try:
            ele['ID'] = int(en.search(chain).group(1))
        except:
            ele['ID'] = 0

        try:
            ele['pict'] = pix.search(chain).group(0)
        except:
            ele['pict'] = None

        return ele

    def get_page(self, url):
        logger.info('get page {0}'.format(url))
        try:
            content = urllib2.urlopen(url).read()
        except IOError as why:
            return None, why

        return self.unescape(content), None

    def get_links(self, idx):
        url = "http://arte.vo.llnwd.net/o21/liveweb/events/event-{0}.xml".format(idx)
        page = self.get_page(url)
        logger.info('Get stream links: %s' % url)
        if page[0] is None:
            if isinstance(page[1], urllib2.URLError):
                rs = unicode(page[1].reason)

            else:
                rs = str(page[1])

            self.loadingPageFailed.emit(5, str(rs))
            return

        page = page[0]
        HD = re.compile("(?<=<urlHd>)(.*?)(?=</urlHd>)", re.DOTALL)
        SD = re.compile("(?<=<urlSd>)(.*?)(?=</urlSd>)", re.DOTALL)
        Live = re.compile("(?<=<liveUrl>)(.*?)(?=</liveUrl>)", re.DOTALL)
        obj = {}

        try:
            obj['HD'] = HD.search(page).group(0)
        except AttributeError:
            obj['HD'] = None

        try:
            obj['SD'] = SD.search(page).group(0)
        except AttributeError:
            obj['SD'] = None

        try:
            obj['Live'] = Live.search(page).group(0)
        except AttributeError:
            obj['Live'] = None

        return obj

    def unescape(self, text):
        text = text.replace("&lt;", "<")
        text = text.replace("&gt;", ">")
        text = text.replace("&amp;", "&")

        return text

    def clean_title(self, title):
        try:
            title = title.decode('utf-8', 'replace')
        except:
            return title

        title = title.replace('&#039;', "'").replace('&quot;', '"')
        return title

    def get_concert_stream_qualities(self, page):
        content = self.get_page(page)
        if content[0] is not None:
            dct = json.loads(content[0].decode('utf8', 'replace'))

            try:
                pl = dct["videoJsonPlayer"]
            except Exception as why:
                logger.info(u'stream not found:\n{0}\n{1}'.format(page, why))
                return

            try:
                vsr = pl["VSR"]
            except Exception as why:
                logger.info(u'vsr not found:\n{0}\n{1}'.format(page, why))
                return 

            urls = [None, None, None]
            try:
                urls[0] = vsr[u'HTTP_SQ_1'][u'url']
            except:
                pass
            try:
                urls[1] = vsr[u'HTTP_EQ_1'][u'url']
            except:
                pass
            try:
                urls[2] = vsr[u'HTTP_HQ_1'][u'url']
            except:
                pass

        return urls

class ExtraParser(QObject):
    loadingCategoryFinished = pyqtSignal(str)
    loadingCategoryFailed = pyqtSignal(str)
    ITEM = 'http://arte.vo.llnwd.net/o21/liveweb/events/event-[idx].xml'
    RE_ITEMS = re.compile('(?<=<item>)(.*?)(?=</item>)', re.DOTALL)
    RE_HD = re.compile('(?<=<urlHd>)(.*?)(?=</urlHd>)', re.DOTALL)
    TITLE = re.compile("(?<=<title>)(.*?)(?=</title>)", re.DOTALL)
    DATE = re.compile("(?<=<pubDate>)(.*?)(?=</pubDate>)", re.DOTALL)
    DESC = re.compile("(?<=<description>)(.*?)(?=</description>)", re.DOTALL)
    AUTHOR = re.compile("(?<=<author>)(.*?)(?=</author>)", re.DOTALL)
    EVENT = re.compile("<enclosure.*?/event/.*?/(.*?)-.*?/>", re.DOTALL)
    IMG = re.compile('(?<=<enclosure url=")(.*?)(?=" type="image/)')

    def __init__(self, aext):
        """Instanciate the arteLiveWeb parser.

        Args:
        alw -- ArteLiveWeb instance
        """
        super(ExtraParser, self).__init__()
        self.aext = aext
        self.lang = aext.lang
        self.partners = aext.partners
        self.LINK = re.compile("(?<=<link>)(http://liveweb.arte.tv/{0}/video/.*?)"
                                "(?=</link>)".format(self.lang), re.DOTALL)

    def read_partner(self, part):
        content = self.get_page(self.partners[part].replace('§', self.lang))
        if content[0] is None:
            logger.info('content of {0} is None: {1}'.format(part, content[1]))
            return

        items = self.RE_ITEMS.findall(content[0])
        vids = {}

        for it in items:

            vid = self.get_element(it)
            if vid is None:
                continue

            try:
                rfc_date = parsedate(vid['date'])
                lt = time.localtime(time.mktime(rfc_date))
                vid['date'] = time.strftime('%c', lt).decode('utf-8', 'ignore')
                if time.mktime(rfc_date) - float(time.time()) > 0:
                    vid['soon'] = True
            except:
                vid['date'] = 'Date ?'

            itm = VideoItem(part, vid)
            vids[vid['ID']] = itm

        self.aext.videos[part] = vids
        self.loadingCategoryFinished.emit(part)

    def get_page(self, url):
        logger.info('get page {0}'.format(url))
        try:
            content = urllib2.urlopen(url).read()
        except IOError as why:
            logger.info('page error: {0}'.format(why))
            return None, why

        return self.unescape(content), None

    def get_links(self, idx):
        page = self.get_page("http://arte.vo.llnwd.net/o21/liveweb/events/event-{0}.xml".format(idx))

        if page[0] is None:
            return

        page = page[0]
        HD = re.compile("(?<=<urlHd>)(.*?)(?=</urlHd>)", re.DOTALL)
        SD = re.compile("(?<=<urlSd>)(.*?)(?=</urlSd>)", re.DOTALL)
        Live = re.compile("(?<=<liveUrl>)(.*?)(?=</liveUrl>)", re.DOTALL)
        obj = {}

        try:
            obj['HD'] = HD.search(page).group(0)
        except AttributeError:
            obj['HD'] = None

        try:
            obj['SD'] = SD.search(page).group(0)
        except AttributeError:
            obj['SD'] = None

        try:
            obj['Live'] = Live.search(page).group(0)
        except AttributeError:
            obj['Live'] = None

        return obj

    def unescape(self, text):
        def ent2chr( m ):
            code = m.group( 1 )

            if( code.isdigit() ): 
                code = int( code )

            else:
                code = int( code[ 1 : ], 16 )

            if( code < 256 ): 
                return chr( code )

            else: 
                return '?'

        text = text.replace("&lt;", "<")
        text = text.replace("&gt;", ">")
        text = text.replace("&amp;", "&")

        return text

    def get_element(self, chain):
        lang = 'fr'
        ele = {'HD': None, 'SD': None, 'Live': None, 'soon': False}
        count = 0

        try:
            s = self.TITLE.search(chain).group(0)
            ele['title'] = s.decode('utf-8', 'replace')
        except:
            return None

        try:
            ele['link']  = self.LINK.search(chain).group(0)
        except Exception, why:
            ele['link']  = "No link"

        try:
            s = self.DATE.search(chain).group(0)
            ele['date'] = s.decode('utf-8', 'replace')
        except:
            ele['date'] = "No date"

        try:
            s = (self.DESC.search(chain).group(0))
            ele['pitch'] = s.decode('utf-8', 'replace')
        except:
            ele['pitch'] = "No description"

        try:
            s = (self.AUTHOR.search(chain).group(0))
            ele['author'] = s.decode('utf-8', 'replace')
        except:
            ele['author'] = "Unknow"

        try:
            ele['ID'] = int(self.EVENT.search(chain).group(1))
        except:
            ele['ID'] = 0

        try:
            ele['pict'] = self.IMG.search(chain).group(0)
        except:
            ele['pict'] = None

        return ele


class VideoPlusItem(object):
    def __init__(self, data):
        """Item video in arte+7.

        Args:
        data -- values provided by the parser
        ['title', 'long date', 'duration', 'url', 'image_url', 'desc', 'date']
        """
        d = dict(title = data[0],
                ldate = data[1],
                duration = data[2],
                link = data[3],
                pix = data[4],
                pitch = data[5],
                date = data[6],
                HD = None,
                SD = None,
                outfile = None,
                preview = None,
                summary = None,
                orig = None,
                streams = None,
                stream = None)

        for key, value in d.iteritems():
            setattr(self, key, value)


class VideoItem(object):
    def __init__(self, cat, item):
        """Item video in arteLiveWeb.

        Args:
        cat -- category
        item -- values provided by the parser
        """
        d = dict(category = cat,
                order = item['ID'],
                title = item['title'],
                date = item['date'],
                pitch = item['pitch'],
                link = item['link'],
                pix = item['pict'],
                soon = item['soon'],
                preview = None,
                HD = None,
                SD = None,
                Live = None,
                outfile = None,
                quality = None,
                author = item['author'])

        for key, value in d.iteritems():
            setattr(self, key, value)

        if self.pix is not None:
            self.preview = os.path.basename(self.pix)

    def get_stream_links(self, page):
        tt = re.compile("(?<=<nameDe>)(.*?)(?=</nameDe>)", re.DOTALL)
        HD = re.compile("(?<=<urlHd>)(.*?)(?=</urlHd>)", re.DOTALL)
        SD = re.compile("(?<=<urlSd>)(.*?)(?=</urlSd>)", re.DOTALL)
        Live = re.compile("(?<=<liveUrl>)(.*?)(?=</liveUrl>)", re.DOTALL)

        try:
            self.local_name = tt.search(page).group(0)
        except AttributeError:
            self.local_name = None

        try:
            self.HD = HD.search(page).group(0)
        except AttributeError:
            self.HD = None

        try:
            self.SD = SD.search(page).group(0)
        except AttributeError:
            self.SD = None

        try:
            self.Live = Live.search(page).group(0)
        except AttributeError:
            self.Live = None

    def get_image(self):
        if self.preview is not None:
            try:
                img = urllib2.urlopen(self.pix).read()
            except Exception, why:
                return None

            else:
                return img

        else:
            return None

