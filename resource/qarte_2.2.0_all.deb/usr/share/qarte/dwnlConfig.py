# -*- coding: utf-8 -*-

# dwnlConfig.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2012-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Download config dialog boxs

import gettext
import itertools
import logging

logger = logging.getLogger(__name__)

from PyQt4 import QtCore, QtGui

class ArtePlusDownloadingConfig(QtGui.QDialog):
    def __init__(self, obj, parent=None):
        # Dialog for arte+7
        super(ArtePlusDownloadingConfig, self).__init__(parent)
        self.obj = obj
        self.resize(650, 300)
        self.gridLayout_3 = QtGui.QGridLayout(self)
        self.gridLayout_3.setContentsMargins(4, 2, 4, 4)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.title_lbl = QtGui.QLabel(self)
        font = QtGui.QFont()
        font.setFamily("DejaVu Sans")
        font.setPointSize(12)
        font.setWeight(75)
        font.setBold(True)
        self.title_lbl.setFont(font)
        self.title_lbl.setAlignment(QtCore.Qt.AlignCenter)
        self.title_lbl.setObjectName("title_lbl")
        self.horizontalLayout.addWidget(self.title_lbl)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.filename_lbl = QtGui.QLabel(self)
        font = QtGui.QFont()
        font.setFamily("DejaVu Sans")
        font.setWeight(75)
        font.setBold(True)
        self.filename_lbl.setFont(font)
        self.filename_lbl.setObjectName("filename_lbl")
        self.horizontalLayout_2.addWidget(self.filename_lbl)
        spacerItem2 = QtGui.QSpacerItem(40, 17, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem2)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        spacerItem3 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem3)
        self.filename_led = QtGui.QLineEdit(self)
        self.filename_led.setObjectName("filename_led")
        self.horizontalLayout_3.addWidget(self.filename_led)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        spacerItem4 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem4)
        self.info_name_lbl = QtGui.QLabel(self)
        self.info_name_lbl.setText("")
        self.info_name_lbl.hide()
        self.info_name_lbl.setObjectName("info_name_lbl")
        self.horizontalLayout_4.addWidget(self.info_name_lbl)
        self.verticalLayout.addLayout(self.horizontalLayout_4)
        self.horizontalLayout_5 = QtGui.QHBoxLayout()
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        spacerItem5 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem5, 0, 0, 1, 1)
        self.replace_space_chb = QtGui.QCheckBox(self)
        self.replace_space_chb.setObjectName("replace_space_chb")
        self.gridLayout.addWidget(self.replace_space_chb, 0, 1, 1, 1)
        self.underscore_rdo = QtGui.QRadioButton(self)
        self.underscore_rdo.setChecked(True)
        self.underscore_rdo.setEnabled(False)
        self.underscore_rdo.setObjectName("underscore_rdo")
        self.buttonGroup = QtGui.QButtonGroup(self)
        self.buttonGroup.setObjectName("buttonGroup")
        self.buttonGroup.addButton(self.underscore_rdo)
        self.gridLayout.addWidget(self.underscore_rdo, 0, 2, 1, 1)
        spacerItem6 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem6, 1, 0, 1, 1)
        spacerItem7 = QtGui.QSpacerItem(118, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem7, 1, 1, 1, 1)
        self.hyphen_rdo = QtGui.QRadioButton(self)
        self.hyphen_rdo.setEnabled(False)
        self.hyphen_rdo.setObjectName("hyphen_rdo")
        self.buttonGroup.addButton(self.hyphen_rdo)
        self.gridLayout.addWidget(self.hyphen_rdo, 1, 2, 1, 1)
        self.horizontalLayout_5.addLayout(self.gridLayout)
        spacerItem8 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_5.addItem(spacerItem8)
        self.verticalLayout.addLayout(self.horizontalLayout_5)

        self.line = QtGui.QFrame(self)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName("line")
        self.verticalLayout.addWidget(self.line)
        self.horizontalLayout_6 = QtGui.QHBoxLayout()
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.quality_lbl = QtGui.QLabel(self)
        self.quality_lbl.setFont(font)
        self.quality_lbl.setObjectName("quality_lbl")
        self.version_lbl = QtGui.QLabel(self)
        self.version_lbl.setFont(font)
        self.version_lbl.setObjectName("version_lbl")

        self.horizontalLayout_7 = QtGui.QHBoxLayout()
        self.horizontalLayout_7.setObjectName("horizontalLayout_7")
        self.gridLayout_2 = QtGui.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.gridLayout_2.addWidget(self.quality_lbl, 0, 1, 1, 1)
        spacerItem14 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                    QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem14, 0, 1, 1, 1)
        self.gridLayout_2.addWidget(self.version_lbl, 0, 3, 1, 1)
        spacerItem14 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                    QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem14, 2, 1, 1, 1)
        self.buttonGroup_2 = QtGui.QButtonGroup(self)
        self.buttonGroup_2.setObjectName("buttonGroup_2")
        self.buttonGroup_3 = QtGui.QButtonGroup(self)
        self.buttonGroup_3.setObjectName("buttonGroup_3")
        
        sel_quality = ""
        sel_version = ""
        # Set the qualities availables
        avl = obj[2]
        #print avl
        qualities = set()
        versions = set()
        self.streams_by_q_version = dict()
        for k,val in avl.iteritems():
            q = 0
            try:
                q = val["bitrate"]
            except KeyError:
                logger.error("missing quality or bitrate for %s" % (k))
            qualities.add(q)
            v = ""
            try:
                v = val["versionCode"]
            except KeyError:
                logger.error("missing versionCode for %s" % (k))
            versions.add(v)
            self.streams_by_q_version[(q,v)] = k
            
            #print("avail: %s %s => %s" % (q,v,k))
            if obj[4] is not None and obj[4] == k:
                sel_quality = q
                sel_version = v
                #print("sel: %s %s" % (sel_quality,sel_version))

        idx = 2
        getval = lambda x: x[1]
        sortedqualities = list(qualities)
        sortedqualities.sort()
        self.QUALITIES = sortedqualities
        for ind, bitrate in enumerate(sortedqualities):
            rdo = QtGui.QRadioButton(self)
            #print("cur,sel : %s %s" % (bitrate, sel_quality))
            rdo.setChecked(sel_quality == bitrate)
            rdo.setObjectName(str(bitrate)+"_rdo")
            self.buttonGroup_2.addButton(rdo)
            self.buttonGroup_2.setId(rdo, ind)
            self.gridLayout_2.addWidget(rdo, idx, 1, 1, 1)
            spacerItem14 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
            self.gridLayout_2.addItem(spacerItem14, idx+1, 0, 1, 1)
            idx+=2
            
        idx = 2
        self.VERSIONS = list(versions)
        self.VERSIONS.sort()
        for ind, q in enumerate(self.VERSIONS):
            rdo = QtGui.QRadioButton(self)
            #print("cur,sel : %s %s" % (q, sel_version))
            rdo.setChecked(sel_version == q)
            rdo.setObjectName(q)
            rdo.setText(_(q))
            self.buttonGroup_3.addButton(rdo)
            self.buttonGroup_3.setId(rdo, ind)
            self.gridLayout_2.addWidget(rdo, idx, 3, 1, 1)
            spacerItem14 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
            self.gridLayout_2.addItem(spacerItem14, idx+1, 2, 1, 1)
            idx+=2
            
        idx = max(len(qualities), len(versions))*2+2
        self.fix_quality_chb = QtGui.QCheckBox(self)
        self.gridLayout_2.addWidget(self.fix_quality_chb, idx, 1, 1, 1)
        idx += 1
        self.info_quality_lbl = QtGui.QLabel(self)
        self.info_quality_lbl.setText("")
        self.info_quality_lbl.hide()
        self.info_quality_lbl.setObjectName("info_quality_lbl")
        self.gridLayout_2.addWidget(self.info_quality_lbl, idx, 1, 1, 1)
        idx += 1
        self.horizontalLayout_7.addLayout(self.gridLayout_2)
        spacerItem15 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_7.addItem(spacerItem15)
        self.verticalLayout.addLayout(self.horizontalLayout_7)

        self.horizontalLayout_8 = QtGui.QHBoxLayout()
        self.horizontalLayout_8.setObjectName("horizontalLayout_8")
        spacerItem16 = QtGui.QSpacerItem(378, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_8.addItem(spacerItem16)
        self.close_btn = QtGui.QPushButton(self)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("medias/close.png"), QtGui.QIcon.Normal, 
                                        QtGui.QIcon.Off)
        self.close_btn.setIcon(icon)
        self.close_btn.setObjectName("close_btn")
        self.horizontalLayout_8.addWidget(self.close_btn)
        self.verticalLayout.addLayout(self.horizontalLayout_8)
        self.gridLayout_3.addLayout(self.verticalLayout, 0, 0, 1, 1)

        idx = 0
        self.old_sett = obj[4]
        self.update_config()
        self.retranslateUi()
        self.filename_led.textChanged.connect(self.on_edit_filename)
        self.replace_space_chb.stateChanged.connect(self.on_replace_checked)
        self.underscore_rdo.toggled.connect(self.set_separator)
        self.close_btn.clicked.connect(self.close_dialog)
        self.buttonGroup_2.buttonClicked.connect(self.on_quality_changed)
        self.buttonGroup_3.buttonClicked.connect(self.on_version_changed)
        self.fix_quality_chb.stateChanged.connect(self.set_quality_config)
        QtCore.QMetaObject.connectSlotsByName(self)
        self.sep = " "

        try:
            self.filename_led.setText(self.obj[1])
        except:
            self.filename_led.setText(self.obj[0])

        self.update_config()

    def on_replace_checked(self, state):
        self.underscore_rdo.setEnabled(state)
        self.hyphen_rdo.setEnabled(state) 

        if state:
            self.set_separator()

        else:
            self.filename_led.setText(self.obj[0])
            self.sep = " "

    def set_separator(self):
        sep = "" + ("_" if self.underscore_rdo.isChecked() else "-")
        self.filename_led.blockSignals(True)
        self.filename_led.setText(unicode(self.filename_led.text())
                                    .replace(self.sep, sep))
        self.sep = sep
        self.filename_led.blockSignals(False)

    def on_edit_filename(self, txt):
        self.replace_space_chb.blockSignals(True)
        self.replace_space_chb.setChecked(False)
        self.replace_space_chb.blockSignals(False)

    def on_quality_changed(self, idx):
        if not isinstance(idx, int):
            idx = self.buttonGroup_2.id(idx)

        sel_bitrate = self.QUALITIES[idx]
        sel_version = self.VERSIONS[self.buttonGroup_3.checkedId()]

        self.set_quality_version(sel_bitrate,sel_version)            

    def on_version_changed(self, idx):
        if not isinstance(idx, int):
            idx = self.buttonGroup_3.id(idx)

        sel_bitrate = self.QUALITIES[self.buttonGroup_2.checkedId()]
        sel_version = self.VERSIONS[idx]

        self.set_quality_version(sel_bitrate,sel_version)            

    def set_quality_version(self, sel_bitrate, sel_version):
        logger.info("set_quality_version %i %s" % (sel_bitrate,sel_version))
        
        for vidx,version in enumerate(self.VERSIONS):
            check_version = self.buttonGroup_3.button(vidx)
            try:
                stream = self.streams_by_q_version[(sel_bitrate,version)]
                check_version.setVisible(True)
                if version == sel_version:
                    self.obj[3] = stream
                    logger.info("found: %s" % stream)
            except KeyError:
                check_version.setVisible(False)
                if version == sel_version:
                    check_version.setSelected(False)

        self.update_config()

    def set_quality_config(self, state):
        if not state:
            self.obj[4] = self.old_sett

        else:
            self.obj[4] = self.obj[3]

    def update_config(self):
        if self.obj[4] is None:
            return

        self.fix_quality_chb.blockSignals(True)
        if self.obj[3] == self.obj[4]:
            self.fix_quality_chb.setChecked(True)

        else:
            self.fix_quality_chb.setChecked(False)
        self.fix_quality_chb.blockSignals(False)

    def close_dialog(self):
        self.obj[1] = unicode(self.filename_led.text())
        QtCore.QCoreApplication.processEvents()
        self.accept()

    def retranslateUi(self):
        self.setWindowTitle(_("Downloading Parameters"))
        self.title_lbl.setText(_("Downloading configuration"))
        self.filename_lbl.setText(_("File name:"))
        self.replace_space_chb.setText(_("Replace space with:"))
        self.underscore_rdo.setText(_("Underscore"))
        self.hyphen_rdo.setText(_("Hyphen"))
        self.quality_lbl.setText(_("Quality:"))
        for idx,button in enumerate(self.buttonGroup_2.buttons()):
            button.setText(self.lbl_quality(self.QUALITIES[idx]))

        self.version_lbl.setText(_("Version:"))
        for idx,button in enumerate(self.buttonGroup_3.buttons()):
            button.setText(self.lbl_version(self.VERSIONS[idx]))

        self.fix_quality_chb.setText(_('Always use this quality / version'))
        self.close_btn.setText(_("Close"))

    def lbl_quality(self, qual):
        if   qual == 300:
            return _("Low quality (320x200)")
        elif qual == 800:
            return _("Medium quality (720x406)")
        elif qual == 1500:
            return _("Medium+ quality (720x406 with higher bitrate)")
        if qual == 2200:
            return _("High quality (1280x720)")
        else:
            return "Unexpected quality (%i)" % qual

    def lbl_version(self, v):
        if   v == "VA-STA" or v == "VA":
            return _("German version")
        elif v == "VF-STF" or v == "VOF":
            return _("French version")
        elif v == "VF-STMF"  or v == "VOF-STMF":
            return _("Subtitles")
        elif v == "VO-STF":
            return _("Original version")
        else:
            return v

class ArteLiveDownloadingConfig(object):
    def setupUi(self, dial, obj):
        # Dialog for arteLiveWeb
        self.obj = obj
        dial.setObjectName("dial")
        dial.resize(650, 300)
        self.gridLayout_3 = QtGui.QGridLayout(dial)
        self.gridLayout_3.setContentsMargins(4, 2, 4, 4)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.title_lbl = QtGui.QLabel(dial)
        font = QtGui.QFont()
        font.setFamily("DejaVu Sans")
        font.setPointSize(12)
        font.setWeight(75)
        font.setBold(True)
        self.title_lbl.setFont(font)
        self.title_lbl.setAlignment(QtCore.Qt.AlignCenter)
        self.title_lbl.setObjectName("title_lbl")
        self.horizontalLayout.addWidget(self.title_lbl)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.filename_lbl = QtGui.QLabel(dial)
        font = QtGui.QFont()
        font.setFamily("DejaVu Sans")
        font.setWeight(75)
        font.setBold(True)
        self.filename_lbl.setFont(font)
        self.filename_lbl.setObjectName("filename_lbl")
        self.horizontalLayout_2.addWidget(self.filename_lbl)
        spacerItem2 = QtGui.QSpacerItem(40, 17, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem2)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        spacerItem3 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem3)
        self.filename_led = QtGui.QLineEdit(dial)
        self.filename_led.setObjectName("filename_led")
        self.horizontalLayout_3.addWidget(self.filename_led)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        spacerItem4 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem4)
        self.info_name_lbl = QtGui.QLabel(dial)
        self.info_name_lbl.setText("")
        self.info_name_lbl.hide()
        self.info_name_lbl.setObjectName("info_name_lbl")
        self.horizontalLayout_4.addWidget(self.info_name_lbl)
        self.verticalLayout.addLayout(self.horizontalLayout_4)
        self.horizontalLayout_5 = QtGui.QHBoxLayout()
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        spacerItem5 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem5, 0, 0, 1, 1)
        self.replace_space_chb = QtGui.QCheckBox(dial)
        self.replace_space_chb.setObjectName("replace_space_chb")
        self.gridLayout.addWidget(self.replace_space_chb, 0, 1, 1, 1)
        self.underscore_rdo = QtGui.QRadioButton(dial)
        self.underscore_rdo.setChecked(True)
        self.underscore_rdo.setEnabled(False)
        self.underscore_rdo.setObjectName("underscore_rdo")
        self.buttonGroup = QtGui.QButtonGroup(dial)
        self.buttonGroup.setObjectName("buttonGroup")
        self.buttonGroup.addButton(self.underscore_rdo)
        self.gridLayout.addWidget(self.underscore_rdo, 0, 2, 1, 1)
        spacerItem6 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem6, 1, 0, 1, 1)
        spacerItem7 = QtGui.QSpacerItem(118, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem7, 1, 1, 1, 1)
        self.hyphen_rdo = QtGui.QRadioButton(dial)
        self.hyphen_rdo.setEnabled(False)
        self.hyphen_rdo.setObjectName("hyphen_rdo")
        self.buttonGroup.addButton(self.hyphen_rdo)
        self.gridLayout.addWidget(self.hyphen_rdo, 1, 2, 1, 1)
        self.horizontalLayout_5.addLayout(self.gridLayout)
        spacerItem8 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_5.addItem(spacerItem8)
        self.verticalLayout.addLayout(self.horizontalLayout_5)
        self.line = QtGui.QFrame(dial)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName("line")
        self.verticalLayout.addWidget(self.line)
        self.horizontalLayout_6 = QtGui.QHBoxLayout()
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.quality_lbl = QtGui.QLabel(dial)
        font = QtGui.QFont()
        font.setFamily("DejaVu Sans")
        font.setWeight(75)
        font.setBold(True)
        self.quality_lbl.setFont(font)
        self.quality_lbl.setObjectName("quality_lbl")
        self.horizontalLayout_6.addWidget(self.quality_lbl)
        spacerItem9 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_6.addItem(spacerItem9)
        self.verticalLayout.addLayout(self.horizontalLayout_6)
        self.horizontalLayout_7 = QtGui.QHBoxLayout()
        self.horizontalLayout_7.setObjectName("horizontalLayout_7")
        self.gridLayout_2 = QtGui.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        spacerItem10 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem10, 0, 0, 1, 1)
        self.hd_rdo = QtGui.QRadioButton(dial)
        self.hd_rdo.setChecked(True)
        self.hd_rdo.setObjectName("hd_rdo")
        self.buttonGroup_2 = QtGui.QButtonGroup(dial)
        self.buttonGroup_2.setObjectName("buttonGroup_2")
        self.buttonGroup_2.addButton(self.hd_rdo)
        self.gridLayout_2.addWidget(self.hd_rdo, 0, 1, 1, 1)
        spacerItem11 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem11, 1, 0, 1, 1)
        self.sd_rdo = QtGui.QRadioButton(dial)
        self.sd_rdo.setObjectName("sd_rdo")
        self.buttonGroup_2.addButton(self.sd_rdo)
        self.gridLayout_2.addWidget(self.sd_rdo, 1, 1, 1, 1)
        spacerItem12 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem12, 2, 0, 1, 1)
        self.info_quality_lbl = QtGui.QLabel(dial)
        self.info_quality_lbl.setText("")
        self.info_quality_lbl.hide()
        self.info_quality_lbl.setObjectName("info_quality_lbl")
        self.gridLayout_2.addWidget(self.info_quality_lbl, 2, 1, 1, 1)
        self.horizontalLayout_7.addLayout(self.gridLayout_2)
        spacerItem13 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_7.addItem(spacerItem13)
        self.verticalLayout.addLayout(self.horizontalLayout_7)
        self.horizontalLayout_8 = QtGui.QHBoxLayout()
        self.horizontalLayout_8.setObjectName("horizontalLayout_8")
        spacerItem14 = QtGui.QSpacerItem(378, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_8.addItem(spacerItem14)
        self.close_btn = QtGui.QPushButton(dial)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("medias/close.png"), QtGui.QIcon.Normal, 
                                        QtGui.QIcon.Off)
        self.close_btn.setIcon(icon)
        self.close_btn.setObjectName("close_btn")
        self.horizontalLayout_8.addWidget(self.close_btn)
        self.verticalLayout.addLayout(self.horizontalLayout_8)
        self.gridLayout_3.addLayout(self.verticalLayout, 0, 0, 1, 1)

        self.retranslateUi(dial)
        self.filename_led.textChanged.connect(self.on_edit_filename)
        self.replace_space_chb.stateChanged.connect(self.on_replace_checked)
        self.underscore_rdo.toggled.connect(self.set_separator)
        self.close_btn.clicked.connect(self.close_dialog)
        QtCore.QMetaObject.connectSlotsByName(dial)
        self.dial = dial
        self.sep = " "
        try:
            self.filename_led.setText(self.obj.outfile)
        except:
            self.filename_led.setText(self.obj.title)
        if self.obj.quality is not None:
            self.hd_rdo.setChecked(self.obj.quality)

        if "A_EQ" in self.obj.HD:
            self.hd_rdo.setText("400 x 720 ")

        if "A_EQ" in self.obj.SD:
            self.sd_rdo.setText("400 x 720 ")

    def on_replace_checked(self, state):
        self.underscore_rdo.setEnabled(state)
        self.hyphen_rdo.setEnabled(state) 

        if state:
            self.set_separator()

        else:
            self.filename_led.setText(self.obj.title)
            self.sep = " "

    def set_separator(self):
        sep = "" + ("_" if self.underscore_rdo.isChecked() else "-")
        self.filename_led.blockSignals(True)
        self.filename_led.setText(unicode(self.filename_led.text())
                                    .replace(self.sep, sep))
        self.sep = sep
        self.filename_led.blockSignals(False)

    def on_edit_filename(self, txt):
        self.replace_space_chb.blockSignals(True)
        self.replace_space_chb.setChecked(False)
        self.replace_space_chb.blockSignals(False)

    def close_dialog(self):
        self.obj.outfile = unicode(self.filename_led.text())
        self.obj.quality = 0 + self.hd_rdo.isChecked()
        self.dial.accept()

    def retranslateUi(self, dial):
        dial.setWindowTitle(_("Downloading Parameters"))
        self.title_lbl.setText(_("Downloading configuration"))
        self.filename_lbl.setText(_("File name:"))
        self.replace_space_chb.setText(_("Replace space with:"))
        self.underscore_rdo.setText(_("Underscore"))
        self.hyphen_rdo.setText(_("Hyphen"))
        self.quality_lbl.setText(_("Quality:"))
        self.hd_rdo.setText(_("HD Best quality "))
        self.sd_rdo.setText(_("SD Medium quality"))
        self.close_btn.setText(_("Close"))


if __name__ == "__main__":
    import sys
    import json
    if len(sys.argv) == 2:
        allJSON = sys.argv[1]
    else:
        allJSON = "rawALL.json"
    print "Loading %s..." % allJSON
    dct = json.load(open(allJSON, "r"), "UTF-8")
    pl = dct["videoJsonPlayer"]
    vsr = pl["VSR"]
    obj = [pl["VSU"], "toto.flv", vsr, "RTMP_SQ_1", 
                "RTMP_SQ_1"]
    arg = ('Title', 'Filename')
    app = QtGui.QApplication(sys.argv)
    ui = ArtePlusDownloadingConfig(obj)
    ui.show()
    sys.exit(app.exec_())

