# -*- coding: utf-8 -*-

# utils.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2011-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte

import sys
import os
import pickle
import time
import re
import pwd
import subprocess
import platform
import urllib2
import logging
logger = logging.getLogger(__name__)

from PyQt4.QtCore import Qt, QT_VERSION_STR, PYQT_VERSION_STR
from sip import SIP_VERSION_STR

import data

class Utils(object):
    def __init__(self):
        self.root = os.path.dirname(os.path.abspath(__file__))
        self.cfg = None
        self.paths = []
        self.get_common_paths()
        self.config_file = self.paths[1]
        self.is_updated = False

    def get_common_paths(self):
        if not self.paths:
            user = os.path.expanduser("~")
            self.user_fld = os.path.join(user, ".Qarte")
            self.paths.append(self.user_fld)
            self.paths.append(os.path.join(self.user_fld, "config.cfg"))
            self.paths.append(os.path.join(self.user_fld, "livePreviews"))
            self.paths.append(os.path.join(self.user_fld, "plusPreviews"))
            self.paths.append(os.path.join(self.user_fld, "olds.stat"))

        return self.paths

    def get_user_config(self):
        if self.cfg is None:
            self.load_config()

        # New in 1.5.0
        if 'copythumb_plus' not in self.cfg:
            self.cfg['copythumb_plus'] = False

        if 'copythumb_live' not in self.cfg:
            self.cfg['copythumb_live'] = False

        # New in 1.6.0
        pgs = self.cfg['load_pages']
        if len(pgs) < 3:
            self.cfg['load_pages'] = (pgs[0], pgs[1], False)

        try:
            # Removed from the config
            del self.cfg['news']
        except KeyError:
            pass

        # New in 1.8.2
        if not 'quality' in self.cfg:
            self.cfg['quality'] = u'RTMP_MQ_1'

        return self.cfg

    def load_config(self):
        try:
            with open(self.config_file, "r") as objf:
                self.cfg = pickle.load(objf)
        except Exception as why:
            logger.warning("Config file read error: {0} using default."
                            .format(why))
            self.cfg = data.DEFAULT_PREFS
            self.set_default_crontab_mailbox()

    def save_config(self, cfg):
        try:
            with open(self.config_file, "w") as objf:
                pickle.dump(cfg, objf)
        except Exception as why:
            logger.warning("Config file write error: {0}".format(why))

    def set_default_crontab_mailbox(self):
        """Set the path of crontab mail by default.

        Returns:
        '/var/mail/<user name>'
        """
        self.cfg['mailbox'] = self.cfg['mailbox'] + self.get_user()
        return self.cfg['mailbox']

    def get_user(self):
        """Return user name.

        """
        try:
            user = os.getlogin()
        except:
            try:
                user = pwd.getpwuid(os.getuid())[0]
            except:
                return "user"

        return user

    def update_data(self):
        logger.info('Updating')
        lg = self.cfg['lang']
        url = 'http://www.oqapy.eu/releases/livedata'
        updated = os.path.join(self.user_fld, 'livedata.py')
        try:
            content = urllib2.urlopen(url).read()
        except IOError as why:
            logger.info('loading update error: {0}'.format(why))

        else:

            try:
                with open(updated, "w") as outf:
                    outf.write(content)
                logger.info('File {0} saved'.format(updated))
            except IOError as why:
                logger.info('writing update error: {0}'.format(why))

        self.__get_default_data()

    def __get_default_data(self):
        fname = os.path.join(self.user_fld, 'livedata.py')
        self.is_updated = True
        if not os.path.isfile(fname):
            logger.info('updated file not found, use default')
            self.is_updated = False

        else:
            sys.path.append(self.user_fld)
            try:
                import livedata as lvd
            except ImportError, why:
                logger.warning("Unable to import update: {0}".format(why))
                self.is_updated = False

        if self.is_updated:
            t = float(lvd.UPDATED)
            st = time.strftime('%c', time.localtime(t)).decode('utf-8', 'ignore')
            logger.info('The file has been updated at: {0}\n'.format(st))

            self.fr_categories = lvd.FR_CATEGORIES
            self.de_categories = lvd.DE_CATEGORIES
            self.categories = lvd.CATEGORIES
            self.urls_fr = lvd.URLS_FR
            self.urls_de = lvd.URLS_DE

            self.dp = lvd.DataProvider()

        else:
            self.fr_categories = data.FR_CATEGORIES
            self.de_categories = data.DE_CATEGORIES
            self.categories = data.CATEGORIES
            self.urls_fr = data.URLS_FR
            self.urls_de = data.URLS_DE

    def get_extra_data(self, codename):
        if self.is_updated:
            try:
                return self.dp.get_partner(codename)
            except Exception as why:
                logger.warning('updated data not found: {0}'.format(why))
                pass
                
        return False
        

class Versions(object):
    def __init__(self):
        PY_VERSION = sys.version.split()[0]
        PLATFORM = platform.platform()

        try:
            rep = subprocess.Popen(["rtmpdump"], shell=True, 
                                    universal_newlines=True,
                                    stdout = subprocess.PIPE, 
                                    stderr=subprocess.STDOUT)
            line = rep.stdout.readline()
            if "not found" in line:
                RTMPDUMP_VERSION = "RTMPDump not Found !"
            else:
                RTMPDUMP_VERSION = line.split()[1]

        except Exception as why:
            RTMPDUMP_VERSION = "Version error: {0}".format(why)

        self.versions = {u"pltf": PLATFORM,
                        u"qarte": data.VERSION_STR,
                        u"py": PY_VERSION,
                        u"qt": QT_VERSION_STR,
                        u"pyqt": PYQT_VERSION_STR,
                        u"sip": SIP_VERSION_STR,
                        u"rtmp": RTMPDUMP_VERSION}

    def get_versions(self):
        return self.versions

    def get_formatted_versions(self):
        v = self.versions
        frmt = "\nVERSIONS:\n"
        frmt += "{0:>13}: {1}\n".format("Qarte", v["qarte"])
        frmt += "{0:>13}: {1}\n".format("Platform", v["pltf"])
        frmt += "{0:>13}: {1}\n".format("Python", v["py"])
        frmt += "{0:>13}: {1}\n".format("Qt", v["qt"])
        frmt += "{0:>13}: {1}\n".format("PyQt", v["pyqt"])
        frmt += "{0:>13}: {1}\n".format("Sip", v["sip"])
        frmt += "{0:>13}: {1}\n".format("RTMPDump", v["rtmp"])
        return frmt
        
        
if __name__ == '__main__':
    vrs = Versions()
    print vrs.get_formatted_versions()
