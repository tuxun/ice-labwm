# -*- coding: utf-8 -*-

# ui_main.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2011-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Main gui
#
# If issue with theme (Mate, Voyager, ...) see:
# http://wiki.mate-desktop.org/known_issues#qt_apps_not_styled

import os
import gettext
import logging
logger = logging.getLogger(__name__)

import data

from PyQt4 import QtCore, QtGui

from themes import Themes
from about import About
from artelivewebviewer import ArteLiveWebViewer
from VWidgets.vlineedit import VLineEdit
from commonwidgets.horizontalslider import HorizontalSlider

VERSION = data.VERSION
VERSION_STR = data.VERSION_STR

class Ui_MainWindow(object):
    def setupUi(self, MainWindow, main):
        logger.info(u"setup main window")
        MainWindow.setObjectName("MainWindow")
        MainWindow.setWindowTitle("Qarte - {0}".format(VERSION_STR))
        MainWindow.resize(860, 509)
        self.main = main
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayout_3 = QtGui.QGridLayout(self.centralwidget)
        self.gridLayout_3.setContentsMargins(2, 0, 2, 2)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.stackedWidget = QtGui.QStackedWidget(self.centralwidget)
        self.stackedWidget.setObjectName("stackedWidget")

        # arte+7 page
        self.plus_pg = QtGui.QWidget()
        self.plus_pg.setObjectName("plus_pg")
        self.hl_1 = QtGui.QHBoxLayout(self.plus_pg)
        self.hl_1.setMargin(0)
        self.hl_1.setObjectName("hl_1")
        self.splitter = QtGui.QSplitter(self.plus_pg)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.splitter.sizePolicy()
                                        .hasHeightForWidth())
        self.splitter.setSizePolicy(sizePolicy)
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setObjectName("splitter")
        # Preview
        logger.info(u"set page arte+")
        self.widgetview = QtGui.QWidget(self.splitter)
        self.widgetview.setObjectName("widgetview")
        self.viewlayout = QtGui.QVBoxLayout(self.widgetview)
        self.viewlayout.setContentsMargins(0, 0, 0, 0)
        self.viewlayout.setSpacing(2)
        self.preview = ArtePlusPreview(self, MainWindow, self.widgetview)
        self.viewlayout.addWidget(self.preview)
        self.toolLayout = QtGui.QHBoxLayout()
        self.toolLayout.setContentsMargins(6, 2, 6, 2)
        self.flt_lbl = QtGui.QLabel(self.widgetview)
        self.flt_lbl.setText('Filter: ')
        self.toolLayout.addWidget(self.flt_lbl)
        self.filter_led = VLineEdit(self.widgetview)
        #self.filter_led.setResetButton(True)
        self.filter_led.setHistoricButton(True)
        self.filter_led.setCommandButton(True)
        self.filter_led.setInformativeText(_(u'Enter a keyword'))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("medias/magnifier_20x20.png"))
        self.filter_led.set_command_icon(icon)
        self.toolLayout.addWidget(self.filter_led)
        self.showall_btn = QtGui.QToolButton(self.widgetview)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("medias/refresh.png"))
        self.showall_btn.setIcon(icon1)
        self.showall_btn.setIconSize(QtCore.QSize(20, 20))
        self.showall_btn.setEnabled(False)
        self.toolLayout.addWidget(self.showall_btn)
        self.result_lbl = QtGui.QLabel(self.widgetview)
        self.toolLayout.addWidget(self.result_lbl)
        spacerItem11 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.toolLayout.addItem(spacerItem11)
        self.sizer_wdg = HorizontalSlider(self.widgetview)
        self.sizer_wdg.set_range((100, 200))
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("medias/minus_white_20x5.png"))
        self.sizer_wdg.minus.setIcon(icon2)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap("medias/plus_white_20x5.png"))
        self.sizer_wdg.plus.setIcon(icon3)
        self.toolLayout.addWidget(self.sizer_wdg)

        self.viewlayout.addLayout(self.toolLayout)
        # Summarie's editor
        self.layoutWidget = QtGui.QWidget(self.splitter)
        self.layoutWidget.setObjectName("layoutWidget")
        self.hl_6 = QtGui.QHBoxLayout(self.layoutWidget)
        self.hl_6.setSpacing(0)
        self.hl_6.setMargin(0)
        self.hl_6.setObjectName("hl_6")
        self.editor_plus = QtGui.QPlainTextEdit(self.layoutWidget)
        self.editor_plus.setHorizontalScrollBarPolicy(
                                        QtCore.Qt.ScrollBarAlwaysOff)
        self.editor_plus.setObjectName("editor_plus")
        self.hl_6.addWidget(self.editor_plus)
        self.hl_1.addWidget(self.splitter)
        self.vl_5 = QtGui.QVBoxLayout()
        self.vl_5.setObjectName("vl_5")
        # Basket
        logger.info(u"set basket arte+")
        self.basket_plus = Basket(self, self.plus_pg)
        self.basket_plus.setObjectName("basket_plus")
        self.vl_5.addWidget(self.basket_plus)
        # Downloading widgets
        logger.info(u"set dwnld button arte+")
        self.dl_plus_wdg = DownloadingWidgets(self.plus_pg)
        self.dl_plus_wdg.setMaximumSize(QtCore.QSize(300, 16777215))
        self.dl_plus_wdg.setObjectName("dl_plus_wdg")
        self.vl_5.addWidget(self.dl_plus_wdg)
        self.hl_1.addLayout(self.vl_5)
        self.stackedWidget.addWidget(self.plus_pg)

        # arte Live Web
        self.live_pg = QtGui.QWidget()
        self.live_pg.setObjectName("live_pg")
        self.vl_9 = QtGui.QVBoxLayout(self.live_pg)
        self.vl_9.setMargin(0)
        self.vl_9.setObjectName("vl_9")
        logger.info(u"set page arteLive")
        self.viewer = ArteLiveWebViewer(self, self.live_pg)
        self.viewer.setObjectName("viewer")
        self.vl_9.addWidget(self.viewer)
        self.hl_7 = QtGui.QHBoxLayout()
        self.hl_7.setObjectName("hl_7")
        # Categories buttons
        icons = data.ICONS['live']
        self.vl_10 = QtGui.QVBoxLayout()
        self.vl_10.setObjectName("vl_10")
        self.category_wdg = QtGui.QWidget(self.live_pg)
        self.category_wdg.setObjectName("category_wdg")
        self.hl_8 = QtGui.QHBoxLayout(self.category_wdg)
        self.hl_8.setSpacing(0)
        self.hl_8.setMargin(0)
        self.hl_8.setObjectName("hl_8")
        self.hl_9 = QtGui.QHBoxLayout()
        self.hl_9.setSpacing(0)
        self.hl_9.setMargin(0)
        self.hl_9.setObjectName("hl_9")
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.hl_9.addItem(spacerItem1)
        logger.info(u"set categories buttons")
        self.buttons = {}
        self.classic_btn = CategoryButton(0, self, self.live_pg)
        self.classic_btn.set_properties(icons['clsoff'], icons['clson'],
                                        ('Classique', 'Klassik'))
        self.classic_btn.setObjectName("classic_btn")
        self.classic_btn.setEnabled(False)
        self.buttons[self.classic_btn] = ['Classique', 'Klassik', 'fr tip'
                                            'de tip']
        self.hl_9.addWidget(self.classic_btn)
        self.jazz_btn = CategoryButton(1, self, self.live_pg)
        self.jazz_btn.set_properties(icons['jazoff'], icons['jazon'],
                                ('Jazz & Blues', 'Jazz & Blues'))
        self.jazz_btn.setObjectName("jazz_btn")
        self.jazz_btn.setEnabled(False)
        self.buttons[self.jazz_btn] = ['Jazz & Blues', 'Jazz & Blues', 'fr tip'
                                            'de tip']
        self.hl_9.addWidget(self.jazz_btn)
        self.rock_btn = CategoryButton(2, self, self.live_pg)
        self.rock_btn.set_properties(icons['rockoff'], icons['rockon'],
                                ('Pop rock & Electro', 'Pop, Rock, Electro'))
        self.rock_btn.setObjectName("rock_btn")
        self.rock_btn.setEnabled(False)
        self.buttons[self.rock_btn] = ['Pop rock & Electro', 
                                            'Pop, Rock, Electro', 'fr tip'
                                            'de tip']
        self.hl_9.addWidget(self.rock_btn)
        self.theater_btn = CategoryButton(3, self, self.live_pg)
        self.theater_btn.set_properties(icons['thtoff'], icons['thton'],
                                (u'Théâtre & Danse', 'Theater & Tanz'))
        self.theater_btn.setObjectName("theater_btn")
        self.theater_btn.setEnabled(False)
        self.buttons[self.theater_btn] = ['Théâtre & Danse', 'Theater & Tanz', 
                                            'fr tip'
                                            'de tip']
        self.hl_9.addWidget(self.theater_btn)
        self.world_btn = CategoryButton(4, self, self.live_pg)
        self.world_btn.set_properties(icons['wrloff'], icons['wrlon'],
                                ('Musiques du monde', 'World Music'))
        self.world_btn.setEnabled(False)
        self.buttons[self.world_btn] = ['Musiques du monde', 'World Music', 
                                            'fr tip'
                                            'de tip']
        self.world_btn.setObjectName("world_btn")
        self.hl_9.addWidget(self.world_btn)

        self.tracks_btn = CategoryButton(5, self, self.live_pg)
        self.tracks_btn.set_properties(icons['trkoff'], icons['trkon'],
                                ('Tracks', 'Tracks'))
        self.tracks_btn.setEnabled(False)
        self.buttons[self.tracks_btn] = ['Tracks', 'Tracks', 
                                            'fr tip'
                                            'de tip']
        self.tracks_btn.setObjectName("tracks_btn")
        self.hl_9.addWidget(self.tracks_btn)

        self.blogo_btn = CategoryButton(6, self, self.live_pg)
        self.blogo_btn.set_properties(icons['blgoff'], icons['blgon'],
                                (u'La Blogothèque', u'La Blogothèque'))
        self.blogo_btn.setEnabled(False)
        self.buttons[self.blogo_btn] = [u'La Blogothèque', u'La Blogothèque', 
                                            'fr tip'
                                            'de tip']
        self.tracks_btn.setObjectName("blogo_btn")
        self.hl_9.addWidget(self.blogo_btn)


        self.news_btn = CategoryButton(7, self, self.live_pg)
        self.news_btn.set_properties(icons['nwoff'], icons['nwon'],
                                            (u'Nouveautés', u'Neuheiten'))
        self.news_btn.category = 'News', 'News'
        self.news_btn.setEnabled(False)
        self.buttons[self.news_btn] = ['News', 'News', 'fr tip', 'de tip']
        self.news_btn.setObjectName("news_btn")
        self.hl_9.addWidget(self.news_btn)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                            QtGui.QSizePolicy.Minimum)
        self.hl_9.addItem(spacerItem2)
        self.hl_8.addLayout(self.hl_9)
        self.vl_10.addWidget(self.category_wdg)
        # Pitch editor
        self.editor_live = QtGui.QPlainTextEdit(self.live_pg)
        self.editor_live.setHorizontalScrollBarPolicy(
                                            QtCore.Qt.ScrollBarAlwaysOff)
        self.editor_live.setStyleSheet("""background: qlineargradient(
                                        x1: 0, y1: 0, x2: 0, y2: 1,
                                        stop: 0 #FFFFFF, stop: 1 #EDEDED)""")
        self.editor_live.setObjectName("editor_live")
        self.vl_10.addWidget(self.editor_live)
        self.hl_7.addLayout(self.vl_10)
        self.vl_11 = QtGui.QVBoxLayout()
        self.vl_11.setObjectName("vl_11")
        # Viewer's buttons
        self.navigate_wdg = QtGui.QWidget(self.live_pg)
        self.navigate_wdg.setMinimumSize(QtCore.QSize(280, 0))
        self.navigate_wdg.setMaximumSize(QtCore.QSize(280, 16777215))
        self.navigate_wdg.setObjectName("navigate_wdg")
        self.hl_10 = QtGui.QHBoxLayout(self.navigate_wdg)
        self.hl_10.setSpacing(0)
        self.hl_10.setMargin(0)
        self.hl_10.setObjectName("hl_10")
        self.hl_11 = QtGui.QHBoxLayout()
        self.hl_11.setObjectName("hl_11")
        spacerItem3 = QtGui.QSpacerItem(18, 20, QtGui.QSizePolicy.Expanding, 
                                            QtGui.QSizePolicy.Minimum)
        self.hl_11.addItem(spacerItem3)
        self.left_btn = QtGui.QPushButton(self.navigate_wdg)
        self.left_btn.setMinimumSize(QtCore.QSize(45, 35))
        self.left_btn.setMaximumSize(QtCore.QSize(45, 35))
        icon10 = QtGui.QIcon()
        icon10.addPixmap(QtGui.QPixmap("medias/previous_44x30.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.left_btn.setIcon(icon10)
        self.left_btn.setIconSize(QtCore.QSize(45, 35))
        self.left_btn.setFlat(True)
        self.left_btn.setStatusTip(_(u"Previous"))
        self.left_btn.setObjectName("left_btn")
        self.hl_11.addWidget(self.left_btn)
        self.select_btn = QtGui.QPushButton(self.navigate_wdg)
        self.select_btn.setMinimumSize(QtCore.QSize(45, 35))
        self.select_btn.setMaximumSize(QtCore.QSize(45, 35))
        icon11 = QtGui.QIcon()
        icon11.addPixmap(QtGui.QPixmap("medias/add_44x30.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.select_btn.setIcon(icon11)
        self.select_btn.setIconSize(QtCore.QSize(45, 35))
        self.select_btn.setFlat(True)
        self.select_btn.setStatusTip(_(u"Add to download"))
        self.select_btn.setObjectName("select_btn")
        self.hl_11.addWidget(self.select_btn)
        self.right_btn = QtGui.QPushButton(self.navigate_wdg)
        self.right_btn.setMinimumSize(QtCore.QSize(45, 35))
        self.right_btn.setMaximumSize(QtCore.QSize(45, 35))
        icon12 = QtGui.QIcon()
        icon12.addPixmap(QtGui.QPixmap("medias/next_44x30.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.right_btn.setIcon(icon12)
        self.right_btn.setIconSize(QtCore.QSize(45, 35))
        self.right_btn.setFlat(True)
        self.right_btn.setStatusTip(_(u"Next"))
        self.right_btn.setObjectName("right_btn")
        self.hl_11.addWidget(self.right_btn)
        spacerItem4 = QtGui.QSpacerItem(18, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.hl_11.addItem(spacerItem4)
        self.hl_10.addLayout(self.hl_11)
        self.vl_11.addWidget(self.navigate_wdg)
        self.hl_12 = QtGui.QHBoxLayout()
        self.hl_12.setObjectName("hl_12")
        # Basket's buttons
        #logger.info(u"set button's group arteLive")
        #self.live_btns = BasketButtons(self.live_pg)
        #sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, 
                                        #QtGui.QSizePolicy.Preferred)
        #sizePolicy.setHorizontalStretch(0)
        #sizePolicy.setVerticalStretch(0)
        #sizePolicy.setHeightForWidth(self.live_btns.sizePolicy()
                                        #.hasHeightForWidth())
        #self.live_btns.setSizePolicy(sizePolicy)
        #self.live_btns.setMaximumSize(QtCore.QSize(26, 16777215))
        #self.live_btns.setObjectName("live_btns")
        #self.hl_12.addWidget(self.live_btns)
        self.vl_12 = QtGui.QVBoxLayout()
        self.vl_12.setObjectName("vl_12")
        # Basket
        logger.info(u"set basket arteLive")
        self.alw_tbl = ArteLiveWebTable(self, 'live', self.live_pg)
        self.alw_tbl.setObjectName("alw_tbl")
        self.alw_tbl.setMinimumSize(QtCore.QSize(250, 0))
        self.alw_tbl.setMaximumSize(QtCore.QSize(310, 16777215))
        self.alw_tbl.setObjectName("alw_tbl")
        self.vl_12.addWidget(self.alw_tbl)
        # Downloading widgets
        logger.info(u"set dwnld buttons")
        self.dl_live_wdg = DownloadingWidgets(self.live_pg)
        self.dl_live_wdg.setMaximumSize(QtCore.QSize(300, 16777215))
        self.dl_live_wdg.setObjectName("dl_live_wdg")
        self.vl_12.addWidget(self.dl_live_wdg)
        self.hl_12.addLayout(self.vl_12)
        self.vl_11.addLayout(self.hl_12)
        self.hl_7.addLayout(self.vl_11)
        self.vl_9.addLayout(self.hl_7)

        # arte Live extra
        self.extra_pg = QtGui.QWidget()
        self.extra_pg.setObjectName("extra_pg")
        self.vl_20 = QtGui.QVBoxLayout(self.extra_pg)
        self.vl_20.setMargin(0)
        self.vl_20.setObjectName("vl_20")
        logger.info(u"set page arteLive extra")
        self.viewer_2 = ArteLiveWebViewer(self, self.extra_pg)
        self.viewer_2.setObjectName("viewer_2")
        self.vl_20.addWidget(self.viewer_2)
        self.hl_20 = QtGui.QHBoxLayout()
        self.hl_20.setObjectName("hl_20")
        # Categories buttons
        icons = data.ICONS['live']
        self.vl_21 = QtGui.QVBoxLayout()
        self.vl_21.setObjectName("vl_21")
        self.category_2_wdg = QtGui.QWidget(self.extra_pg)
        self.category_2_wdg.setObjectName("category_2_wdg")
        self.hl_21 = QtGui.QHBoxLayout(self.category_2_wdg)
        self.hl_21.setSpacing(0)
        self.hl_21.setMargin(0)
        self.hl_21.setObjectName("hl_21")
        self.hl_22 = QtGui.QHBoxLayout()
        self.hl_22.setSpacing(0)
        self.hl_22.setMargin(0)
        self.hl_22.setObjectName("hl_22")
        spacerItem10 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.hl_22.addItem(spacerItem10)
        logger.info(u"set extra categories buttons")
        self.buttons_2 = {}
        self.introd_btn = CategoryButton(0, self, self.extra_pg)
        self.introd_btn.set_properties(icons['introdoff'], icons['introdon'],
                                        (u'Introducing', u'Introducing'))
        self.introd_btn.setObjectName("introd_btn")
        self.introd_btn.setEnabled(False)
        self.buttons_2[self.introd_btn] = ['introd', 'introd', 'fr tip', 
                                            'de tip']
        self.hl_22.addWidget(self.introd_btn)
        self.rdr_btn = CategoryButton(1, self, self.extra_pg)
        self.rdr_btn.set_properties(icons['rdroff'], icons['rdron'],
                                        (u'La Route du Rock', 
                                        u'La Route du Rock'))
        self.rdr_btn.setObjectName("rdr_btn")
        self.rdr_btn.setEnabled(False)
        self.buttons_2[self.rdr_btn] = ['rdr', 'rdr', 'fr tip', 'de tip']
        self.hl_22.addWidget(self.rdr_btn)
        self.oprf_btn = CategoryButton(2, self, self.extra_pg)
        self.oprf_btn.set_properties(icons['oprfoff'], icons['oprfon'],
                                    (u'Orchestre Philarmonique de Radio France', 
                                    u'Orchestre Philarmonique de Radio France'))
        self.oprf_btn.setObjectName("oprf_btn")
        self.oprf_btn.setEnabled(False)
        self.buttons_2[self.oprf_btn] = ['oprf', 'oprf', 'fr tip', 'de tip']
        self.hl_22.addWidget(self.oprf_btn)
        self.odp_btn = CategoryButton(3, self, self.extra_pg)
        self.odp_btn.set_properties(icons['odpoff'], icons['odpon'],
                                        (u'Orchestre de Paris', 
                                        u'Orchestre de Paris'))
        self.odp_btn.setObjectName("odp_btn")
        self.odp_btn.setEnabled(False)
        self.buttons_2[self.odp_btn] = ['odp', 'odp', 'fr tip', 'de tip']
        self.hl_22.addWidget(self.odp_btn)
        self.cdm_btn = CategoryButton(4, self, self.extra_pg)
        self.cdm_btn.set_properties(icons['cdmoff'], icons['cdmon'],
                                        (u'Cité de la Musique', 
                                        u'Cité de la Musique'))
        self.cdm_btn.setEnabled(False)
        self.buttons_2[self.cdm_btn] = ['cdm', 'cdm', 'fr tip', 'de tip']
        self.cdm_btn.setObjectName("cdm_btn")
        self.hl_22.addWidget(self.cdm_btn)
        self.lounge_btn = CategoryButton(5, self, self.extra_pg)
        self.lounge_btn.set_properties(icons['lngoff'], icons['lngon'],
                                        (u'Arte Lounge', u'Arte Lounge'))
        self.lounge_btn.setEnabled(False)
        self.buttons_2[self.lounge_btn] = ['lounge', 'lounge', 
                                        'fr tip', 'de tip']
        self.lounge_btn.setObjectName("lounge_btn")
        self.hl_22.addWidget(self.lounge_btn)
        self.extra_cmb = QtGui.QComboBox(self.extra_pg)
        self.extra_cmb.setMinimumSize(QtCore.QSize(100, 30))
        self.extra_cmb.setMaximumSize(QtCore.QSize(100, 30))
        self.extra_cmb.view().setMinimumSize(QtCore.QSize(250, 30))
        self.hl_22.addWidget(self.extra_cmb)
        self.festival_cmb = QtGui.QComboBox(self.extra_pg)
        self.festival_cmb.setMaximumSize(QtCore.QSize(100, 30))

        self.festival_cmb.view().setMinimumSize(QtCore.QSize(250, 30))
        self.hl_22.addWidget(self.festival_cmb)
        spacerItem22 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                            QtGui.QSizePolicy.Minimum)
        self.hl_22.addItem(spacerItem22)
        self.hl_21.addLayout(self.hl_22)
        self.vl_21.addWidget(self.category_2_wdg)
        # Pitch editor
        self.editor_extra = QtGui.QPlainTextEdit(self.extra_pg)
        self.editor_extra.setHorizontalScrollBarPolicy(
                                            QtCore.Qt.ScrollBarAlwaysOff)
        self.editor_extra.setStyleSheet("""background: qlineargradient(
                                        x1: 0, y1: 0, x2: 0, y2: 1,
                                        stop: 0 #FFFFFF, stop: 1 #EDEDED)""")
        self.editor_extra.setObjectName("editor_extra")
        self.vl_21.addWidget(self.editor_extra)
        self.hl_20.addLayout(self.vl_21)
        self.vl_22 = QtGui.QVBoxLayout()
        self.vl_22.setObjectName("vl_22")
        # Viewer's buttons
        self.navigate_2_wdg = QtGui.QWidget(self.extra_pg)
        self.navigate_2_wdg.setMinimumSize(QtCore.QSize(280, 0))
        self.navigate_2_wdg.setMaximumSize(QtCore.QSize(280, 16777215))
        self.navigate_2_wdg.setObjectName("navigate_2_wdg")
        self.hl_23 = QtGui.QHBoxLayout(self.navigate_2_wdg)
        self.hl_23.setSpacing(0)
        self.hl_23.setMargin(0)
        self.hl_23.setObjectName("hl_23")
        self.hl_24 = QtGui.QHBoxLayout()
        self.hl_24.setObjectName("hl_24")
        spacerItem3 = QtGui.QSpacerItem(18, 20, QtGui.QSizePolicy.Expanding, 
                                            QtGui.QSizePolicy.Minimum)
        self.hl_24.addItem(spacerItem3)
        self.left_2_btn = QtGui.QPushButton(self.navigate_2_wdg)
        self.left_2_btn.setMinimumSize(QtCore.QSize(45, 35))
        self.left_2_btn.setMaximumSize(QtCore.QSize(45, 35))
        self.left_2_btn.setIcon(icon10)
        self.left_2_btn.setIconSize(QtCore.QSize(45, 35))
        self.left_2_btn.setFlat(True)
        self.left_2_btn.setStatusTip(_(u"Previous"))
        self.left_2_btn.setObjectName("left_2_btn")
        self.hl_24.addWidget(self.left_2_btn)
        self.select_2_btn = QtGui.QPushButton(self.navigate_2_wdg)
        self.select_2_btn.setMinimumSize(QtCore.QSize(45, 35))
        self.select_2_btn.setMaximumSize(QtCore.QSize(45, 35))
        self.select_2_btn.setIcon(icon11)
        self.select_2_btn.setIconSize(QtCore.QSize(45, 35))
        self.select_2_btn.setFlat(True)
        self.select_2_btn.setStatusTip(_(u"Add to download"))
        self.select_2_btn.setObjectName("select_2_btn")
        self.hl_24.addWidget(self.select_2_btn)
        self.right_2_btn = QtGui.QPushButton(self.navigate_2_wdg)
        self.right_2_btn.setMinimumSize(QtCore.QSize(45, 35))
        self.right_2_btn.setMaximumSize(QtCore.QSize(45, 35))
        self.right_2_btn.setIcon(icon12)
        self.right_2_btn.setIconSize(QtCore.QSize(45, 35))
        self.right_2_btn.setFlat(True)
        self.right_2_btn.setStatusTip(_(u"Next"))
        self.right_2_btn.setObjectName("right_2_btn")
        self.hl_24.addWidget(self.right_2_btn)
        spacerItem24 = QtGui.QSpacerItem(18, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.hl_24.addItem(spacerItem24)
        self.hl_23.addLayout(self.hl_24)
        self.vl_22.addWidget(self.navigate_2_wdg)
        self.hl_25 = QtGui.QHBoxLayout()
        self.hl_25.setObjectName("hl_25")
        self.vl_23 = QtGui.QVBoxLayout()
        self.vl_23.setObjectName("vl_23")
        # Basket
        logger.info(u"set basket arteLive extra")
        self.extra_tbl = ArteLiveWebTable(self, 'extra', self.extra_pg)
        self.extra_tbl.setObjectName("extra_tbl")
        self.extra_tbl.setMinimumSize(QtCore.QSize(250, 0))
        self.extra_tbl.setMaximumSize(QtCore.QSize(310, 16777215))
        self.extra_tbl.setObjectName("extra_tbl")
        self.vl_23.addWidget(self.extra_tbl)
        # Downloading widgets
        logger.info(u"set extra dwnld buttons")
        self.dl_extra_wdg = DownloadingWidgets(self.extra_pg)
        self.dl_extra_wdg.setMaximumSize(QtCore.QSize(300, 16777215))
        self.dl_extra_wdg.setObjectName("dl_extra_wdg")
        self.vl_23.addWidget(self.dl_extra_wdg)
        self.hl_25.addLayout(self.vl_23)
        self.vl_22.addLayout(self.hl_25)
        self.hl_20.addLayout(self.vl_22)
        self.vl_20.addLayout(self.hl_20)


        #self.gridLayout_2.addLayout(self.vl_9, 0, 0, 1, 1)
        self.stackedWidget.addWidget(self.live_pg)
        self.stackedWidget.addWidget(self.extra_pg)
        self.gridLayout_3.addWidget(self.stackedWidget, 0, 0, 1, 1)
        MainWindow.setCentralWidget(self.centralwidget)
        logger.info(u"set menu bar")
        self.menubar = QtGui.QMenuBar(MainWindow)
        self.menubar.setObjectName("menubar")
        self.menuArte_7 = QtGui.QMenu(self.menubar)
        self.menuArte_7.setTitle("arte+7")
        self.menuArte_7.setObjectName("menuArte_7")
        self.menuArteLiveWeb = QtGui.QMenu(self.menubar)
        self.menuArteLiveWeb.setObjectName("menuArteLiveWeb")
        self.menuExtra = QtGui.QMenu(self.menubar)
        self.menuExtra.setTitle("Extra")
        self.menuExtra.setObjectName("menuExtra")
        self.menu_Settings = QtGui.QMenu(self.menubar)
        self.menu_Settings.setObjectName("menu_Settings")
        self.menu_Help = QtGui.QMenu(self.menubar)
        self.menu_Help.setObjectName("menu_Help")
        MainWindow.setMenuBar(self.menubar)
        logger.info(u"set status bar")
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        self.statusbar.setStyleSheet("""QStatusBar {background: qlineargradient(
                                        x1: 0, y1: 0, x2: 0, y2: 0.4,
                                        stop: 0 #CCCCCC, stop: 1 #000000);
                                        color: white}""")

        self.form_button = QtGui.QWidget()
        self.form_button.setMinimumSize(QtCore.QSize(300, 20))
        self.form_button.setMaximumSize(QtCore.QSize(300, 20))
        self.grid_button = QtGui.QGridLayout(self.form_button)
        self.grid_button.setMargin(0)
        self.grid_button.setSpacing(0)

        self.frame_button = QtGui.QLabel()
        self.frame_button.setPixmap(QtGui.QPixmap("medias/rectangle.png"))
        self.frame_button.setMinimumSize(QtCore.QSize(200, 20))
        self.frame_button.setMaximumSize(QtCore.QSize(300, 20))

        self.grid_button.addWidget(self.frame_button, 0, 0, 1, 2)
        self.group = QtGui.QButtonGroup(self.form_button)
        self.plus_state_btn = QtGui.QPushButton()
        self.plus_state_btn.setMaximumSize(100, 24)
        self.plus_state_btn.setText("arte+7")
        self.plus_state_btn.setCheckable(True)
        self.plus_state_btn.setChecked(True)
        self.group.addButton(self.plus_state_btn)
        self.grid_button.addWidget(self.plus_state_btn, 0, 0, 1, 1)
        self.live_state_btn = QtGui.QPushButton()
        self.live_state_btn.setMaximumSize(100, 24)
        self.live_state_btn.setText("arte Live Web")
        self.live_state_btn.setCheckable(True)
        self.group.addButton(self.live_state_btn)
        self.grid_button.addWidget(self.live_state_btn, 0, 1, 1, 1)
        self.extra_state_btn = QtGui.QPushButton()
        self.extra_state_btn.setMaximumSize(100, 24)
        self.extra_state_btn.setText("Extras")
        self.extra_state_btn.setCheckable(True)
        self.group.addButton(self.extra_state_btn)
        self.grid_button.addWidget(self.extra_state_btn, 0, 2, 1, 1)
        self.statusbar.addPermanentWidget(self.form_button)
        MainWindow.setStatusBar(self.statusbar)
        logger.info(u"set actions")
        # arte+7
        self.action_Connection = QtGui.QAction(MainWindow)
        self.action_Connection.setObjectName("action_Connection")
        self.action_Download = QtGui.QAction(MainWindow)
        self.action_Download.setEnabled(False)
        self.action_Download.setObjectName("action_Download")
        self.actionC_ancel = QtGui.QAction(MainWindow)
        self.actionC_ancel.setEnabled(False)
        self.actionC_ancel.setObjectName("actionC_ancel")
        self.action_Quit = QtGui.QAction(MainWindow)
        self.action_Quit.setObjectName("action_Quit")
        # arteLiveWeb
        self.actionC_onnection = QtGui.QAction(MainWindow)
        self.actionC_onnection.setObjectName("actionC_onnection")
        self.actionDow_nload = QtGui.QAction(MainWindow)
        self.actionDow_nload.setEnabled(False)
        self.actionDow_nload.setObjectName("actionDow_nload")
        self.actionCanc_el = QtGui.QAction(MainWindow)
        self.actionCanc_el.setEnabled(False)
        self.actionCanc_el.setObjectName("actionCanc_el")
        # Extras
        self.actionConnection = QtGui.QAction(MainWindow)
        self.actionConnection.setObjectName("actionConnection")
        self.actionDownload = QtGui.QAction(MainWindow)
        self.actionDownload.setEnabled(False)
        self.actionDownload.setObjectName("actionDownload")
        self.actionCancel = QtGui.QAction(MainWindow)
        self.actionCancel.setEnabled(False)
        self.actionCancel.setObjectName("actionCancel")
        self.actionCustom = QtGui.QAction(MainWindow)
        self.actionCustom.setObjectName("actionCustom") 
        self.actionD_iffered = QtGui.QAction(MainWindow)
        self.actionD_iffered.setObjectName("actionD_iffered")
        self.actionSe_ttings = QtGui.QAction(MainWindow)
        self.actionSe_ttings.setObjectName("actionSe_ttings")
        self.action_About = QtGui.QAction(MainWindow)
        self.action_About.setObjectName("action_About")
        self.menuArte_7.addAction(self.action_Connection)
        self.menuArte_7.addSeparator()
        self.menuArte_7.addAction(self.action_Download)
        self.menuArte_7.addAction(self.actionC_ancel)
        self.menuArte_7.addSeparator()
        self.menuArte_7.addAction(self.action_Quit)
        self.menuArteLiveWeb.addAction(self.actionC_onnection)
        self.menuArteLiveWeb.addSeparator()
        self.menuArteLiveWeb.addAction(self.actionDow_nload)
        self.menuArteLiveWeb.addAction(self.actionCanc_el)
        self.menuExtra.addAction(self.actionConnection)
        self.menuExtra.addSeparator()
        self.menuExtra.addAction(self.actionDownload)
        self.menuExtra.addAction(self.actionCancel)
        self.menuExtra.addAction(self.actionCustom)
        self.menu_Settings.addAction(self.actionD_iffered)
        self.menu_Settings.addAction(self.actionSe_ttings)
        self.menu_Help.addAction(self.action_About)
        self.menubar.addAction(self.menuArte_7.menuAction())
        self.menubar.addAction(self.menuArteLiveWeb.menuAction())
        self.menubar.addAction(self.menuExtra.menuAction())
        self.menubar.addAction(self.menu_Settings.menuAction())
        self.menubar.addAction(self.menu_Help.menuAction())

        logger.info(u"make connections")
        self.action_Connection.triggered.connect(self.main.reload_artePlus)
        self.action_Download.triggered.connect(self.main.download_plus)
        self.actionC_ancel.triggered.connect(self.main.cancel_plus)
        self.action_Quit.triggered.connect(self.main.close_event)
        self.actionC_onnection.triggered.connect(self.main.reload_arteLive)
        self.actionDow_nload.triggered.connect(self.main.download_live)
        self.actionCanc_el.triggered.connect(self.main.cancel_live)
        self.actionConnection.triggered.connect(self.main.reload_extras)
        self.actionDownload.triggered.connect(self.main.download_extra)
        self.actionCancel.triggered.connect(self.main.cancel_extra)
        self.actionCustom.triggered.connect(self.main.on_custom_clicked)
        self.actionD_iffered.triggered.connect(self.main.set_differed_tasks)
        self.actionSe_ttings.triggered.connect(self.main.edit_settings)
        self.action_About.triggered.connect(self.about)

        self.retranslateUi(MainWindow)
        logger.info(u"set theme")
        self.set_theme()

        self.festival_cmb.setEnabled(False)
        self.extra_cmb.setEnabled(False)

        self.stackedWidget.setCurrentIndex(0)
        self.plus_state_btn.clicked.connect(self.show_plus_page)
        self.live_state_btn.clicked.connect(self.show_live_page)
        self.extra_state_btn.clicked.connect(self.show_extra_page)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.mwin = MainWindow

        MainWindow.show()
        QtCore.QCoreApplication.processEvents()
        logger.info(u"main window complete")
        self.set_busy_cursor(True)
        # Resize the splitter
        h, h1 = self.splitter.sizes()[0], self.splitter.sizes()[1]
        r = int((h + h1) / 5)
        self.splitter.setSizes([r * 4, r])

    def show_plus_page(self):
        self.stackedWidget.setCurrentIndex(0)
        self.set_page_button_style()
        self.plus_state_btn.setStyleSheet(self.theme.siteButtonActive_style)

    def show_live_page(self):
        self.stackedWidget.setCurrentIndex(1)
        self.set_page_button_style()
        self.live_state_btn.setStyleSheet(self.theme.siteButtonActive_style)

    def show_extra_page(self):
        self.stackedWidget.setCurrentIndex(2)
        self.set_page_button_style()
        self.extra_state_btn.setStyleSheet(self.theme.siteButtonActive_style)

    def enable_button(self, btn):
        for k in self.buttons.keys():
            if btn in self.buttons[k]:
                k.setEnabled(True)

    def set_page_button_style(self):
        self.plus_state_btn.setStyleSheet(self.theme.siteButton_style)
        self.live_state_btn.setStyleSheet(self.theme.siteButton_style)
        self.extra_state_btn.setStyleSheet(self.theme.siteButton_style)

    def set_toggled_button(self, cat):
        for k in self.buttons.keys():
            if cat in self.buttons[k]:
                k.set_current(True)
            else:
                k.set_current(False)
        
    def enable_button_2(self, btn):
        for k in self.buttons_2.keys():
            if btn in self.buttons_2[k]:
                k.setEnabled(True)

    def set_toggled_button_2(self, cat):
        for k in self.buttons_2.keys():
            if cat in self.buttons_2[k]:
                k.set_current(True)
            else:
                k.set_current(False)

    def about(self):
        v = About(VERSION_STR)

    def set_busy_cursor(self, b):
        if b:
            self.mwin.setCursor(QtCore.Qt.BusyCursor)
        else:
            self.mwin.setCursor(QtCore.Qt.ArrowCursor)

    def retranslateUi(self, MainWindow):
        self.showall_btn.setStatusTip(
                                _("Show all videos"))
        self.menuArte_7.setTitle(_("&arte+7"))
        self.menuArteLiveWeb.setTitle(_("arte&LiveWeb"))
        self.menuExtra.setTitle(_("&Extra"))
        self.menu_Settings.setTitle(_("&Settings"))
        self.menu_Help.setTitle(_("&Help"))
        self.action_Connection.setText(_("&Connection"))
        self.action_Download.setText(_("&Download"))
        self.actionC_ancel.setText(_("C&ancel"))
        self.actionConnection.setText(_("&Connection"))
        self.actionDownload.setText(_("&Download"))
        self.actionCancel.setText(_("C&ancel"))
        self.actionCustom.setText(_("Custom searching"))
        self.action_Quit.setText(_("&Quit"))
        self.actionC_onnection.setText(_("C&onnection"))
        self.actionDow_nload.setText(_("Dow&nload"))
        self.actionCanc_el.setText(_("Canc&el"))
        self.actionD_iffered.setText(_("D&iffered download"))
        self.actionSe_ttings.setText(_("Se&ttings"))
        self.action_About.setText(_("&About"))

    def set_theme(self):
        self.theme = Themes(self)
        self.theme.set_theme_dark()
        #self.centralwidget
        self.stackedWidget.setStyleSheet(self.theme.baseWidget_style)
        self.plus_pg.setStyleSheet(self.theme.baseWidget_style)
        self.filter_led.setStyleSheet(self.theme.lineEdit_style)
        self.filter_led.informative_text.setStyleSheet(self.theme.label_style)
        self.filter_led.command_button.setStyleSheet("QToolButton {background: transparent;}")
        self.filter_led.historic_button.setStyleSheet("""QToolButton {background: transparent;
                                                            color: #000000}""")
        self.showall_btn.setStyleSheet(self.theme.toolButton_style)
        self.sizer_wdg.minus.setStyleSheet(self.theme.toolButton_style)
        self.sizer_wdg.slider.setStyleSheet(self.theme.slider_style)
        self.sizer_wdg.plus.setStyleSheet(self.theme.toolButton_style)
        #self.splitter
        self.preview.setStyleSheet(self.theme.viewerPlus_style)
        self.preview.verticalScrollBar().setStyleSheet(self.theme.scrollBar_V_style)
        self.editor_plus.setStyleSheet(self.theme.plainTextEdit_style)
        self.editor_plus.verticalScrollBar().setStyleSheet(self.theme.scrollBar_V_style)
        #self.plus_btns
        self.basket_plus.setStyleSheet(self.theme.basketLive_style)
        self.basket_plus.verticalScrollBar().setStyleSheet(self.theme.scrollBar_V_style)
        #self.dl_plus_wdg
        self.dl_plus_wdg.dwnld_btn.setStyleSheet(self.theme.dwnlButton_style)
        self.dl_plus_wdg.cancel_btn.setStyleSheet(self.theme.dwnlButton_style)
        self.live_pg.setStyleSheet(self.theme.baseWidget_style)
        self.viewer.setStyleSheet(self.theme.viewer_style)
        self.viewer.verticalScrollBar().setStyleSheet(self.theme.scrollBar_V_style)
        self.extra_cmb.setStyleSheet(self.theme.comboBox_style)
        self.festival_cmb.setStyleSheet(self.theme.comboBox_style)
        self.editor_live.setStyleSheet(self.theme.plainTextEdit_style)
        self.editor_live.verticalScrollBar().setStyleSheet(self.theme.scrollBar_V_style)
        self.editor_extra.setStyleSheet(self.theme.plainTextEdit_style)
        self.editor_extra.verticalScrollBar().setStyleSheet(self.theme.scrollBar_V_style)
        self.alw_tbl.setStyleSheet(self.theme.basketLive_style)
        self.alw_tbl.verticalScrollBar().setStyleSheet(self.theme.scrollBar_V_style)
        self.extra_tbl.setStyleSheet(self.theme.basketLive_style)
        self.extra_tbl.verticalScrollBar().setStyleSheet(self.theme.scrollBar_V_style)
        #self.dl_live_wdg
        self.dl_live_wdg.dwnld_btn.setStyleSheet(self.theme.dwnlButton_style)
        self.dl_live_wdg.cancel_btn.setStyleSheet(self.theme.dwnlButton_style)
        #self.menubar
        self.statusbar.setStyleSheet(self.theme.statusBar_style)
        self.plus_state_btn.setStyleSheet(self.theme.siteButtonActive_style)
        self.live_state_btn.setStyleSheet(self.theme.siteButton_style)
        self.extra_state_btn.setStyleSheet(self.theme.siteButton_style)
        self.menuArte_7.setStyleSheet(self.theme.menu_style)
        self.menuArteLiveWeb.setStyleSheet(self.theme.menu_style)
        self.menu_Settings.setStyleSheet(self.theme.menu_style)
        self.menu_Help.setStyleSheet(self.theme.menu_style)
        self.menu_style = self.theme.menu_style


class ArtePlusPreview(QtGui.QListWidget):
    itemDragged = QtCore.pyqtSignal(int)
    def __init__(self, ui, mw, parent=None):
        super(ArtePlusPreview, self).__init__(parent)
        self.ui = ui
        self.main = ui.main
        self.mw = mw
        self.setDragEnabled(True)
        self.setDragDropMode(QtGui.QAbstractItemView.DragDrop)
        self.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.setIconSize(QtCore.QSize(160, 160))
        self.setFlow(QtGui.QListView.LeftToRight)
        self.setViewMode(QtGui.QListView.IconMode)
        #self.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.itemSelectionChanged.connect(self.selection_changed)

    def startDrag(self, event):
        it = self.itemAt(event.pos())
        if not it:
            return
        idx = self.main.apl.items.index(it)

        mimeData = QtCore.QMimeData()
        mimeData.setText('new %s' % str(idx))

        drag = QtGui.QDrag(self)
        drag.setMimeData(mimeData)
        pixmap = QtGui.QPixmap(self.main.apl.thumbnails[idx]).scaled(
                                    QtCore.QSize(200, 110))
        drag.setPixmap(pixmap)
        drag.setHotSpot(QtCore.QPoint(pixmap.width()/2, pixmap.height()))
        drag.setPixmap(pixmap)
        result = drag.start(QtCore.Qt.MoveAction)
        self.itemDragged.emit(idx)

    def mouseMoveEvent(self, event):
        self.startDrag(event)
        event.accept()

    def mousePressEvent(self, event):
        item = self.itemAt(event.pos())
        if not item:
            self.clearSelection()
            event.accept()

        elif event.button() == 1:
            item.setSelected(True)
            self.main.apl.on_item_selected(self.main.apl.items.index(item))
            event.accept()

        else:
            event.ignore()

    def contextMenuEvent(self, event):
        item = self.itemAt(event.pos())
        if item is not None:
            item.show_context_menu(event.globalPos())
        event.accept()

    def mouseDoubleClickEvent(self, event):
        if self.itemAt(event.pos()):
            self.move_item(self.itemAt(event.pos()))
            event.accept()
        else:
            event.ignore()

    def resizeEvent(self, event):
        s = self.spacing()
        self.setSpacing(s)
        self.updateGeometries()
        w, h = self.mw.size().width(), self.mw.size().height()
        self.main.cfg["size"] = (w, h)
        event.ignore()

    def set_scrolling_value2(self):
        self.verticalScrollBar().setRange(0, self.viewport().height())
        self.verticalScrollBar().setPageStep(self.viewport().height()/8)

    def selection_changed(self):
        if self.selectedItems():
            self.main.apl.show_pitch()

    def move_item(self, item):
        """Item in preview windows has double-clicked.

        When an item in preview has double-clicked, he's moved to
        download basket.

        Args:
        item -- item double-clicked
        """
        idx = self.main.apl.items.index(item)
        self.ui.basket_plus.add_object(idx)

class Basket(QtGui.QTableWidget):
    itemAdded = QtCore.pyqtSignal(int)
    def __init__(self, ui, parent=None):
        super(Basket, self).__init__(parent)
        self.ui = ui
        self.main = ui.main
        self.lst_movies = []
        self.setMaximumSize(QtCore.QSize(300, 16777215))
        self.setShowGrid(False)
        self.setDragEnabled(True)
        self.setDragDropMode(QtGui.QAbstractItemView.InternalMove)
        self.setDefaultDropAction(QtCore.Qt.CopyAction)
        self.setDropIndicatorShown(True)
        self.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.verticalHeader().hide()
        self.horizontalHeader().hide()
        self.setIconSize(QtCore.QSize(85, 48))
        self.setColumnCount(4)
        self.setColumnWidth(0, 80)
        self.setColumnWidth(1, 165)
        self.setColumnWidth(2, 24)
        self.setColumnWidth(3, 24)

    def mousePressEvent(self, event):
        self.idx = False
        mod = QtGui.QApplication.keyboardModifiers()
        idx = self.indexAt(event.pos())
        btn = event.button()
        if btn == 1 and not idx.isValid():
            self.clearSelection()

        elif btn == 1 and idx.isValid():
            self.idx = idx

        QtGui.QTableWidget.mousePressEvent(self, event)

    def mouseMoveEvent(self, event):
        if self.idx:
            # Don't move the item 0 if is loading
            if not self.idx.row() and self.main.apl.is_loading:
                return

            self.startDrag(event)

    def startDrag(self, event):
        index = self.indexAt(event.pos())
        mimeData = QtCore.QMimeData()
        mimeData.setText("video")
        drag = QtGui.QDrag(self)
        drag.setMimeData(mimeData)
        pixmap = QtGui.QPixmap()
        pixmap = self.item(index.row(), 0).icon().pixmap(80, 60, 
                                                        QtGui.QIcon.Normal, 
                                                        QtGui.QIcon.Off)
        drag.setPixmap(pixmap)
        drag.setHotSpot(QtCore.QPoint(pixmap.width()/2, pixmap.height()))
        drag.setPixmap(pixmap)
        result = drag.start(QtCore.Qt.MoveAction)
        event.accept()

    def dragEnterEvent(self, event):
        if event.mimeData().hasText():
            event.accept()

        else:
            event.ignore()

    def dragMoveEvent(self, event):
        idx = self.indexAt(event.pos())
        if idx.isValid() and event.mimeData().hasText():
            event.setDropAction(QtCore.Qt.MoveAction)
            self.highlight_item(self.indexAt(event.pos()))

        elif str(event.mimeData().text()).startswith('new'):
            event.setDropAction(QtCore.Qt.MoveAction)

        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        pass

    def dropEvent(self, event):
        idx = self.indexAt(event.pos())
        if not event.mimeData().hasText():
            event.ignore()
            return

        data = str(event.mimeData().text())
        if data == "video" and idx.isValid() and idx != self.idx:
            self.move_item_to(self.idx.row(), idx.row())

        elif data.startswith('new'):
            self.add_object(int(data.split(' ')[1]))

    def move_item_to(self, src, dest):
        if not dest and self.main.apl.is_loading:
            # Don't shift the item 0 if is loading
            if src == 1:
                return

            dest == 1

        ic = self.item(src, 0).icon()
        txt = self.item(src, 1).text()
        video = self.remove_item(src)
        self.insertRow(dest)
        self.setRowHeight(dest, 48)
        item = QtGui.QTableWidgetItem()
        item.setIcon(ic)
        self.setItem(dest, 0, item)
        item = QtGui.QTableWidgetItem()
        item.setText(txt)
        self.setItem(dest, 1, item)
        item = TableButton(dest, 'settings', self)
        self.setCellWidget(dest, 2, item)
        item = TableButton(dest, 'remove', self)
        self.setCellWidget(dest, 3, item)

        self.update_buttons()
        self.lst_movies.insert(dest, video)

    def remove_item(self, row):
        """Remove one item from table and from list.

        """
        self.removeRow(row)
        video = self.lst_movies.pop(row)

        self.clearSelection()
        self.update_buttons()
        if not self.rowCount():
            self.ui.dl_plus_wdg.dwnld_btn.setEnabled(False)
            self.ui.action_Download.setEnabled(False)

        return video

    def print_titles(self):
        """Debugging function"""
        for v in self.lst_movies:
            print v.title

    def highlight_item(self, idx):
        self.clearSelection()
        self.selectionModel().setCurrentIndex(idx, 
                                QtGui.QItemSelectionModel.Select)

    def update_buttons(self):
        for r in range(self.rowCount()):
            self.cellWidget(r, 2).row_ = r
            self.cellWidget(r, 3).row_ = r

    def config_download(self, idx):
        self.main.apl.config_downloading(idx)

    def add_object(self, idx):
        """Add a video into the basket.

        Args:
        idx -- index of video
        """
        video = self.main.apl.videos[idx]

        if video in self.lst_movies:
            self.ui.preview.clearSelection()
            return

        def send_signal():
            self.itemAdded.emit(idx)

        img = video.preview
        text = self.format_text(video.title)
        r = self.rowCount()
        self.insertRow(r)
        self.setRowHeight(r, 48) 
        item = QtGui.QTableWidgetItem()
        item.setIcon(QtGui.QIcon(img))
        self.setItem(r, 0, item)
        item = QtGui.QTableWidgetItem()
        item.setText(text)
        self.setItem(r, 1, item)
        item = TableButton(r, 'settings', self)
        self.setCellWidget(r, 2, item)
        item = TableButton(r, 'remove', self)
        self.setCellWidget(r, 3, item)

        self.lst_movies.append(video)
        QtCore.QCoreApplication.processEvents()
        self.ui.dl_plus_wdg.dwnld_btn.setEnabled(True)
        self.ui.action_Download.setEnabled(True)
        self.ui.preview.clearSelection()
        timer = QtCore.QTimer()
        timer.singleShot(300, send_signal)
        timer.start()

    def rename(self, row, txt):
        """Rename an item.

        Args:
        row -- row
        txt -- new name
        """
        self.item(row, 1).setText(txt)

    def format_text(self, txt):
        """Format the movie's title.

        Args:
        txt -- title

        Returns:
        Formated text
        """
        if len(txt) < 31:
            return txt

        form = ""
        while 1:
            chain = txt[:31]
            count = len(chain) - 1
            while 1:
                if chain[count]  in [" ", "_", "-"]:
                    break

                count -= 1
                if count == 0:
                    count = len(chain) - 1
                    break

            form = form + chain[:count] + "\n"
            txt = txt[count+1:]
            if not txt:
                break

            elif len(txt) < 31:
                form = form + txt + "\n"
                break

        return form[:-1]

    def disable_settings(self):
        """Disable the settings and remove buttons for the video that is 
            downloading.

        """
        self.cellWidget(0, 2).setEnabled(False)
        self.cellWidget(0, 3).setEnabled(False)


class TableButton(QtGui.QToolButton):
    def __init__(self, row, feature, parent=None):
        super(TableButton, self).__init__()
        self.row_ = row
        self.feature = feature
        self.table = parent
        self.setIconSize(QtCore.QSize(20, 20))
        self.set_icon()
        self.clicked.connect(self.send_signal)
        self.setStyleSheet("""
                QToolButton {background-color: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #FFFFFF, stop: 0.4 #FAFAFA,
                    stop: 0.5 #FDFDFD, stop: 1.0 #F0F0F0);
                    border-radius: 4px;
                    padding: 2px;}
                QToolButton:hover {border: 2px solid #CC1D00;}
                QToolButton:pressed {background-color: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #000000, stop: 0.4 #050505,
                    stop: 0.5 #606060, stop: 1.0 #101010);}""")

    def set_icon(self):
        icon = QtGui.QIcon()
        if self.feature == 'settings':
            pix = QtGui.QPixmap('medias/settings.png')
        else:
            pix = QtGui.QPixmap('medias/list-remove.png')
        icon.addPixmap(pix, QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.setIcon(icon)

    def send_signal(self, b):
        if self.feature == 'remove':
            self.table.remove_item(self.row_)
        else:
            self.table.config_download(self.row_)


class ArteLiveWebTable(QtGui.QTableWidget):
    """Arte Live Web and partners downloading basket.

    """
    itemSelected  = QtCore.pyqtSignal(int)
    unselectAll = QtCore.pyqtSignal()
    onLastItemRemoved = QtCore.pyqtSignal()
    def __init__(self, ui, driver, parent):
        super(ArteLiveWebTable, self).__init__(parent)
        self.ui = ui
        self.main = ui.main
        self.driver = driver
        self.setMaximumSize(QtCore.QSize(300, 16777215))
        self.setDragEnabled(True)
        self.setDragDropMode(QtGui.QAbstractItemView.InternalMove)
        self.setDefaultDropAction(QtCore.Qt.CopyAction)
        self.setDropIndicatorShown(True)
        self.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.setAlternatingRowColors(True)
        self.setShowGrid(False)
        self.setIconSize(QtCore.QSize(85, 48))
        self.setColumnCount(4)
        self.setRowCount(0)
        self.setColumnWidth(0, 80)
        self.setColumnWidth(1, 165)
        self.setColumnWidth(2, 24)
        self.setColumnWidth(3, 24)
        self.horizontalHeader().hide()
        self.verticalHeader().hide()
        self.horizontalHeader().setStretchLastSection(True)
        self.cellClicked.connect(self.on_cell_activated)
        self.itemSelectionChanged.connect(self.set_selection)

    def add_item(self, item, img):
        img = self.get_pixmap(img)
        r = self.rowCount()
        self.insertRow(r)
        self.setRowHeight(r, 48)  
        pix = QtGui.QPixmap(img)
        icon = QtGui.QIcon()
        icon.addPixmap(pix, QtGui.QIcon.Normal, QtGui.QIcon.Off)
        obj = QtGui.QTableWidgetItem()
        obj.setIcon(icon)
        self.setItem(r, 0, obj)
        obj = QtGui.QTableWidgetItem()
        obj.setText(item.title)
        self.setItem(r, 1, obj)
        item = TableButton(r, 'settings', self)
        self.setCellWidget(r, 2, item)
        item = TableButton(r, 'remove', self)
        self.setCellWidget(r, 3, item)
        #self.selectRow(r)

    def get_pixmap(self, px):
        if isinstance(px, QtGui.QPixmap):
            return px

        if os.path.isfile(px):
            return QtGui.QPixmap(px)

        else:
            return QtGui.QPixmap("medias/noPreview_2.png")

    def rename_item(self, idx, new):
        item = self.item(idx, 1)
        item.setText(self.format_text(new))

    def remove_item(self, idx):
        if self.driver == 'live':
            self.main.alw.remove_item_from_basket(idx)

        else:
            self.main.aex.remove_item_from_basket(idx)

    def replace_item(self, orig, dest):
        drv = self.main.aex
        if self.driver == 'live':
            drv = self.main.alw

        vid = drv.to_download.pop(orig)
        drv.to_download.insert(dest, vid)

    def delete_item(self, idx):
        self.removeRow(idx)
        self.clearSelection()
        self.update_buttons()
        if not self.rowCount():
            self.onLastItemRemoved.emit()

    def move_up_selection(self):
        """Move selected item one level up.

        """
        sel = self.selectedItems()
        if not sel:
            return

        row = self.selectedItems()[0].row()
        if row == 0:
            return

        icon = sel[0].icon()
        txt = sel[1].text()
        self.removeRow(row)
        self.insertRow(row-1)
        self.setRowHeight(row-1, 48)
        obj = QtGui.QTableWidgetItem()
        obj.setIcon(icon)
        self.setItem(row-1, 0, obj)
        obj = QtGui.QTableWidgetItem()
        obj.setText(txt)
        self.setItem(row-1, 1, obj)
        self.selectRow(row-1)

    def move_down_selection(self):
        """Move selected item one level up.

        """
        sel = self.selectedItems()
        if not sel:
            return

        row = self.selectedItems()[0].row()
        if row == self.rowCount() - 1:
            return

        icon = sel[0].icon()
        txt = sel[1].text()
        self.removeRow(row)
        self.insertRow(row+1)
        self.setRowHeight(row+1, 48)
        obj = QtGui.QTableWidgetItem()
        obj.setIcon(icon)
        self.setItem(row+1, 0, obj)
        obj = QtGui.QTableWidgetItem()
        obj.setText(txt)
        self.setItem(row+1, 1, obj)
        self.selectRow(row+1)

    def mousePressEvent(self, event):
        self.idx = False
        mod = QtGui.QApplication.keyboardModifiers()
        idx = self.indexAt(event.pos())
        btn = event.button()
        if btn == 1 and not idx.isValid():
            self.clearSelection()

        elif btn == 1 and idx.isValid():
            self.idx = idx

        QtGui.QTableWidget.mousePressEvent(self, event)

    def is_movable(self, idx):
        if self.driver == 'live':
            load = self.main.alw.is_loading
        else:
            load = self.main.aex.is_loading
        # Don't move the item 0 if is loading
        if not idx.row() and load:
            return False

        return True

    def mouseMoveEvent(self, event):
        if self.idx and self.is_movable(self.idx):
            self.startDrag(event)

    def startDrag(self, event):
        index = self.indexAt(event.pos())
        mimeData = QtCore.QMimeData()
        mimeData.setText("video")
        drag = QtGui.QDrag(self)
        drag.setMimeData(mimeData)
        pixmap = QtGui.QPixmap()
        pixmap = self.item(index.row(), 0).icon().pixmap(80, 60, 
                                                        QtGui.QIcon.Normal, 
                                                        QtGui.QIcon.Off)
        drag.setPixmap(pixmap)
        drag.setHotSpot(QtCore.QPoint(pixmap.width()/2, pixmap.height()))
        drag.setPixmap(pixmap)
        result = drag.start(QtCore.Qt.MoveAction)
        event.accept()

    def dragEnterEvent(self, event):
        if event.mimeData().hasText():
            event.accept()

        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasText():
            event.setDropAction(QtCore.Qt.MoveAction)
            self.highlight_item(self.indexAt(event.pos()))
            event.accept()

        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        pass

    def dropEvent(self, event):
        idx = self.indexAt(event.pos())
        if not event.mimeData().hasText():
            event.ignore()
            return

        data = event.mimeData().text()
        if str(data) == "video" and idx.isValid() and idx != self.idx:
            self.move_item_to(self.idx.row(), idx)

    def move_item_to(self, src, idx):
        dest = idx.row()
        if not self.is_movable(idx):
            # Don't shift the item 0 if is loading
            if src == 1:
                return

            dest == 1

        ic = self.item(src, 0).icon()
        txt = self.item(src, 1).text()
        self.delete_item(src)
        self.insertRow(dest)
        self.setRowHeight(dest, 48)
        item = QtGui.QTableWidgetItem()
        item.setIcon(ic)
        self.setItem(dest, 0, item)
        item = QtGui.QTableWidgetItem()
        item.setText(txt)
        self.setItem(dest, 1, item)
        item = TableButton(dest, 'settings', self)
        self.setCellWidget(dest, 2, item)
        item = TableButton(dest, 'remove', self)
        self.setCellWidget(dest, 3, item)

        self.update_buttons()
        self.replace_item(src, dest)

    def set_selection(self):
        if not self.selectedItems():
            self.unselectAll.emit()

        else:
            self.itemSelected.emit(self.selectedItems()[0].row())

    def on_cell_activated(self, row, col):
        self.selectRow(row)
        self.itemSelected.emit(row)

    def format_text(self, txt):
        """Format the movie's title.

        Args:
        txt -- title

        Returns:
        Formated text
        """
        if len(txt) < 31:
            return txt

        form = ""
        while 1:
            chain = txt[:31]
            count = len(chain) - 1
            while 1:
                if chain[count] in [" ", "_", "-"]:
                    break

                count -= 1
                if count == 0:
                    count = len(chain) - 1
                    break

            form = form + chain[:count] + "\n"
            txt = txt[count+1:]
            if not txt:
                break

            elif len(txt) < 31:
                form = form + txt + "\n"
                break

        return form[:-1]

    def highlight_item(self, idx):
        self.clearSelection()
        self.selectionModel().setCurrentIndex(idx, 
                                QtGui.QItemSelectionModel.Select)

    def update_buttons(self):
        for r in range(self.rowCount()):
            self.cellWidget(r, 2).row_ = r
            self.cellWidget(r, 3).row_ = r

    def config_download(self, idx):
        if self.driver == 'live':
            self.main.alw.config_downloading(idx)
        else:
            self.main.aex.config_downloading(idx)

    def disable_settings(self):
        """Disable the settings and remove buttons for the video that is 
            downloading.

        """
        self.cellWidget(0, 2).setEnabled(False)
        self.cellWidget(0, 3).setEnabled(False)

    def print_list(self, lst):
        """Debugging function"""
        for v in lst:
            print v.title

class BasketButtons(QtGui.QWidget):
    def __init__(self, ui, parent=None):
        super(BasketButtons, self).__init__(parent)
        self.vl = QtGui.QVBoxLayout(self)
        self.vl.setSpacing(0)
        self.vl.setMargin(0)
        self.vl_1 = QtGui.QVBoxLayout()
        self.vl_1.setObjectName("verticalLayout_9")
        self.vl_1.setSpacing(0)
        self.vl_1.setMargin(0)
        self.param_btn = QtGui.QPushButton(self)
        self.param_btn.setMinimumSize(QtCore.QSize(26, 28))
        self.param_btn.setMaximumSize(QtCore.QSize(26, 28))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("medias/download_sett_26x28.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.param_btn.setIcon(icon)
        self.param_btn.setIconSize(QtCore.QSize(26, 28))
        self.param_btn.setFlat(True)
        self.param_btn.setEnabled(False)
        self.param_btn.setObjectName("param_btn")
        self.vl_1.addWidget(self.param_btn)
        self.remove_btn = QtGui.QPushButton(self)
        self.remove_btn.setMinimumSize(QtCore.QSize(26, 28))
        self.remove_btn.setMaximumSize(QtCore.QSize(26, 28))
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("medias/remove_26x28.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.remove_btn.setIcon(icon1)
        self.remove_btn.setIconSize(QtCore.QSize(26, 28))
        self.remove_btn.setFlat(True)
        self.remove_btn.setEnabled(False)
        self.remove_btn.setObjectName("remove_btn")
        self.vl_1.addWidget(self.remove_btn)
        self.moveup_btn = QtGui.QPushButton(self)
        self.moveup_btn.setMinimumSize(QtCore.QSize(26, 28))
        self.moveup_btn.setMaximumSize(QtCore.QSize(26, 28))
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("medias/up_26x28.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.moveup_btn.setIcon(icon2)
        self.moveup_btn.setIconSize(QtCore.QSize(26, 28))
        self.moveup_btn.setFlat(True)
        self.moveup_btn.setEnabled(False)
        self.moveup_btn.setObjectName("moveup_btn")
        self.vl_1.addWidget(self.moveup_btn)
        self.movedown_btn = QtGui.QPushButton(self)
        self.movedown_btn.setMinimumSize(QtCore.QSize(26, 28))
        self.movedown_btn.setMaximumSize(QtCore.QSize(26, 28))
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap("medias/down_26x28.png"), 
                                        QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.movedown_btn.setIcon(icon3)
        self.movedown_btn.setIconSize(QtCore.QSize(26, 28))
        self.movedown_btn.setFlat(True)
        self.movedown_btn.setEnabled(False)
        self.movedown_btn.setObjectName("movedown_btn")
        self.vl_1.addWidget(self.movedown_btn)
        spacerItem4 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, 
                                        QtGui.QSizePolicy.Expanding)
        self.vl_1.addItem(spacerItem4)
        self.vl.addLayout(self.vl_1)


class CategoryButton(QtGui.QPushButton):
    triggered  = QtCore.pyqtSignal(tuple)
    def __init__(self, idx, ui, parent=None):
        super(CategoryButton, self).__init__(parent)
        dct = dict(idx = idx,
                    ic_off = QtGui.QIcon(),
                    ic_on = QtGui.QIcon(),
                    category = None,
                    de_tip = None,
                    fr_tip = None,
                    is_current = False)
        for key, value in dct.iteritems():
            setattr(self, key, value)
        self.ui = ui
        self.setMinimumSize(QtCore.QSize(60, 30))
        self.setMaximumSize(QtCore.QSize(60, 30))
        self.setFlat(True)
        self.setCheckable(True)
        self.clicked.connect(self.on_clicked)

    def set_properties(self, *prop):
        self.set_icons(prop[0], prop[1])
        self.category = prop[2]
        self.fr_tip = prop[2][0]
        self.de_tip = prop[2][1]
        self.setStatusTip(u"{0} - {1}".format(self.fr_tip, self.de_tip))

    def set_icons(self, off, on):
        self.ic_off.addPixmap(QtGui.QPixmap(off), 
                                QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.setIcon(self.ic_off)
        self.setIconSize(QtCore.QSize(62, 37))
        self.ic_on.addPixmap(QtGui.QPixmap(on), 
                                QtGui.QIcon.Normal, QtGui.QIcon.Off)

    def set_current(self, b):
        if b:
            self.setIcon(self.ic_on)
            self.is_current = True

        else:
            self.setIcon(self.ic_off)
            self.is_current = False

    def enterEvent(self, event):
        return
        self.ui.statusbar.showMessage(u"{0} - {1}"
                                        .format(self.fr_tip, self.de_tip))

    def leaveEvent(self, event):
        return

    def on_clicked(self):
        if not self.is_current:
            self.triggered.emit(self.category)

    def update_icon(self):
        if self.is_current:
            self.setIcon(self.ic_off)
            self.is_current = False
        else:
            self.setIcon(self.ic_on)
            self.is_current = True

class DownloadingWidgets(QtGui.QWidget):
    def __init__(self, parent=None):
        super(DownloadingWidgets, self).__init__(parent)
        self.setMaximumSize(QtCore.QSize(300, 16777215))
        self.vl_13 = QtGui.QVBoxLayout(self)
        self.vl_13.setContentsMargins(2, 0, 2, 2)
        self.vl_13.setSpacing(2)
        self.hl_13 = QtGui.QHBoxLayout()
        self.hl_13.setSpacing(0)
        self.dwnld_btn = QtGui.QPushButton(self)
        self.dwnld_btn.setMinimumSize(QtCore.QSize(50, 40))
        self.dwnld_btn.setMaximumSize(QtCore.QSize(50, 40))
        self.dwnld_btn.setStyleSheet("QPushButton:hover" 
                                            "{border: 2px solid #9900FF;}")
        self.dwnld_btn.setStatusTip(_(u"Download"))
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap("medias/download_44x30.png"), 
                                            QtGui.QIcon.Normal, 
                                            QtGui.QIcon.Off)
        self.dwnld_btn.setIcon(icon4)
        self.dwnld_btn.setIconSize(QtCore.QSize(44, 30))
        self.dwnld_btn.setFlat(True)
        self.dwnld_btn.setEnabled(False)
        self.dwnld_btn.setObjectName("dwnld_btn")
        self.hl_13.addWidget(self.dwnld_btn)
        self.progressBar = QtGui.QProgressBar(self)
        self.progressBar.setProperty("value", 0)
        self.progressBar.setMinimumSize(QtCore.QSize(100, 32))
        self.progressBar.setObjectName("progressBar")
        self.hl_13.addWidget(self.progressBar)
        self.cancel_btn = QtGui.QPushButton(self)
        self.cancel_btn.setMinimumSize(QtCore.QSize(50, 40))
        self.cancel_btn.setMaximumSize(QtCore.QSize(50, 40))
        self.cancel_btn.setStyleSheet("""QPushButton:hover 
                                            {border: 2px solid #9900FF;}""")
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap("medias/stop_44x30.png"), 
                                            QtGui.QIcon.Normal, 
                                            QtGui.QIcon.Off)
        self.cancel_btn.setIcon(icon5)
        self.cancel_btn.setIconSize(QtCore.QSize(44, 30))
        self.cancel_btn.setShortcut("Ctrl+S")
        self.cancel_btn.setFlat(True)
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setStatusTip(_(u"Cancel download"))
        self.cancel_btn.setObjectName("cancel_btn")
        self.hl_13.addWidget(self.cancel_btn)
        self.vl_13.addLayout(self.hl_13)
        self.progress_lbl = QtGui.QLabel(self)
        self.progress_lbl.setAlignment(QtCore.Qt.AlignCenter)
        self.progress_lbl.setText("")
        self.progress_lbl.setObjectName("progress_lbl")
        self.vl_13.addWidget(self.progress_lbl)
        self.progress_lbl2 = QtGui.QLabel(self)
        self.progress_lbl2.setAlignment(QtCore.Qt.AlignCenter)
        self.progress_lbl2.setText("")
        self.progress_lbl2.setObjectName("progress_lbl2")
        self.vl_13.addWidget(self.progress_lbl2)


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    MainWindow = QtGui.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

