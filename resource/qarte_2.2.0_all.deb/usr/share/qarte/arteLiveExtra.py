# -*- coding: utf-8 -*-

# arteLiveExtra.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2012-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Arte Live Web extra main class

import os, re
import time
import datetime
import shutil
import urllib2
import sys
import pickle
import logging
logger = logging.getLogger(__name__)

try:
    import pynotify
    NOTIFY = True
except:
    NOTIFY = False

from threading import Thread, current_thread
from threading import enumerate as enumerate_

from PyQt4 import QtCore, QtGui

import data

from parsers import ExtraParser, VideoItem
from loaders import LiveLoader, RateCounter
from dwnlConfig import ArteLiveDownloadingConfig
from ui_custom import CustomSearch
from utils import Utils

class ArteLiveExtra(object):
    """Main class of Arte Live Web partner's page handler.

    """
    def __init__(self, main):
        """Instanciate the main class of arteLiveExtra.

        """
        self.main = main
        self.ui = main.ui
        self.utils = main.utils
        self.exui = main.ui.extra_pg
        self.viewer = main.ui.viewer_2
        self.viewer.al = self
        self.cfg = main.cfg
        self.prev_fld = main.prev_fld
        self.dwlnd_fld = self.cfg['live_folder']
        self.lang = self.cfg['lang']
        self.cur_category = 0
        self.cur_hall = 0
        self.cur_festival = 0
        self.to_download = []
        self.summaries = []
        self.is_loading = False
        self.cur_in_basket = None
        self.lld = None
        self.viewer.prev_fld = self.prev_fld
        self.viewer.cfg = self.cfg
        self.__set_connections()

        if self.utils.is_updated:
            self.partners = self.utils.get_extra_data('partners')
            self.categories = self.utils.get_extra_data('ext_cat')
            self.halls = self.utils.get_extra_data('halls')[self.lang]
            self.festivals = self.utils.get_extra_data('festivals')[self.lang]

        else:
            self.partners = data.PARTNERS
            self.categories = data.EXT_CATEGORIES
            self.halls = data.HALLS[self.lang]
            self.festivals = data.FESTIVALS[self.lang]

        self.ui.extra_cmb.addItem('More...')
        for c in sorted(self.halls.keys()):
            self.ui.extra_cmb.addItem(c)

        self.ui.festival_cmb.addItem('Festivals')
        for c in sorted(self.festivals.keys()):
            self.ui.festival_cmb.addItem(c)

        self.videos = {'introd': {},
                        'rdr': {},
                        'oprf': {},
                        'odp': {},
                        'cdm': {},
                        'lounge': {}}

        if not 'pitch_extra' in self.cfg:
            self.cfg['pitch_extra'] = False

        self.ep = ExtraParser(self)
        self.ep.loadingCategoryFinished.connect(self.update_category)

    def get_pages(self):
        """Get the predifined pages.

        Predifined pages are the page wich have her own button.
        """
        self.count = 0
        for site in self.videos.keys():
            logger.info('Get extra page {0}'.format(site))
            self.ep.read_partner(site)

        self.ui.set_toggled_button_2('introd')
        self.viewer.show_category(self.videos['introd'])

    def update_category(self, cat):
        """Called when the page parser has finished to read a category page.

        Args:
        cat -- category
        """
        cat = str(cat)
        logger.info('set category videos {0}'.format(cat))
        self.count += 1
        if self.count > len(self.categories[self.lang]):
            # category 'halls' or 'festivals'
            self.viewer.show_category(self.videos[cat])
            return

        if len(self.videos[cat]):
            self.ui.enable_button_2(cat)

        if self.count == len(self.categories[self.lang]) - 1:
            self.ui.set_toggled_button_2('introd')
            logger.info('parsing extra videos finished')
            self.ui.festival_cmb.setEnabled(True)
            self.ui.extra_cmb.setEnabled(True)

    def show_category(self, cat):
        """Shows preview items in the viewer area.

        """
        cat = str(cat)
        self.remove_duplicate(cat)
        self.viewer.show_category(self.videos[cat])
        self.ui.enable_button_2(cat)

    def change_category(self, cat):
        """Called when user change category.

        Args:
        cat -- category
        """
        c = self.categories['fr'][cat[0]]

        if self.lang == 'de':
            c = self.categories['de'][cat[1]]

        self.cur_category = c
        self.ui.set_toggled_button_2(c)
        self.viewer.setFocus()
        self.show_category(c)
        self.reset_extra_combo(0)
        self.reset_festival_combo(0)

    def on_extra_changed(self, idx):
        """Called when the user change the item in the 'More' comboBox.

        Args:
        idx -- index of the item
        """
        if idx == 0:
            self.reset_extra_combo(self.cur_hall)
            return

        self.ui.set_toggled_button_2('nihil')
        cat = sorted(self.halls.keys())[idx-1]
        codename = self.halls[cat]
        if not codename in self.videos:
            logger.info('Get extra page {0}'.format(cat))
            self.ep.read_partner(codename)

        else:
            self.viewer.show_category(self.videos[codename])

        self.reset_festival_combo(0)

    def reset_extra_combo(self, idx):
        self.ui.extra_cmb.blockSignals(True)
        self.ui.extra_cmb.setCurrentIndex(idx)
        self.ui.extra_cmb.blockSignals(False)

    def on_festival_changed(self, idx):
        """Called when the user change the item in the 'Festivals' comboBox.

        Args:
        idx -- index of the item
        """
        if idx == 0:
            self.reset_festival_combo(self.cur_festival)
            return

        self.ui.set_toggled_button_2('nihil')
        fest = sorted(self.festivals.keys())[idx-1]
        codename = self.festivals[fest]
        if not codename in self.videos:
            logger.info('Get extra page {0}'.format(fest))
            self.ep.read_partner(codename)

        else:
            self.viewer.show_category(self.videos[codename])

        self.reset_extra_combo(0)

    def reset_festival_combo(self, idx):
        self.ui.festival_cmb.blockSignals(True)
        self.ui.festival_cmb.setCurrentIndex(idx)
        self.ui.festival_cmb.blockSignals(False)

    def show_pitch(self, item):
        """Called when the current item in the viewer has changed.

        """
        title = item.title
        date = item.date
        pitch = item.pitch
        self.update_pitch(title, date, pitch)

    def update_pitch(self, *args):
        """Show the pitch of the current item.

        """

        self.ui.editor_extra.clear()
        font = QtGui.QFont("sans", 10)
        c_form = QtGui.QTextCharFormat()
        c_form.setFont(font)
        font1 = QtGui.QFont("sans", 12)
        font1.setWeight(75)
        c_form1 = QtGui.QTextCharFormat()
        c_form1.setFont(font1)
        self.ui.editor_extra.setCurrentCharFormat(c_form1)
        self.ui.editor_extra.appendPlainText(args[0])
        self.ui.editor_extra.setCurrentCharFormat(c_form) 
        self.ui.editor_extra.appendPlainText(args[1])
        self.ui.editor_extra.appendPlainText("")
        self.ui.editor_extra.appendHtml(args[2])
        self.ui.editor_extra.verticalScrollBar().setValue(0)

    def __set_connections(self):
        self.ui.introd_btn.triggered.connect(self.change_category)
        self.ui.rdr_btn.triggered.connect(self.change_category)
        self.ui.oprf_btn.triggered.connect(self.change_category)
        self.ui.odp_btn.triggered.connect(self.change_category)
        self.ui.cdm_btn.triggered.connect(self.change_category)
        self.ui.lounge_btn.triggered.connect(self.change_category)
        self.ui.left_2_btn.clicked.connect(self.viewer.shift_to_previous)
        self.ui.right_2_btn.clicked.connect(self.viewer.shift_to_next)
        self.ui.select_2_btn.pressed.connect(self.select_video_to_download)
        #self.ui.extra_btns.param_btn.clicked.connect(self.config_downloading)
        #self.ui.extra_btns.remove_btn.clicked.connect(
        #                                        self.remove_item_from_basket)
        #self.ui.extra_btns.moveup_btn.clicked.connect(self.move_up_item)
        #self.ui.extra_btns.movedown_btn.clicked.connect(self.move_down_item)
        self.ui.dl_extra_wdg.dwnld_btn.clicked.connect(self.fetch_video)
        self.ui.dl_extra_wdg.cancel_btn.clicked.connect(self.abort_loading)
        self.ui.extra_tbl.itemSelected.connect(self.on_table_selection_changed)
        self.ui.extra_tbl.unselectAll.connect(self.on_table_unselect)
        self.ui.extra_tbl.onLastItemRemoved.connect(self.on_table_empty)
        self.ui.extra_cmb.currentIndexChanged.connect(self.on_extra_changed)
        self.ui.festival_cmb.currentIndexChanged.connect(
                                                self.on_festival_changed)

    def build_items(self, name, dct):
        self.videos[name] = {}
        for key, value in dct.items():
            self.videos[name][key] = VideoItem(name, value)

    def remove_duplicate(self, cat):
        """Remove the videos which are already in the Arte Live Web page.

        Args:
        cat -- category name
        """
        if cat in ['introd', 'rdr']:
            name = u'Pop rock & Electro'
            if self.lang == 'de':
                name = u'Pop, Rock, Electro'

        else:
            return

        other = self.main.alw.videos[name]

        for item in other.keys():
            if item in self.videos[cat]:
                del self.videos[cat][item]

    def on_thumbnail_selected(self, item):
        # Check if video is already in the downloading basket
        self.ui.select_2_btn.setEnabled(not item in self.to_download)
        # and if already available
        self.ui.select_2_btn.setEnabled(not item.soon)

    def get_personal_link(self):
        """Call Custom video search dialog box.

        """ 
        self.cst = CustomSearch(self)

    def set_personal_video(self, item, thumb):
        """Set a video found into the custom search dialog box.

        Args:
        item -- dict(video desc)
        thumb -- full path of the thumbnail (~/.Qarte/xyz.jpg)
        """
        video = VideoItem('custom', item)

        logger.info(u"Append item {0} to download basket".format(video.order))
        prop = self.get_stream_properties(video)
        if prop is None:
            logger.warning(u"No stream URLs found, item rejected")
            return

        self.to_download.append(video)
        self.ui.extra_tbl.add_item(video, thumb)
        self.ui.select_2_btn.setEnabled(False)
        self.ui.dl_extra_wdg.dwnld_btn.setEnabled(True)
        self.ui.actionDownload.setEnabled(True)


    #==============================================
    # QTableWidget functions
    #==============================================
    def select_video_to_download(self, idx=None):
        """Select a video for the downloading basket.

        Args:
        idx -- index of video if called by a double click on a item
        """
        if idx is None:
            idx = self.viewer.current

        else:
            self.viewer.go_to_item(idx)

        vid = self.viewer.videos_items[idx]
        if vid in self.to_download:
            return

        logger.info(u"Append item {0} to download basket".format(vid.order))
        prop = self.get_stream_properties(vid)
        if prop is None:
            logger.warning(u"No stream URLs found, item rejected")
            return

        self.to_download.append(vid)
        self.ui.extra_tbl.add_item(vid, self.viewer.previews[idx].img)
        self.ui.select_2_btn.setEnabled(False)
        self.ui.dl_extra_wdg.dwnld_btn.setEnabled(True)
        self.ui.actionDownload.setEnabled(True)
        self.append_summary_to_download()

    def remove_item_from_basket(self, idx=None):
        """Called if user remove an item from downloading basket or when
        a downloading is complete.

        idx -- index of item
        """
        if idx == 'first':
            idx = 0

        elif idx is None:
            idx = self.get_current_item_index()

        self.ui.extra_tbl.delete_item(idx)
        self.to_download.pop(idx)

    def move_up_item(self):
        """Move an item to up one level.

        """
        idx = self.get_current_item_index()
        if idx is not None:
            self.to_download.insert(idx-1, self.to_download.pop(idx))

        self.ui.extra_tbl.move_up_selection()

    def move_down_item(self):
        """Move down an item.

        """
        idx = self.get_current_item_index()
        if idx is not None:
            self.to_download.insert(idx+1, self.to_download.pop(idx))

        self.ui.extra_tbl.move_down_selection()

    def on_table_selection_changed(self, idx):
        logger.info('Selection changed: {0}'.format(idx))
        self.cur_in_basket = self.to_download[idx]
        self.set_basket_buttons_enabled(True)

        #if idx == 0:
            #self.ui.extra_btns.moveup_btn.setEnabled(False)

        #if idx == self.ui.extra_tbl.rowCount() - 1:
            #self.ui.extra_btns.movedown_btn.setEnabled(False)

    def on_table_unselect(self):
        self.cur_in_basket = None
        self.set_basket_buttons_enabled(False)

    def on_table_empty(self):
        """Called when last item in table has been removed.

        """
        self.ui.dl_extra_wdg.dwnld_btn.setEnabled(False)
        self.ui.actionDownload.setEnabled(False)
        self.ui.dl_extra_wdg.cancel_btn.setEnabled(False)
        self.ui.actionCancel.setEnabled(False)

    def get_current_item_index(self):
        """Return the selected item index in the table.

        """
        item = self.cur_in_basket
        if item is not None:
            return self.to_download.index(item)

        return None

    def config_downloading(self, idx):
        """Call the downloading setting dialog box.

        """
        video = self.to_download[idx]

        dial = QtGui.QDialog()
        gui = ArteLiveDownloadingConfig()
        gui.setupUi(dial, video)
        dial.exec_()
        self.ui.extra_tbl.rename_item(idx, video.outfile)

    def append_summary_to_download(self):
        self.summaries.append(unicode(self.ui.editor_live.toPlainText()))

    def get_stream_properties(self, movie):
        """Get stream links.

        Args:
        movie -- VideoItem instance
        """
        links = self.ep.get_links(movie.order)
        movie.HD = links['HD']
        movie.SD = links['SD']
        movie.Live = links['Live']

        if movie.HD is not None:
            movie.quality = 1

        elif vid.SD is not None:
            movie.quality = 0

        else:
            self.main.show_warning(5, "Undefined")
            movie.quality = None
            return None

        return movie

    #==========================================================
    # Downloading
    #==========================================================
    def fetch_video(self):
        """Set parameters for downloading.

        To avoid encoding problem, the target name is build with
        the actual time and the file will be renamed when
        the downloading is finished.
        """
        tmp = os.path.join(self.dwlnd_fld, self.get_temp_filename())

        if self.to_download[0].outfile is None:
            self.to_download[0].outfile = self.to_download[0].title

        logger.info(u"Downloading request, title: {0}"
                        .format(self.to_download[0].title))
        logger.info(u"Temp file:{0}".format(tmp))
        fname = self.format_file_name(self.to_download[0].outfile)
        self.name_to_notify = fname
        dest = os.path.join(self.dwlnd_fld, fname)
        dest += ".flv"
        self.last_loaded = False

        if self.to_download[0].quality is None:
            url = self.to_download[0].Live

        elif self.to_download[0].quality:
            url = self.to_download[0].HD

        else:
            url = self.to_download[0].SD

        if url is None:
            # Should not appears, but bug
            return

        self.rcount = RateCounter(self, tmp)
        self.lld = LiveLoader(self)
        self.lld.loadProgress.connect(self.show_progress)
        self.lld.loadComplete.connect(self.on_loading_finished)
        self.lld.set_url(url)
        self.lld.set_target(tmp)
        self.lld.set_destination(dest)
        self.is_loading = True
        self.ui.extra_tbl.disable_settings()

        def run_load():
            self.lld.load()

        Thread(target=run_load).start()
        self.enable_download_buttons(True)

    def abort_loading(self):
        """Called when user cancel the current downloading.

        """
        logger.info(u"Downloading cancelled by user")
        if self.lld is not None:
            self.lld.kill_request = True

    def on_loading_finished(self, err):
        """Called when download is finished or cancelled.

        """
        item = self.to_download[0]
        self.ui.dl_extra_wdg.progressBar.setValue(0)
        self.enable_download_buttons(False)
        self.remove_item_from_basket('first')

        if not err:
            logger.info(u"Download complete")
            if self.cfg['notify']:
                self.notify()

            if self.cfg['pitch_live']:
                self.save_pitch()

            if self.cfg['copythumb_live']:
                self.copy_thumbnail(item)

        self.is_loading = False

    def show_progress(self, val):
        if int(val) != self.ui.dl_extra_wdg.progressBar.value():
            self.ui.dl_extra_wdg.progressBar.setValue(val)

            if not int(val) % 3:
                rate, rem = self.rcount.counter(val)
                self.ui.dl_extra_wdg.progress_lbl.setText(rate)
                self.ui.dl_extra_wdg.progress_lbl2.setText(rem)

    def format_file_name(self, name):
        """Remove from the file name characters wich may cause problem.

        Args:
        name -- basename file

        Returns:
        Cleaned file name 
        """
        try:
            for c in [u'»', u'«', u'/', u'\\', u'"']:
                name = name.replace(c, "_")
        except:
            pass

        return name

    def get_temp_filename(self):
        """Create a temporary file name with time()

        Returns:
        filename like 'alw123456789...'
        """
        d = str(time.time()).replace(".", "")
        t = "".join(["alw", d, ".flv"])
        count = 1

        while 1:
            target = os.path.join(self.dwlnd_fld, t)
            if os.path.isfile(target):
                t = "".join(["alw", d, str(count), ".flv"])
                count += 1
            else:
                break

        return t

    def enable_download_buttons(self, b):
        """Enable download and cancel buttons when downloading is called or
        is finished.

        Args:
        b -- boolean
        """
        self.ui.dl_extra_wdg.dwnld_btn.setEnabled(not b)
        self.ui.actionDownload.setEnabled(not b)
        self.ui.dl_extra_wdg.cancel_btn.setEnabled(b)
        self.ui.actionCancel.setEnabled(b)

    def save_pitch(self):
        if self.cfg['pitch_live_unique']:
            f = os.path.join(self.dwlnd_fld, "index")

        else:
            f = os.path.join(self.dwlnd_fld, self.name_to_notify[:-4])

        p = self.summaries.pop(0)
        p += u"\n\n"

        try:
            with open(f, "a") as objf:
                objf.write(p.encode('utf8', 'ignore'))
        except Exception, why:
            self.main.show_warning(4, why)

    def copy_thumbnail(self, item):
        """Place a copy of the video thumbnail into the downloading folder.

        This feature is useful for some medias server wich have an option
        'use sameNameAsVideo.jpg' for populate "cover art".

        Args:
        item -- ItemVideo instance
        """
        if not self.last_loaded:
            return

        try:
            thumb = os.path.join(self.prev_fld, item.preview)
            name = os.path.join(self.dwlnd_fld, self.last_loaded[:-4] + '.jpg')
        except Exception as why:
            logger.warning(u'Copy thumbnail error: {0}'.format(why))
            return

        logger.info('Copy thumbnail {0}'.format(name))
        try:
            shutil.copy(thumb, name)
        except Exception as why:
            logger.warning(u'Copy error: {0}'.format(why))

    #===========================================================

    def download_later(self, idx):
        """Call differed download dialog.

        Args:
        idx -- video's index
        """
        logger.info('Call differed downloading dialog, item: %s' % idx)
        v = self.viewer.videos_items[idx]
        video = self.get_stream_properties(v)
        if video is None:
            return

        self.viewer.go_to_item(idx)
        video.pitch = unicode(self.ui.editor_live.toPlainText())
        self.main.set_differed_tasks(video)

    #===========================================================

    def set_basket_buttons_enabled(self, b):
        return
        self.ui.extra_btns.param_btn.setEnabled(b)
        self.ui.extra_btns.remove_btn.setEnabled(b)
        self.ui.extra_btns.moveup_btn.setEnabled(b)
        self.ui.extra_btns.movedown_btn.setEnabled(b)

    def update_button(self):
        pass

    def on_page_failed(self, stage, msg):
        pass

    def notify(self):
        """Show GTK notification.

        Arguments :
        t -- title of video
        """
        if not NOTIFY:
            return
        img_uri = os.path.join(os.getcwd(), "medias/qarte_logo.png")
        pynotify.init("arteLiveWeb")
        notification = pynotify.Notification(self.name_to_notify,
                                             "Download complete", img_uri)
        notification.show()
