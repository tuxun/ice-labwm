# -*- coding: utf-8 -*-

# ui_config.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2011-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Configuration gui

import sys
import os
import pickle
import gettext

from PyQt4 import QtCore, QtGui

import data
from themes import Themes

class Settings(object):
    def setupUi(self, Setting, main):
        self.cfg = main.cfg
        self.main = main
        Setting.setObjectName("Settings")
        Setting.resize(662, 536)
        Setting.setSizeGripEnabled(True)
        self.gridLayout = QtGui.QGridLayout(Setting)
        self.gridLayout.setMargin(6)
        self.gridLayout.setObjectName("gridLayout")
        self.verticalLayout_8 = QtGui.QVBoxLayout()
        self.verticalLayout_8.setSpacing(12)
        self.verticalLayout_8.setObjectName("verticalLayout_8")
        self.verticalLayout_5 = QtGui.QVBoxLayout()
        self.verticalLayout_5.setSpacing(2)
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.horizontalLayout.setSpacing(10)
        self.start_lbl = QtGui.QLabel(Setting)
        self.start_lbl.setObjectName("start_lbl")
        self.horizontalLayout.addWidget(self.start_lbl)
        self.lang_cmb = QtGui.QComboBox(Setting)
        self.lang_cmb.setMinimumSize(120, 25)
        self.lang_cmb.addItems([u"Français", u"Deutsch"])
        self.lang_cmb.setObjectName("lang_cmb")
        self.horizontalLayout.addWidget(self.lang_cmb)
        self.load_plus_chb = QtGui.QCheckBox(Setting)
        self.load_plus_chb.setText(u"arte+7")
        self.load_plus_chb.setChecked(True)
        self.load_plus_chb.setObjectName("load_plus_chb")
        self.horizontalLayout.addWidget(self.load_plus_chb)
        self.load_live_chb = QtGui.QCheckBox(Setting)
        self.load_live_chb.setText(u"arte Live Web")
        self.load_live_chb.setChecked(True)
        self.load_live_chb.setObjectName("load_live_chb")
        self.horizontalLayout.addWidget(self.load_live_chb)
        spacerItem = QtGui.QSpacerItem(40, 13, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout_5.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.notify_chb = QtGui.QCheckBox(Setting)
        self.notify_chb.setChecked(True)
        self.notify_chb.setObjectName("notify_chb")
        self.horizontalLayout_2.addWidget(self.notify_chb)
        spacerItem1 = QtGui.QSpacerItem(40, 13, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem1)
        self.verticalLayout_5.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_18 = QtGui.QHBoxLayout()
        self.horizontalLayout_18.setObjectName("horizontalLayout_18")
        self.mail_lbl = QtGui.QLabel(Setting)
        self.mail_lbl.setObjectName("mail_lbl")
        self.horizontalLayout_18.addWidget(self.mail_lbl)
        self.mail_led = QtGui.QLineEdit(Setting)
        self.mail_led.setMinimumSize(QtCore.QSize(300, 0))
        self.mail_led.setObjectName("mail_led")
        self.horizontalLayout_18.addWidget(self.mail_led)
        self.browse_2_btn = QtGui.QPushButton(Setting)
        self.browse_2_btn.setObjectName("browse_2_btn")
        self.horizontalLayout_18.addWidget(self.browse_2_btn)
        self.verticalLayout_5.addLayout(self.horizontalLayout_18)
        self.verticalLayout_8.addLayout(self.verticalLayout_5)
        self.line_2 = QtGui.QFrame(Setting)
        self.line_2.setFrameShape(QtGui.QFrame.HLine)
        self.line_2.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.verticalLayout_8.addWidget(self.line_2)
        self.verticalLayout_6 = QtGui.QVBoxLayout()
        self.verticalLayout_6.setSpacing(2)
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.logo_0 = QtGui.QLabel(Setting)
        self.logo_0.setText("")
        self.logo_0.setPixmap(QtGui.QPixmap("medias/logo+7_112x48.png"))
        self.logo_0.setObjectName("logo_0")
        self.horizontalLayout_4.addWidget(self.logo_0)
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem2)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        spacerItem3 = QtGui.QSpacerItem(20, 18, QtGui.QSizePolicy.Minimum, 
                                        QtGui.QSizePolicy.Fixed)
        self.verticalLayout.addItem(spacerItem3)
        self.horizontalLayout_4.addLayout(self.verticalLayout)
        self.verticalLayout_6.addLayout(self.horizontalLayout_4)
        self.grid_5 = QtGui.QGridLayout()
        self.grid_5.setSpacing(10)
        self.grid_5.setObjectName("grid_5")
        self.folder_0_lbl = QtGui.QLabel(Setting)
        self.folder_0_lbl.setObjectName("folder_0_lbl")
        self.grid_5.addWidget(self.folder_0_lbl, 0, 0, 1, 1)
        self.folder_0_led = QtGui.QLineEdit(Setting)
        self.folder_0_led.setMinimumSize(QtCore.QSize(300, 0))
        self.folder_0_led.setObjectName("folder_0_led")
        self.grid_5.addWidget(self.folder_0_led, 0, 1, 1, 5)
        self.browse_0_btn = QtGui.QPushButton(Setting)
        self.browse_0_btn.setObjectName("browse_0_btn")
        self.grid_5.addWidget(self.browse_0_btn, 0, 6, 1, 1)
        self.warning_0_lbl = QtGui.QLabel(Setting)
        self.warning_0_lbl.setStyleSheet("QFrame {color: #FF0000;}")
        self.warning_0_lbl.hide()
        self.grid_5.addWidget(self.warning_0_lbl, 1, 1, 1, 5)
        self.verticalLayout_6.addLayout(self.grid_5)
        self.horizontalLayout_6 = QtGui.QHBoxLayout()
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.pitch_0_chb = QtGui.QCheckBox(Setting)
        self.pitch_0_chb.setObjectName("pitch_0_chb")
        self.horizontalLayout_6.addWidget(self.pitch_0_chb)
        self.pitch_0_cmb = QtGui.QComboBox(Setting)
        self.pitch_0_cmb.addItems([_("Use one file by movie"),
                                    _("Use one unique file")])
        self.pitch_0_cmb.setMinimumSize(200, 25)
        self.pitch_0_cmb.setObjectName("pitch_0_cmb")
        self.horizontalLayout_6.addWidget(self.pitch_0_cmb)
        self.format_cmb = QtGui.QComboBox(Setting)
        self.format_cmb.addItems(['Text', 'Html'])
        self.format_cmb.setMinimumSize(80, 25)
        self.format_cmb.setObjectName("format_cmb")
        # Not yet implemented
        self.format_cmb.hide()
        self.horizontalLayout_6.addWidget(self.format_cmb)
        spacerItem4 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_6.addItem(spacerItem4)
        self.verticalLayout_6.addLayout(self.horizontalLayout_6)

        self.horizontalLayout_20 = QtGui.QHBoxLayout()
        self.copy_thumbs_chb = QtGui.QCheckBox(Setting)
        self.horizontalLayout_20.addWidget(self.copy_thumbs_chb)
        spacerItem16 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_20.addItem(spacerItem16)
        self.verticalLayout_6.addLayout(self.horizontalLayout_20)

        self.horizontalLayout_7 = QtGui.QHBoxLayout()
        self.horizontalLayout_7.setSpacing(10)
        self.horizontalLayout_7.setObjectName("horizontalLayout_7")
        self.size_0_lbl = QtGui.QLabel(Setting)
        self.size_0_lbl.setObjectName("size_0_lbl")
        self.horizontalLayout_7.addWidget(self.size_0_lbl)
        self.size_0_spb = QtGui.QSpinBox(Setting)
        self.size_0_spb.setMinimum(60)
        self.size_0_spb.setMaximum(200)
        self.size_0_spb.setSingleStep(10)
        self.size_0_spb.setProperty("value", 160)
        self.size_0_spb.setObjectName("size_0_spb")
        self.horizontalLayout_7.addWidget(self.size_0_spb)
        spacerItem5 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_7.addItem(spacerItem5)
        self.verticalLayout_6.addLayout(self.horizontalLayout_7)
        self.verticalLayout_8.addLayout(self.verticalLayout_6)
        self.line = QtGui.QFrame(Setting)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName("line")
        self.verticalLayout_8.addWidget(self.line)
        self.verticalLayout_7 = QtGui.QVBoxLayout()
        self.verticalLayout_7.setSpacing(2)
        self.verticalLayout_7.setObjectName("verticalLayout_7")
        self.horizontalLayout_9 = QtGui.QHBoxLayout()
        self.horizontalLayout_9.setObjectName("horizontalLayout_9")
        self.logo_1 = QtGui.QLabel(Setting)
        self.logo_1.setText("")
        self.logo_1.setPixmap(QtGui.QPixmap("medias/logoLW_213x36.png"))
        self.logo_1.setObjectName("logo_1")
        self.horizontalLayout_9.addWidget(self.logo_1)
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout_8 = QtGui.QHBoxLayout()
        self.horizontalLayout_8.setObjectName("horizontalLayout_8")
        spacerItem6 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_8.addItem(spacerItem6)
        self.verticalLayout_2.addLayout(self.horizontalLayout_8)
        spacerItem7 = QtGui.QSpacerItem(20, 30, QtGui.QSizePolicy.Minimum, 
                                        QtGui.QSizePolicy.Fixed)
        self.verticalLayout_2.addItem(spacerItem7)
        self.horizontalLayout_9.addLayout(self.verticalLayout_2)
        self.verticalLayout_7.addLayout(self.horizontalLayout_9)
        self.grid_10 = QtGui.QGridLayout()
        self.grid_10.setSpacing(10)
        self.grid_10.setObjectName("grid_10")
        self.folder_1_lbl = QtGui.QLabel(Setting)
        self.folder_1_lbl.setObjectName("folder_1_lbl")
        self.grid_10.addWidget(self.folder_1_lbl, 0, 0, 1, 1)
        self.folder_1_led = QtGui.QLineEdit(Setting)
        self.folder_1_led.setMinimumSize(QtCore.QSize(300, 0))
        self.folder_1_led.setObjectName("folder_1_led")
        self.grid_10.addWidget(self.folder_1_led, 0, 1, 1, 5)
        self.browse_1_btn = QtGui.QPushButton(Setting)
        self.browse_1_btn.setObjectName("browse_1_btn")
        self.grid_10.addWidget(self.browse_1_btn, 0, 6, 1, 1)
        self.warning_1_lbl = QtGui.QLabel(Setting)
        self.warning_1_lbl.setStyleSheet("QFrame {color: #FF0000;}")
        self.warning_1_lbl.hide()
        self.grid_10.addWidget(self.warning_1_lbl, 1, 1, 1, 5)
        self.verticalLayout_7.addLayout(self.grid_10)
        self.horizontalLayout_11 = QtGui.QHBoxLayout()
        self.horizontalLayout_11.setSpacing(10)
        self.horizontalLayout_11.setObjectName("horizontalLayout_11")
        self.load_first_lbl = QtGui.QLabel(Setting)
        self.load_first_lbl.setObjectName("load_first_lbl")
        self.horizontalLayout_11.addWidget(self.load_first_lbl)
        self.categories_cmb = QtGui.QComboBox(Setting)
        self.categories_cmb.setMinimumSize(180, 25)
        self.categories_cmb.setObjectName("categories_cmb")
        self.horizontalLayout_11.addWidget(self.categories_cmb)
        spacerItem8 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_11.addItem(spacerItem8)
        self.verticalLayout_7.addLayout(self.horizontalLayout_11)
        self.horizontalLayout_15 = QtGui.QHBoxLayout()
        self.horizontalLayout_15.setObjectName("horizontalLayout_15")
        self.pitch_1_chb = QtGui.QCheckBox(Setting)
        self.pitch_1_chb.setObjectName("pitch_1_chb")
        self.horizontalLayout_15.addWidget(self.pitch_1_chb)
        self.pitch_1_cmb = QtGui.QComboBox(Setting)
        self.pitch_1_cmb.addItems([_("Use one file by movie"),
                                    _("Use one unique file")])
        self.pitch_1_cmb.setMinimumSize(200, 25)
        self.pitch_1_cmb.setObjectName("pitch_1_cmb")
        self.horizontalLayout_15.addWidget(self.pitch_1_cmb)
        self.format_1_cmb = QtGui.QComboBox(Setting)
        self.format_1_cmb.addItems(['Text', 'Html'])
        self.format_1_cmb.setMinimumSize(80, 25)
        self.format_1_cmb.setObjectName("format_1_cmb")
        # Not yet implemented
        self.format_1_cmb.hide()
        self.horizontalLayout_15.addWidget(self.format_1_cmb)
        spacerItem11 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_15.addItem(spacerItem11)
        self.verticalLayout_7.addLayout(self.horizontalLayout_15)

        self.horizontalLayout_19 = QtGui.QHBoxLayout()
        self.copy_thumbs_1_chb = QtGui.QCheckBox(Setting)
        self.horizontalLayout_19.addWidget(self.copy_thumbs_1_chb)
        spacerItem15 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_19.addItem(spacerItem15)
        self.verticalLayout_7.addLayout(self.horizontalLayout_19)

        self.horizontalLayout_16 = QtGui.QHBoxLayout()
        self.horizontalLayout_16.setSpacing(10)
        self.horizontalLayout_16.setObjectName("horizontalLayout_16")
        self.size_1_lbl = QtGui.QLabel(Setting)
        self.size_1_lbl.setObjectName("size_1_lbl")
        self.horizontalLayout_16.addWidget(self.size_1_lbl)
        self.size_1_spb = QtGui.QSpinBox(Setting)
        self.size_1_spb.setMinimum(150)
        self.size_1_spb.setMaximum(250)
        self.size_1_spb.setSingleStep(10)
        self.size_1_spb.setProperty("value", 250)
        self.size_1_spb.setObjectName("size_1_spb")
        self.horizontalLayout_16.addWidget(self.size_1_spb)
        spacerItem12 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_16.addItem(spacerItem12)
        self.verticalLayout_7.addLayout(self.horizontalLayout_16)
        self.verticalLayout_8.addLayout(self.verticalLayout_7)
        self.horizontalLayout_17 = QtGui.QHBoxLayout()
        self.horizontalLayout_17.setObjectName("horizontalLayout_17")
        spacerItem13 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_17.addItem(spacerItem13)
        self.close_btn = QtGui.QPushButton(Setting)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("medias/close.png"), QtGui.QIcon.Normal, 
                                        QtGui.QIcon.Off)
        self.close_btn.setIcon(icon)
        self.close_btn.setObjectName("close_btn")
        self.horizontalLayout_17.addWidget(self.close_btn)
        spacerItem14 = QtGui.QSpacerItem(10, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_17.addItem(spacerItem14)
        self.verticalLayout_8.addLayout(self.horizontalLayout_17)
        self.gridLayout.addLayout(self.verticalLayout_8, 0, 0, 1, 1)
        self.sett = Setting
        self.retranslateUi(Setting)
        #self.set_style()
        self.lang_cmb.currentIndexChanged.connect(self.on_lang_changed)
        self.browse_0_btn.clicked.connect(self.get_folder)
        self.browse_1_btn.clicked.connect(self.get_live_folder)
        self.browse_2_btn.clicked.connect(self.get_mailBox)
        self.folder_0_led.editingFinished.connect(self.on_plus_dir_editing)
        self.folder_1_led.editingFinished.connect(self.on_live_dir_editing)
        self.close_btn.clicked.connect(self.close_dialog)
        QtCore.QMetaObject.connectSlotsByName(Setting)
        self.set_config()

    def set_config(self):
        self.set_categories(self.cfg['lang'])
        self.load_plus_chb.setChecked(self.cfg['load_pages'][0])
        self.load_live_chb.setChecked(self.cfg['load_pages'][1])
        self.notify_chb.setChecked(self.cfg['notify'])
        self.mail_led.setText(self.cfg['mailbox'])
        self.folder_0_led.setText(self.cfg['plus_folder'])
        self.pitch_0_chb.setChecked(self.cfg['pitch_plus'])
        self.pitch_0_cmb.setCurrentIndex(self.cfg['pitch_plus_unique'])
        self.copy_thumbs_chb.setChecked(self.cfg['copythumb_plus'])
        self.format_cmb.setCurrentIndex(self.cfg['pitch_plus_format'] == 'html') 
        self.size_0_spb.setValue(self.cfg['thumb1'])
        self.folder_1_led.setText(self.cfg['live_folder'])
        self.categories_cmb.setCurrentIndex(self.categories.index(
                                            self.cfg['cur_cat']))
        self.pitch_1_chb.setChecked(self.cfg['pitch_live'])
        self.pitch_1_cmb.setCurrentIndex(self.cfg['pitch_live_unique'])
        self.copy_thumbs_1_chb.setChecked(self.cfg['copythumb_live'])
        self.format_1_cmb.setCurrentIndex(self.cfg['pitch_live_format'] == 'html')
        self.size_1_spb.setValue(self.cfg['mini'])

    def get_live_folder(self):
        self.get_folder(True)

    def get_mailBox(self):
        f = self.cfg['mailbox']
        if not os.path.isdir(f):
            f = os.path.dirname(f)
        fdial = QtGui.QFileDialog(None, u"Choose mail file")
        fdial.setFileMode(QtGui.QFileDialog.AnyFile)
        fdial.setDirectory(f)
        mail = unicode(fdial.exec_())

        if not mail or not os.path.isfile(mail):
            return

        self.mail_led.setText(mail)

    def get_folder(self, site=False):
        f = os.path.expanduser('~')
        d = unicode(QtGui.QFileDialog.getExistingDirectory(None, 
                            u"Choose destination folder", f, 
                            QtGui.QFileDialog.DontResolveSymlinks
                            | QtGui.QFileDialog.ShowDirsOnly))
        if not d:
            return

        if not os.path.isdir(d):
            if not self.create_folder(d):
                return

        if not site:
            self.folder_0_led.setText(d)
            if not os.access(d, os.W_OK):
                # Read-only
                self.warning_0_lbl.show()

            else:
                self.warning_0_lbl.hide()

        else:
            self.folder_1_led.setText(d)
            if not os.access(d, os.W_OK):
                # Read-only
                self.warning_1_lbl.show()

            else:
                self.warning_1_lbl.hide()

        if self.cfg['lang'] == 'fr':
            cats = data.FR_CATEGORIES

        else:
            cats = data.DE_CATEGORIES

    def on_lang_changed(self, idx):
        if idx:
            self.set_categories('de')

        else:
            self.set_categories('fr')

    def set_categories(self, lang):
        idx = self.categories_cmb.currentIndex()
        if idx == -1:
            idx = 0

        if lang == 'fr':
            self.categories = data.FR_CATEGORIES
            self.lang_cmb.setCurrentIndex(0)

        else:
            self.categories = data.DE_CATEGORIES
            self.lang_cmb.setCurrentIndex(1)

        self.categories_cmb.clear()
        self.categories_cmb.addItems(self.categories)
        self.categories_cmb.setCurrentIndex(idx)

    def create_folder(self, path):
        try:
            os.makedirs(path)

        except Exception, why:
            self.main.show_warning(10,(path, why))
            return False

        return True

    def on_plus_dir_editing(self):
        d = unicode(self.folder_0_led.text())
        if not os.path.isdir(d):
            if not self.create_folder(d):
                self.folder_0_led.setText(os.path.expanduser("~"))

    def on_live_dir_editing(self):
        d = unicode(self.folder_1_led.text())
        if not os.path.isdir(d):
            if not self.create_folder(d):
                self.folder_1_led.setText(os.path.expanduser("~"))

    def close_dialog(self):
        langs = ('fr', 'de')
        self.cfg['lang'] = langs[self.lang_cmb.currentIndex()]
        self.cfg['load_pages'] = (self.load_plus_chb.isChecked(),
                                    self.load_live_chb.isChecked(),
                                    self.cfg['load_pages'][2])
        self.cfg['notify'] = self.notify_chb.isChecked()
        self.cfg['mailbox'] = unicode(self.mail_led.text())

        if not self.warning_0_lbl.isVisible():
            self.cfg['plus_folder'] = unicode(self.folder_0_led.text())

        self.cfg['pitch_plus'] = self.pitch_0_chb.isChecked()
        self.cfg['pitch_plus_unique'] = self.pitch_0_cmb.currentIndex()
        self.cfg['copythumb_plus'] = self.copy_thumbs_chb.isChecked()
        self.cfg['thumb1'] = self.size_0_spb.value()

        if not self.warning_1_lbl.isVisible():
            self.cfg['live_folder'] = unicode(self.folder_1_led.text())

        if self.categories_cmb.currentIndex() == 5:
            self.cfg['cur_cat'] = 'News'

        else:
            self.cfg['cur_cat'] = unicode(self.categories_cmb.currentText())

        self.cfg['pitch_live'] = self.pitch_1_chb.isChecked()
        self.cfg['pitch_live_unique'] = self.pitch_1_cmb.currentIndex()
        self.cfg['copythumb_live'] = self.copy_thumbs_1_chb.isChecked()
        self.cfg['mini'] = self.size_1_spb.value()
        self.sett.accept()

    def set_style(self):
        theme = Themes(self)
        theme.set_theme_dark()
        self.sett.setStyleSheet(theme.settingDialog_style)
        self.mail_led.setStyleSheet(theme.lineEdit_style)
        self.browse_2_btn.setStyleSheet(theme.pushButton_style)
        self.load_plus_chb.setStyleSheet(theme.checkBox_style)
        self.load_live_chb.setStyleSheet(theme.checkBox_style)
        self.notify_chb.setStyleSheet(theme.checkBox_style)
        self.pitch_0_chb.setStyleSheet(theme.checkBox_style)
        self.copy_thumbs_chb.setStyleSheet(theme.checkBox_style)
        self.copy_thumbs_1_chb.setStyleSheet(theme.checkBox_style)
        self.pitch_1_chb.setStyleSheet(theme.checkBox_style)
        self.lang_cmb.setStyleSheet(theme.comboBox_style)
        self.pitch_0_cmb.setStyleSheet(theme.comboBox_style)
        self.format_cmb.setStyleSheet(theme.comboBox_style)
        self.categories_cmb.setStyleSheet(theme.comboBox_style)
        self.pitch_1_cmb.setStyleSheet(theme.comboBox_style)
        self.format_1_cmb.setStyleSheet(theme.comboBox_style)
        self.folder_0_led.setStyleSheet(theme.lineEdit_style)
        self.folder_1_led.setStyleSheet(theme.lineEdit_style)
        self.browse_0_btn.setStyleSheet(theme.pushButton_style)
        self.browse_1_btn.setStyleSheet(theme.pushButton_style)
        self.close_btn.setStyleSheet(theme.pushButton_style)
        self.size_0_spb.setStyleSheet(theme.spinBox_style)
        self.size_1_spb.setStyleSheet(theme.spinBox_style)

    def retranslateUi(self, Settings):
        Settings.setWindowTitle(_("Qarte - Settings"))
        self.start_lbl.setText(_("Load page:"))
        self.notify_chb.setText(_("Notify when the downloads are finished"))
        self.mail_lbl.setText(_("Crontab mail box"))
        self.browse_2_btn.setText(_("Browse"))
        self.folder_0_lbl.setText(_("Videos folder:"))
        self.browse_0_btn.setText(_("Browse"))
        self.warning_0_lbl.setText(_("Warning, this folder is read only!"))
        self.pitch_0_chb.setText(_("Record the summaries"))
        self.copy_thumbs_chb.setText(_("Copy a thumbnail for each video"))
        self.size_0_lbl.setText(_("Thumbnail\'s size:"))
        self.size_0_spb.setSuffix(_(" px"))
        self.folder_1_lbl.setText(_("Videos folder:"))
        self.browse_1_btn.setText(_("Browse"))
        self.warning_1_lbl.setText(_("Warning"))
        self.load_first_lbl.setText(_("Show category at startup:"))
        self.pitch_1_chb.setText(_("Record the summaries"))
        self.copy_thumbs_1_chb.setText(_("Copy a thumbnail for each video"))
        self.size_1_lbl.setText(_("Thumbnail\'s size:"))
        self.size_1_spb.setSuffix(_(" px"))
        self.close_btn.setText(_("Close"))


