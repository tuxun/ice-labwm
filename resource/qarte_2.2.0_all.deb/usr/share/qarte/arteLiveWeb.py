# -*- coding: utf-8 -*-

# arteLiveWeb.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2011-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Arte Live Web main class

import os, re
import time
import datetime
import shutil
import sys
import pickle
import logging
logger = logging.getLogger(__name__)

try:
    import pynotify
    NOTIFY = True
except:
    NOTIFY = False

from threading import Thread, current_thread
from threading import enumerate as enumerate_

from PyQt4 import QtCore, QtGui

from data import CATEGORIES

from parsers import LiveParser
from loaders import LiveLoader, RateCounter
from dwnlConfig import ArteLiveDownloadingConfig

class ArteLiveWeb(object):
    """Main class of arteLiveWeb.

    """
    def __init__(self, main):
        """Instanciate the main class of arteLiveWeb.

        """
        self.main = main
        self.ui = main.ui
        self.viewer = main.ui.viewer
        self.lui = main.ui.live_pg
        self.cfg = main.cfg
        self.prev_fld = main.prev_fld
        self.old_list = main.old_list
        self.dwlnd_fld = self.cfg['live_folder']
        self.current = 0
        self.cur_category = None
        self.fr_categories = CATEGORIES['fr']
        self.de_categories = CATEGORIES['de']
        self.urls_fr = None
        self.urls_de = None
        self.videos = {}
        self.images = []
        self.news = []
        self.videos_items = []
        self.lang = self.cfg['lang']
        self.to_download = []
        self.summaries = []
        self.is_loading = False
        self.cur_in_basket = None
        self.get_old_videos()
        self.__set_connections()
        self.cur_category = self.cfg['cur_cat']
        self.counter_category = 0
        self.lld = None
        self.viewer.al = self
        self.viewer.prev_fld = self.prev_fld
        self.viewer.cfg = self.cfg

    def get_live_page(self):
        """Load arteLiveWeb main page.

        """
        self.lp = LiveParser(self, self.urls_fr, self.urls_de)
        self.lp.loadingPageFailed.connect(self.on_page_failed)
        self.lp.loadingCategoryFinished.connect(self.update_category)
        self.lp.loadingCategoryFailed.connect(self.on_page_failed)
        prs = self.lp.parse()
        if prs:
            if self.cur_category is None:
                self.load_all_categories()

            elif self.cur_category != 'News':
                self.load_cur_category()


    def load_all_categories(self):
        """Called if no category is selected in user's config.

        Categories are loaded in order of categories.keys()
        """
        if self.lang == 'fr':
            keys = self.fr_categories.keys()

        else:
            keys = self.de_categories.keys()

        keys.remove('News')
        self.cur_category = keys[0]
        self.load_cur_category()

    def load_cur_category(self):
        """Called at startup if a category is set in user's config.

        Current category is loaded first and following categories are
        loaded into separate threads.
        """
        def get_videos(cat):
            self.lp.get_videos_list(cat)
        Thread(target=get_videos, args=(self.cur_category,)).start()

        if self.lang == 'fr':
            keys = self.fr_categories.keys()

        else:
            keys = self.de_categories.keys()

        keys.remove(self.cur_category)
        keys.remove('News')

        # Wait for loading first category
        time.sleep(1.0)
        for k in keys:
            Thread(target=get_videos, args=(k,)).start()
            time.sleep(0.4)

    def set_categories(self, cat):
        """Create categories found into main page of arteLiveWeb site.

        Args:
        cat -- categories, french or german names according to the user's prefs
        """
        lst = sorted(CATEGORIES[self.lang].keys())
        self.categories = [c.encode('utf-8', 'replace') for c in lst]
        self.videos = {}

        for c in self.categories:
            self.videos[c] = {}

        self.videos['News'] = {}

    def check_for_news(self):
        """Check if there's new videos since the last session.

        """
        if self.news:
            self.ui.enable_button('News')

    def change_category(self, cat):
        """Called when user change category.

        Args:
        cat -- category
        """
        c = cat[0]

        if self.lang == 'de':
            c = cat[1]

        self.cur_category = c
        self.ui.set_toggled_button(c)
        self.viewer.setFocus()
        self.show_category()

    def update_category(self, cat):
        """Called when the page parser has finished to read a category page.

        Args:
        cat -- category
        """
        cat = str(cat)
        for key, val in CATEGORIES[self.lang].items():
            if val == str(cat):
                break

        # Find new videos
        for k in self.videos[key].keys():
            try:
                if k not in self.olds[self.lang][key]:
                    self.news.append(k)
                    self.videos['News'][k] = self.videos[key][k]
            except:
                pass

        self.olds[self.lang][key] = self.videos[key].keys()
        self.save_olds_list()
        self.enable_category(key)

    def enable_category(self, cat):
        """Set enabled a category.

        Args:
        cat -- category
        """
        self.ui.enable_button(cat)
        self.counter_category += 1
        self.remove_duplicate(cat)

        if self.cur_category == "News":

            if self.news:
                self.ui.statusbar.showMessage(u"Find {0} new videos"
                                        .format(len(self.news)))
                QtCore.QCoreApplication.processEvents()

            if self.counter_category == 7:
                self.show_category()
                self.ui.set_toggled_button("News")

        elif cat == self.cur_category:
            self.show_category()
            self.ui.set_toggled_button(cat)

        if self.counter_category == 7:
            # All pages are parsed, checking for news videos
            logger.info(u"arteLiveWeb parsing finished")
            logger.info(u"Thread enum: {0}".format(enumerate_()))
            self.main.check_parsing()
            self.check_for_news()

    def show_category(self):
        """Shows preview items in the viewer area.

        """
        if not self.videos[self.cur_category]:
            logger.info(u'Category {0} has no videos'.format(self.cur_category))
            return
        self.viewer.show_category(self.videos[self.cur_category])

    def remove_duplicate(self, cat):
        """Remove the videos which are already in the Arte Live Web page.

        Args:
        cat -- category name
        """
        if cat == u'La Blogothèque':
            name = u'Pop rock & Electro'
            if self.lang == 'de':
                name = u'Pop, Rock, Electro'

        else:
            return

        other = self.main.alw.videos[name]
        for item in other.keys():
            if item in self.videos[cat]:
                del self.videos[cat][item]

    def on_thumbnail_selected(self, item):
        # Check if video is already in the downloading basket
        self.ui.select_btn.setEnabled(not item in self.to_download)
        # and if already available
        self.ui.select_btn.setEnabled(not item.soon)


    #==============================================
    # QTableWidget functions
    #==============================================
    def select_video_to_download(self, idx=None):
        """Select a video for the downloading basket.

        Args:
        idx -- index of video if called by a double click on a item
        """
        if idx is None:
            idx = self.viewer.current

        else:
            self.viewer.go_to_item(idx)

        vid = self.viewer.videos_items[idx]
        if vid in self.to_download:
            return

        logger.info(u"Append item {0} to download basket".format(vid.order))
        if vid.link.startswith('http://concert'):
            prop = self.get_concert_stream_properties(vid)

        else:
            prop = self.get_stream_properties(vid)

        if prop is None:
            logger.warning(u"No stream URLs found, item rejected")
            return

        self.to_download.append(vid)
        self.ui.alw_tbl.add_item(vid, self.viewer.previews[idx].img)
        self.ui.select_btn.setEnabled(False)
        self.ui.dl_live_wdg.dwnld_btn.setEnabled(True)
        self.ui.actionDow_nload.setEnabled(True)
        self.append_summary_to_download()

    def remove_item_from_basket(self, idx=None):
        """Called if user remove an item from downloading basket or when
        a downloading is complete.

        idx -- index of item
        """
        logger.info('Remove item %s frombasket' % idx)
        if idx == 'first':
            idx = 0

        elif idx is None:
            idx = self.get_current_item_index()

        self.ui.alw_tbl.delete_item(idx)
        self.to_download.pop(idx)

    def move_up_item(self):
        """Move an item to up one level.

        """
        idx = self.get_current_item_index()
        if idx is not None:
            self.to_download.insert(idx-1, self.to_download.pop(idx))

        self.ui.alw_tbl.move_up_selection()

    def move_down_item(self):
        """Move down an item.

        """
        idx = self.get_current_item_index()
        if idx is not None:
            self.to_download.insert(idx+1, self.to_download.pop(idx))

        self.ui.alw_tbl.move_down_selection()

    def on_table_selection_changed(self, idx):
        self.cur_in_basket = self.to_download[idx]
        self.set_basket_buttons_enabled(True)

    def on_table_unselect(self):
        self.cur_in_basket = None
        self.set_basket_buttons_enabled(False)

    def on_table_empty(self):
        """Called when last item in table has been removed.

        """
        self.ui.dl_live_wdg.dwnld_btn.setEnabled(False)
        self.ui.actionDow_nload.setEnabled(False)
        self.ui.dl_live_wdg.cancel_btn.setEnabled(False)
        self.ui.actionCanc_el.setEnabled(False)

    def get_current_item_index(self):
        """Return the selected item index in the table.

        """
        item = self.cur_in_basket
        if item is not None:
            return self.to_download.index(item)

        return None

    def config_downloading(self, idx):
        """Call the downloading setting dialog box.

        """
        video = self.to_download[idx]

        dial = QtGui.QDialog()
        gui = ArteLiveDownloadingConfig()
        gui.setupUi(dial, video)
        dial.exec_()
        self.ui.alw_tbl.rename_item(idx, video.outfile)

    def append_summary_to_download(self):
        self.summaries.append(unicode(self.ui.editor_live.toPlainText()))

    def get_stream_properties(self, movie):
        """Get stream links.

        Args:
        movie -- VideoItem instance
        """
        links = self.lp.get_links(movie.order)
        movie.HD = links['HD']
        movie.SD = links['SD']
        movie.Live = links['Live']

        if movie.HD is not None:
            movie.quality = 1

        elif vid.SD is not None:
            movie.quality = 0

        else:
            self.main.show_warning(5, "Undefined")
            movie.quality = None
            return None

        return movie

    def get_concert_stream_properties(self, movie):
        links = self.lp.get_concert_stream_qualities(movie.link)
        if links is None:
            return

        if links[0] is not None:
            movie.HD = links[0]
            if links[1] is not None:
                movie.SD = links[1]
            else:
                movie.SD = links[2]

        elif links[1] is not None:
            movie.HD = links[1]
            movie.SD = links[2]

        elif links[2] is not None:
            movie.HD = None
            movie.SD = links[2]

        if movie.HD is not None:
            movie.quality = 1

        elif vid.SD is not None:
            movie.quality = 0

        else:
            self.main.show_warning(5, "Undefined")
            movie.quality = None
            return None

        return movie

    #===========================================================

    def download_later(self, idx):
        """Call differed download dialog.

        Args:
        idx -- video's index
        """
        vid = self.viewer.videos_items[idx]
        if vid.link.startswith('http://concert'):
            video = self.get_concert_stream_properties(vid)

        else:
            video = self.get_stream_properties(vid)

        if video is None:
            return

        self.viewer.go_to_item(idx)
        video.pitch = unicode(self.ui.editor_live.toPlainText())
        self.main.set_differed_tasks(video)

    #===========================================================

    def show_pitch(self, item):
        """Called when the current item in the viewer has changed.

        """
        title = item.title
        date = item.date
        pitch = item.pitch
        self.update_pitch(title, date, pitch)

    def update_pitch(self, *args):
        """Show the pitch of the current item.

        """
        self.ui.editor_live.clear()
        font = QtGui.QFont("sans", 10)
        c_form = QtGui.QTextCharFormat()
        c_form.setFont(font)
        font1 = QtGui.QFont("sans", 12)
        font1.setWeight(75)
        c_form1 = QtGui.QTextCharFormat()
        c_form1.setFont(font1)
        self.ui.editor_live.setCurrentCharFormat(c_form1)
        self.ui.editor_live.appendPlainText(args[0])
        self.ui.editor_live.setCurrentCharFormat(c_form) 
        self.ui.editor_live.appendPlainText(args[1])
        self.ui.editor_live.appendPlainText("")
        self.ui.editor_live.appendHtml(args[2])
        self.ui.editor_live.verticalScrollBar().setValue(0) 

    def get_old_videos(self):
        """Load the list of old movies.

        Old movies are the videos wich are already existing on the last
        session. This list is used to detect new videos.
        """
        try:
            with open(self.old_list, "r") as objfile:
                self.olds = pickle.load(objfile)
        except Exception, why:
            self.olds = {'fr': {'Classique': [],
                                'Jazz & Blues': [],
                                'Pop rock & Electro': [],
                                u'Théâtre & Danse': [],
                                'Musiques du monde': []},
                        'de': {'Klassik': [],
                                'Jazz & Blues': [],
                                'Pop, Rock, Electro': [],
                                'Theater & Tanz': [],
                                'World Music': []}}
            self.save_olds_list()

    def save_olds_list(self):
        try:
            with open(self.old_list, "w") as objfile:
                 pickle.dump(self.olds, objfile)
        except Exception, why:
            self.main.show_warning(9, why)
        
    #==========================================================
    # Downloading
    #==========================================================
    def fetch_video(self):
        """Set parameters for downloading.

        To avoid encoding problem, the target name is build with
        the actual time and the file will be renamed when
        the downloading is finished.
        """
        tmp = os.path.join(self.dwlnd_fld, self.get_temp_filename())

        if self.to_download[0].outfile is None:
            self.to_download[0].outfile = self.to_download[0].title

        logger.info(u"Downloading request, title: {0}"
                        .format(self.to_download[0].title))
        logger.info(u"Temp file:{0}".format(tmp))
        fname = self.format_file_name(self.to_download[0].outfile)
        self.name_to_notify = fname
        dest = os.path.join(self.dwlnd_fld, fname)
        dest += ".flv"
        self.last_loaded = False

        if self.to_download[0].quality is None:
            url = self.to_download[0].Live

        elif self.to_download[0].quality:
            url = self.to_download[0].HD

        else:
            url = self.to_download[0].SD

        if url is None:
            # Should not appears, but bug
            return

        self.rcount = RateCounter(self, tmp)
        self.lld = LiveLoader(self)
        self.lld.loadProgress.connect(self.show_progress)
        self.lld.loadComplete.connect(self.on_loading_finished)
        self.lld.set_url(url)
        self.lld.set_target(tmp)
        self.lld.set_destination(dest)
        self.is_loading = True
        self.ui.alw_tbl.disable_settings()

        def run_load():
            self.lld.load()

        Thread(target=run_load).start()
        self.enable_download_buttons(True)

    def abort_loading(self):
        """Called when user cancel the current downloading.

        """
        logger.info(u"Downloading stopped by user")
        if self.lld is not None:
            self.lld.kill_request = True

    def on_loading_finished(self, err):
        """Called when download is finished or cancelled.

        Args:
        err -- Error message if downloading failed
        """
        item = self.to_download[0]
        self.ui.dl_live_wdg.progressBar.setValue(0)
        self.enable_download_buttons(False)
        self.remove_item_from_basket('first')

        if not err:
            logger.info(u"Download complete")
            if self.cfg['notify']:
                self.notify()

            if self.cfg['pitch_live']:
                self.save_pitch()

            if self.cfg['copythumb_live']:
                self.copy_thumbnail(item)

        self.is_loading = False

    def show_progress(self, val):
        """Update the progressBar.

        """
        if int(val) == -1:
             self.ui.dl_live_wdg.progressBar.setMinimum(100)

        elif int(val) != self.ui.dl_live_wdg.progressBar.value():
            self.ui.dl_live_wdg.progressBar.setValue(val)

            if not int(val) % 3:
                rate, rem = self.rcount.counter(val)
                self.ui.dl_live_wdg.progress_lbl.setText(rate)
                self.ui.dl_live_wdg.progress_lbl2.setText(rem)

    def format_file_name(self, name):
        """Remove from the file name characters wich may cause problem.

        Args:
        name -- basename file

        Returns:
        Cleaned file name 
        """
        try:
            for c in [u'»', u'«', u'/', u'\\', u'"']:
                name = name.replace(c, "_")
        except:
            pass

        return name

    def get_temp_filename(self):
        """Create a temporary file name with time()

        Returns:
        filename like 'alw123456789'
        """
        d = str(time.time()).replace(".", "")
        t = "".join(["alw", d, ".flv"])
        count = 1

        while 1:
            target = os.path.join(self.dwlnd_fld, t)
            if os.path.isfile(target):
                t = "".join(["alw", d, str(count), ".flv"])
                count += 1
            else:
                break

        return t

    def enable_download_buttons(self, b):
        """Enable download and cancel buttons when downloading is called or
        is finished.

        Args:
        b -- boolean
        """
        self.ui.dl_live_wdg.dwnld_btn.setEnabled(not b)
        self.ui.actionDow_nload.setEnabled(not b)
        self.ui.dl_live_wdg.cancel_btn.setEnabled(b)
        self.ui.actionCanc_el.setEnabled(b)

    def save_pitch(self):
        if self.cfg['pitch_live_unique']:
            f = os.path.join(self.dwlnd_fld, "index")

        else:
            f = os.path.join(self.dwlnd_fld, self.name_to_notify[:-4])

        p = self.summaries.pop(0)
        p += u"\n\n"

        try:
            with open(f, "a") as objf:
                objf.write(p.encode('utf8', 'ignore'))
        except Exception, why:
            self.main.show_warning(4, why)

    def copy_thumbnail(self, item):
        """Place a copy of the video thumbnail into the downloading folder.

        This feature is useful for some medias server wich have an option
        'use sameNameAsVideo.jpg' for populate "cover art".

        Args:
        item -- ItemVideo instance
        """
        if not self.last_loaded:
            return

        try:
            thumb = os.path.join(self.prev_fld, item.preview)
            name = os.path.join(self.dwlnd_fld, self.last_loaded[:-4] + '.jpg')
        except Exception as why:
            logger.warning(u'Copy thumbnail error: {0}'.format(why))
            return

        logger.info('Copy thumbnail {0}'.format(name))
        try:
            shutil.copy(thumb, name)
        except Exception as why:
            logger.warning(u'Copy error: {0}'.format(why))

    def __set_connections(self):
        self.ui.classic_btn.triggered.connect(self.change_category)
        self.ui.jazz_btn.triggered.connect(self.change_category)
        self.ui.rock_btn.triggered.connect(self.change_category)
        self.ui.theater_btn.triggered.connect(self.change_category)
        self.ui.world_btn.triggered.connect(self.change_category)
        self.ui.tracks_btn.triggered.connect(self.change_category)
        self.ui.blogo_btn.triggered.connect(self.change_category)
        self.ui.news_btn.triggered.connect(self.change_category)
        self.ui.left_btn.clicked.connect(self.viewer.shift_to_previous)
        self.ui.right_btn.clicked.connect(self.viewer.shift_to_next)
        self.ui.select_btn.pressed.connect(self.select_video_to_download)
        self.ui.dl_live_wdg.dwnld_btn.clicked.connect(self.fetch_video)
        self.ui.dl_live_wdg.cancel_btn.clicked.connect(self.abort_loading)
        self.ui.alw_tbl.itemSelected.connect(self.on_table_selection_changed)
        self.ui.alw_tbl.unselectAll.connect(self.on_table_unselect)
        self.ui.alw_tbl.onLastItemRemoved.connect(self.on_table_empty)

    def set_basket_buttons_enabled(self, b):
        return

    def update_button(self):
        pass

    def on_page_failed(self, stage, msg):
        self.main.show_warning(stage, str(msg))

    def notify(self):
        """Show GTK notification.

        Arguments :
        t -- title of video
        """
        if not NOTIFY:
            return
        img_uri = os.path.join(os.getcwd(), "medias/qarte_logo.png")
        pynotify.init("arteLiveWeb")
        notification = pynotify.Notification(self.name_to_notify,
                                             "Download complete", img_uri)
        notification.show()




if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    MainWindow = QtGui.QMainWindow()
    ui = Ui_ArteLiveWeb()
    ui.setupUi(MainWindow)
    MainWindow.show()
    QtCore.QCoreApplication.processEvents()
    alw = ArteLiveWeb(ui)
    sys.exit(app.exec_())
