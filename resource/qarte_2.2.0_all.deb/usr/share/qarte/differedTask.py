# -*- coding: utf-8 -*-

# differedTask.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2011-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Crontab maker

# http://www.cyberciti.biz/faq/disable-the-mail-alert-by-crontab-command/

import sys
import os
import time
import pwd
import pickle
import locale
import logging
logger = logging.getLogger(__name__)

from datetime import datetime
from threading import Thread

from crontab.crontab import CronTab
from ui_differedTask import Ui_DifferedTaskDialog

from PyQt4 import QtCore, QtGui

QUALITIES = [u'RTMP_EQ_1', u'RTMP_MQ_1', u'RTMP_SQ_1', u'RTMP_LQ_1']

class DifferedTask(object):
    def __init__(self, main=None, movie=None):
        """Differed tasks module.

        Tasks 1: The video is identified
              2: A serial name is provided
              3: A keyword is provided
              4: Exceptions; the videos restricted 23:00-05:00 H.
        """  
        self.main = main
        self.utils = main.utils
        self.user_fld = main.user_fld
        self.user = self.get_user()
        self.tasks_file = os.path.join(self.user_fld, "difTasksList")
        self.cfg = main.cfg
        self.lang = self.cfg['lang']
        self.multi_load = False
        self.videos_plus = main.apl.videos
        self.videos_live = main.alw.videos_items
        self.tasks = []
        self.video = None
        self.cur_index = 1
        self.cur_desc = None
        self.is_editing = False
        self.restricted = False
        self.tsked = TaskEditor(self)

        self.load_tasks()
        #self.pprs = main.apl.pprs

        self.dial = QtGui.QDialog()
        self.gui = Ui_DifferedTaskDialog()
        self.gui.setupUi(self, self.dial)
        self.gui.set_tasks(self.tasks)
        self.dial.show()
        QtCore.QCoreApplication.processEvents()

        self.set_log_editor()

        if movie:
            self.set_movie(movie)

    def set_movie(self, movie):
        try:
            o = movie.order
            self.set_live_item(movie)
        except:
            # movies from arte+7 don't have attribute 'order'
            self.set_plus_item(movie)

        self.gui.set_current_site()

    def set_plus_item(self, item):
        self.gui.plus_rdo.setChecked(True)
        self.gui.movie_rdo.setChecked(True)
        self.gui.mov_name_led.setText(item.title)
        if item.stream is None:
            item.stream = u'RTMP_MQ_1'
        self.cur_stream = item.stream
        self.cur_desc = item.summary
        idx = self.gui.serial_cmb.findText(item.title)

        if idx >= 0:
            t = u"".join([item.title, "  <", item.date, ">"])
            self.gui.mov_name_led.setText(t)

        streams = self.get_video_plus_stream(item.link)
        if streams is None:
            self.main.show_warning(5, "Not found")
            del tobj
            return

        else:
            item.streams = streams

        idx = QUALITIES.index(self.cur_stream)
        if idx < 0:
            idx = 0
        self.gui.quality_cmb.setCurrentIndex(idx)

        self.video = item
            
    def set_live_item(self, item):
        self.gui.live_rdo.setChecked(True)
        self.gui.movie_rdo.setChecked(True)
        self.gui.mov_name_led.setText(item.title)
        self.video = item
        self.gui.set_qualities('live')

    def set_selection_mode(self):
        """Called from Ui_DifferedTaskDialog when user want to choose a video.

        Args:
        b -- boolean
        """
        self.main.is_interact_with_dialog = True
        self.dial.hide()

    def select_item(self, item):
        self.dial.show()
        self.set_movie(item)

    def create_new_task(self):
        """Prepare new cron task.

        """
        if self.is_editing:
            task = self.edited_task

        else:
            task = TaskObject(self.cur_index, None)

        if self.gui.plus_rdo.isChecked():
            task.site = 'plus'
            self.make_plus_task(task)

        else:
            task.site = 'live'
            self.make_live_task(task)

    def make_plus_task(self, tobj):
        """Set the name or search key for the movie.

        """
        if self.gui.movie_rdo.isChecked():
            title = unicode(self.gui.mov_name_led.text())

            if self.video is None:
                self.video = self.get_video_plus(title.split("  <")[0])

            if self.video is None:
                del tobj
                self.gui.on_unvalid_movie_name()
                return

            tobj.movie = title
            tobj.filename = self.get_filename(self.video)
            tobj.streams = self.video.streams
            tobj.stream = QUALITIES[self.gui.quality_cmb.currentIndex()]
            tobj.pitch = self.create_summary(self.video)
            tobj.type = 1
            logger.info('Found {0}'.format(tobj.stream))

            # Check for restricted time
            if tobj.streams == 'restricted':
                tobj.type = 4
                tobj.keyword = title
                tobj.moviedate = self.video.date
                self.restricted = True
                time = QtCore.QTime(23, 05, 0)
                time2 = QtCore.QTime(04, 55, 0)
                time3 = self.gui.time_spb.time()
                if time > time3 and time3 > time2:
                    self.gui.time_spb.setTime(time)

        elif self.gui.serial_rdo.isChecked():
            srl = unicode(self.gui.serial_cmb.currentText())
            if srl == u'360 - GEO' or srl == u'360° - GEO-Reportage':
                # The syntax of this category may vary
                tobj.type = 3
                tobj.keyword = u'360 geo'

            else:
                tobj.serial = srl
                tobj.type = 2

        elif self.gui.kword_rdo.isChecked():
            tobj.keyword = unicode(self.gui.kword_led.text())
            tobj.type = 3

        if self.gui.all_rdo.isChecked():
            tobj.single = 0

        self.set_task_date(tobj)

    def make_live_task(self, tobj):
        """Set the name or search key for the movie.

        """
        if self.gui.movie_rdo.isChecked():
            title = unicode(self.gui.mov_name_led.text())

            if self.video is None:
                self.video = self.get_video_live(title)

            if self.video is None:
                del tobj
                self.gui.on_unvalid_movie_name()
                return

        elif self.gui.kword_rdo.isChecked():
            l = self.match_video_live()
            if l is None:
                del tobj
                self.gui.on_unvalid_keywords()
                return

            self.video = l[0]
            self.gui.mov_name_led.setText(self.video.title)

        tobj.movie = self.video.title
        tobj.filename = self.clean_title(self.video.title)
        qlt = self.gui.quality_cmb.currentIndex()

        if not qlt and self.video.HD is not None:
            tobj.stream = self.video.HD

        else:
            tobj.stream = self.video.SD
        tobj.streams = 'live'

        tobj.pitch = self.video.pitch
        tobj.type = 1
        self.set_task_date(tobj)
        print 'Stream:', tobj.stream

    def set_task_date(self, tobj):
        """Set date and time for download.

        """
        logger.info('Set datetime')
        if self.gui.day_rdo.isChecked():
            date = self.gui.date_spb.date()
            time = self.gui.time_spb.time()

            if not self.check_datetime(date, time):
                del tobj
                self.gui.on_invalid_datetime()
                return

            else:
                self.gui.warn_lbl.hide()

            if self.restricted:
                logger.info('Video is restricted (23:00 to 05:00)')
                if time.hour() < 23 and time.hour() > 5:
                    time = QtCore.QTime(23, 05, 0)
                    self.gui.time_spb.setTime(time)

            tobj.date = [date.day(), date.month(), date.year()]
            tobj.time = [time.hour(), time.minute()]
            tobj.dayofweek = None

        elif self.gui.week_rdo.isChecked():
            # Only for arte+7
            wd = self.gui.week_cmb.currentIndex()
            if wd == 7:
                # Each day of the week
                # Note: in crontab 0 = 7 = sunday
                tobj.dayofweek = '0-6'

            else:
                tobj.dayofweek = wd

            time = self.gui.time_spb_2.time()
            tobj.time = (time.hour(), time.minute())

        tobj.retry = (5, 0)

        if self.cfg["pitch_plus"]:
            tobj.save_pitch = 1
            if not self.cfg["pitch_plus_unique"]:
                tobj.save_pitch = 2

        self.create_task(tobj)
        self.gui.warn_lbl.setText("")

    def create_task(self, job):
        job.command = self.tsked.make_cron_job(job)

        if self.is_editing:
            self.gui.rename_create_button(True)
            self.is_editing = False
            self.get_current_index()
            self.gui.tasks_tree.update_task(job)

        else:
            self.tasks.append(job)
            self.save_tasks()
            self.gui.tasks_tree.set_single_task(job)
            self.cur_index += 1

        self.cur_desc = None
        self.tsked.cmd = None
        #self.print_task_properties(job)

    def print_task_properties(self, task):
        """Debug function"""
        for key, value in task.__dict__.iteritems():
            print "%s: %s" % (key, value)

    def get_video_plus(self, txt):
        for video in self.videos_plus:
            if video.title == txt:
                return video

        return None

    def get_video_plus_stream(self, video):
        """Seek for an arte+7 video with title and get his stream url.

        Args:
        txt -- movie's title

        Returns:
        stream url or None if not found
        """
        self.gui.warn_lbl.setText(u"Search stream link ...")
        QtCore.QCoreApplication.processEvents()
        lnk = self.main.apl.get_stream_link(video)
        self.gui.warn_lbl.setText("")
        return lnk

    def get_video_live(self, name):
        """Seek for an arteLiveWeb video with title and get his stream url.

        Args:
        name -- movie's title

        Returns:
        VideoItem instance
        """
        for video in self.videos_live:
            if video.title == name:
                return self.main.alw.get_stream_properties(video)

        return None

    def match_video_live(self):
        """Seek for an arteLiveWeb video with keywords and get his stream url.

        """       
        keys = unicode(self.gui.kword_led.text()).split()
        movies = []
        for video in self.videos_live:
            title = video.title.lower()
            movies.append(video)

            for key in keys:
                if key.lower() not in title:
                    movies.pop(-1)
                    break

        if not movies:
            return None

        return self.main.alw.get_stream_properties(movies[0])

    def get_temp_filename(self):
        d = str(time.time()).replace(".", "")
        t = "".join(["plus", d, ".flv"])
        count = 1

        while 1:
            target = os.path.join(self.cfg['plus_folder'], t)
            if os.path.isfile(target):
                t = "".join(["plus", d, str(count), ".flv"])
                count += 1

            else:
                break

        return t

    def get_filename(self, task):
        name = self.clean_title(task.title)
        return "".join([name, '-', task.date, '.flv'])

    def clean_title(self, name):
        for c in [u'»', u'«', u'/', u'\\', u'"']:
            name = name.replace(c, "_")

        return name

    def edit_task(self, idx):
        """Configure download for an existing task.

        Args:
        idx -- task's index
        """
        task = False
        for tsk in self.tasks:
            if tsk.ID == idx:
                task = tsk
                break

        if not task:
            logger.warning('edit_task unknow task <{0}>'.format(idx))
            return

        self.cur_index = idx
        self.is_editing = True
        self.edited_task = task

        if task.site == 'plus':
            self.edit_plus_item(task)

        else:
            self.edit_live_item(task)

        self.tsked.remove_task(task)
        self.gui.rename_create_button(False)

    def edit_plus_item(self, task):
        self.gui.plus_rdo.setChecked(True)

        if task.type == 1:
            self.gui.movie_rdo.setChecked(True)
            self.gui.mov_name_led.setText(task.movie)

        elif task.type == 2:
            self.gui.serial_rdo.setChecked(True)
            self.gui.serial_cmb.setCurrentIndex(
                            self.gui.serial_cmb.findText(task.serial))

        else:
            self.gui.keyword_rdo.setChecked(True)
            self.gui.keyword_led.setText(task.keyword)

        self.edit_date(task)

    def edit_live_item(self, task):
        self.gui.live_rdo.setChecked(True)
        self.gui.mov_name_rdo.setChecked(True)
        self.gui.mov_name_lbl.setText(task.movie)
        self.edit_date(task)

    def edit_date(self, job):
        if job.dayofweek is None:
            date = QtCore.QDate(job.date[2], job.date[1], job.date[0])
            self.gui.date_spb.setDate(date)

        else:
            if job.dayofweek == '0-6':
                self.week.cmb.setCurrentIndex(7)

            else:
                self.week.cmb.setCurrentIndex(int(job.dayofweek))

        time = QtCore.QTime(job.time[0], job.time[1], 0)
        self.gui.time_spb.setTime(time)
        self.gui.time_spb_2.setTime(time)

    def set_log_editor(self):
        try:
            mb = self.cfg['mailbox']
        except KeyError:
            self.cfg['mailbox'] = self.utils.set_default_crontab_mailbox()
            self.main.save_config()

        self.tasks_log = self.cfg['mailbox']
        self.gui.log_editor.set_log_filename(self.tasks_log)
        self.gui.log_editor.load_log()

    def load_tasks(self):
        orders = []
        try:
            with open(self.tasks_file, 'r') as tskf:
                jobs = pickle.load(tskf)

                for job in jobs:
                    self.tasks.append(TaskObject(None, job))

        except Exception as why:
            self.tasks = []

        if len(self.tasks):
            self.clean_tasks()

        self.get_current_index()
        self.save_tasks()

    def save_tasks(self):
        jobs = []
        for task in self.tasks:
            jobs.append(task.__dict__)

        try:
            with open(self.tasks_file, 'w') as tskf:
                pickle.dump(jobs, tskf)
        except Exception as why:
            self.main.show_warning(self.tasks_file, why)

    def create_summary(self, video):
        text = video.summary
        if not text or text is None:
            text = video.pitch

        return "".join([video.title, "  ", video.orig, "\n", video.date,
                        "\n\n", text])

    def get_formated_time(self):
        return time.strftime('%a, %d %b %Y %H:%M:%S', time.localtime())

    def check_datetime(self, d, t):
        """Check if date and time of cron are not too short.

        Args:
        d -- QDate
        t -- QTime

        Returns:
        False if datetime is too short, True otherwise
        """
        now = datetime.now()
        dt = datetime(d.year(), d.month(), d.day(), t.hour(), t.minute(), 0)
        if now >= dt:
            return False

        return True

    def check_retricted_time(self, time):
        """Check if time of cron is in range 23:00-05:00.

        Args:
        time --QTime

        Returns:
        False if time is non valid
        """
        if time.hour() < 23 or time.hour() > 5:
            return False

        return True

    def clean_tasks(self):
        unvalids = []
        for task in self.tasks:
            if task.dayofweek is None:
                date = self.get_qdate(task.date)
                time = self.get_qtime(task.time)

                if not self.check_datetime(date, time):
                    unvalids.append(task)

        for unv in unvalids:
            self.tasks.remove(unv)
            self.tsked.remove_task(unv)

    def delete_tasks(self, idx):
        """Remove a task, called by 'Delete' button.

        Args:
        idx -- task's index
        """
        for task in self.tasks:
            if task.ID == idx:
                break

        self.tasks.remove(task)
        self.tsked.remove_task(task)
        self.save_tasks()

    def get_qdate(self, date):
        return QtCore.QDate(date[2], date[1], date[0])

    def get_qtime(self, time):
        return QtCore.QTime(time[0], time[1], 0)

    def get_current_index(self):
        """Return the next index for a new task.

        """ 
        orders = []
        for task in self.tasks:
            orders.append(task.ID)
            self.cur_index = max(orders) + 1

    def get_user(self):
        """Return user name.

        """
        return pwd.getpwuid(os.getuid())[0]

class TaskEditor(object):
    def __init__(self, main):
        # http://www.math-linux.com/spip.php?article16
        dct = dict(user = None,
                    main = main,
                    task = [],
                    tab = None,
                    current_cron = None,
                    cmd = None)
        for key, value in dct.iteritems():
            setattr(self, key, value)

        self.user = self.get_user()
        self.set_crontab()

    def get_command(self):
        """Create the command for crontab.

        """
        lng, cod = locale.getdefaultlocale()
        lang = ".".join([lng, cod.lower()])
        root = os.path.join('/usr/bin/qarte')
        return self.main.cfg['crontab_cmd'].replace('<lang>', lang)\
                                    .replace('<root>', root)\
                                    .replace('<ID>', str(self.current_cron))

    def set_crontab(self):
        self.tab = CronTab()

    def set_current(self, idx):
        self.current_cron = idx

    def make_cron_job(self, job):
        self.current_cron = job.ID

        if self.cmd is None: 
            self.cmd = self.get_command()

        self.cron = self.tab.new(command=self.cmd)

        if job.date is not None:
            self.cron.dom().on(job.date[0])
            self.cron.month().on(job.date[1])
            self.cron.hour().on(job.time[0])
            self.cron.minute().on(job.time[1])

        elif job.dayofweek is not None:
            self.cron.dow().on(job.dayofweek)
            self.cron.hour().on(job.time[0])
            self.cron.minute().on(job.time[1])

        else:
            return

        self._write()
        # Command is returned for the task creation.
        # When this program is running as daemon (cron), 
        # locale.getdefaultlocale() returns (None, None)
        return self.cmd

    def get_user(self):
        user = pwd.getpwuid(os.getuid())[0]
        return user

    def list_tasks(self):
        """Debugging function"""
        for task in self.tab:
            print task

    def remove_task(self, task):
        """Remove obsolete task from crontab.

        Args:
        task -- TaskObject instance
        """
        t = " ".join(['-a', str(task.ID)])
        items = self.tab.find_command(t)

        for item in items:
            self.tab.remove(item)

        self._write()

    def _write(self):
        def write(*args):
            self.tab.write()

        # To avoid an 'error: (4, 'System call interrupted')' the crontab
        # must be created in separate process
        Thread(target=write, args=(None,)).start()

class TaskObject(object):
    def __init__(self, idx, dct=None):
        if dct is None:
            dct = {'ID': idx,
                    'type': None,
                    'tasks': [],
                    'site': 'plus',
                    'date': None,
                    'time': None,
                    'dayofweek': None,
                    'single': 1,
                    'retry': (5, 0),
                    'notify': 0,
                    'mailto': 0,
                    'mail': '',
                    'keyword': u'',
                    'serial': u'',
                    'movie': '',
                    'moviedate': '',
                    'filename': '',
                    'title': '',
                    'stream': '',
                    'streams': '',
                    'subtitles': False,
                    'save_pitch': 0,
                    'pitch': '',
                    'command': None}
        for key, value in dct.iteritems():
            setattr(self, key, value)
