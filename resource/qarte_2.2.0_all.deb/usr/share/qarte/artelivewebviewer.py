# -*- encoding: utf-8 -*-

# artelivewebviewer.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2011-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Graphics view for 'Live' and 'Extra' pages

import os
import gettext
import logging
logger = logging.getLogger(__name__)

from PyQt4 import QtCore, QtGui

from themes import Themes



class ArteLiveWebViewer(QtGui.QGraphicsView):
    def __init__(self, ui, parent=None):
        super(ArteLiveWebViewer, self).__init__(parent)
        self.setMinimumSize(QtCore.QSize(0, 250))
        self.setMaximumSize(QtCore.QSize(16777215, 270))
        self.setDragMode(QtGui.QGraphicsView.ScrollHandDrag)
        self.setTransformationAnchor(QtGui.QGraphicsView.AnchorViewCenter)
        self.setStyleSheet("""QGraphicsView {color: white;
                            background: qlineargradient(
                            x1: 0, y1: 0, x2: 0, y2: 1,
                            stop: 0 #FFFFFF,
                            stop: 0.4 #606060, stop: 0.5 #101010,
                            stop: 1 #000000)}""")
        self.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)

        self.ui = ui
        self.al = None
        self.prev_fld = None
        self.cfg = None
        self.videos_items = None
        self.to_download = []
        self.news = []

    def show_category(self, videos):
        """Shows preview items in the viewer area.

        """
        self.images = []
        self.videos_items = ([videos[idx] for idx in sorted(videos.keys())])
        self.videos_items.reverse()

        for idx, vid in enumerate(self.videos_items):
            is_preview = vid.preview

            if vid.preview is not None:
                img = os.path.join(self.prev_fld, vid.preview)

                if not os.path.isfile(img):
                    pict = self.videos_items[idx].get_image()

                    if pict is not None:
                        try:
                            with open(img, 'w') as outf:
                                outf.write(pict)
                        except Exception, why:
                            vid.preview = None

                    else:
                        vid.preview = None

            if vid.preview is None:
                img = os.path.join("medias", "noPreview.png")

            self.images.append(img)

        self.prepare_scene()
        self.populate_scene()

    def prepare_scene(self):
        """Create the QGraphicsScene.

        """
        mg = 20 # margin
        sp = 10 # spacing
        nb = len(self.images)
        lng = mg + ((nb - 1) * (self.cfg['mini'] + 10)) + self.cfg['maxi'] + mg
        # TODO Scene height must be in config

        try:
            self.scene.clear()
        except:
            self.scene = QtGui.QGraphicsScene()

        self.scene.setSceneRect(0.0, 0.0, float(lng), self.height()-5)
        self.setScene(self.scene)

    def populate_scene(self):
        """Create and set thumbnails into the scene.

        """
        if not self.videos_items:
            logger.warning(u"No such videos found")
            return

        posX, posY = 20, 0
        self.previews = []
        new = False
        self.current = 0

        if self.videos_items[0].soon:
            new = -1

        elif self.videos_items[0].order in self.news:
            new = True

        item = PreviewItem(self, self.images[0], 0,
                            self.videos_items[0].title, new,
                            self.cfg['maxi'], None, self.scene)
        y = (self.scene.height() - item.height_) / 2
        item.setPos(posX, y)
        self.al.show_pitch(self.videos_items[0])
        QtCore.QCoreApplication.processEvents()
        self.previews.append(item)
        posX += self.cfg['maxi'] + 10
        posY += 40

        for idx, img in enumerate(self.images):
            if idx:
                new = False

                if self.videos_items[idx].soon:
                    new = -1

                elif self.videos_items[idx].order in self.news:
                    new = True

                item = PreviewItem(self, self.images[idx], 
                                    idx,
                                    self.videos_items[idx].title, new,
                                    self.cfg['mini'], None, self.scene)
                item.setPos(posX, posY)
                QtCore.QCoreApplication.processEvents()
                self.previews.append(item)
                posX += self.cfg['mini'] + 10
                QtCore.QCoreApplication.processEvents()

        self.center_item()

    def shift_to_next(self):
        """Move one step to the right.

        """
        nb = len(self.images) - 1
        self.minimise_current()
        self.current = self.current + (1 if self.current < nb else -nb)
        self.maximise_current()

        if self.current:
            self.previews[self.current].moveBy(self.cfg['mini'] - 
                                                self.cfg['maxi'], 0)

        else:
            # If we're come back to the first image, we need to move
            # all others pixmap to the right
            for p in self.previews[1:]:
                p.moveBy(self.cfg['maxi'] - self.cfg['mini'], 0)

        self.center_item()

    def shift_to_previous(self):
        """Move one step to the left.

        """
        nb = len(self.images) - 1
        self.minimise_current()
        self.previews[self.current].moveBy(self.cfg['maxi'] - 
                                            self.cfg['mini'], 0)

        if not self.current:
            for p in self.previews:
                p.moveBy(self.cfg['mini'] - self.cfg['maxi'], 0)
            
        self.current = self.current - (1 if self.current > 0 else -nb)
        self.maximise_current()
        self.center_item()

    def go_to_item(self, idx):
        """Move to item idx.

        Called when an item has been clicked.

        Args:
        idx -- index of item
        """
        if idx == self.current:
            return

        delta = self.cfg['maxi'] - self.cfg['mini']
        self.minimise_current()

        if idx > self.current:
            for i in range(self.current, idx):
                self.previews[i + 1].moveBy(-delta, 0)

        else:
            for i in range(idx, self.current):
                self.previews[i + 1].moveBy(delta, 0)

        self.current = idx
        self.maximise_current()
        self.center_item()

    def on_item_selected(self, idx):
        """Check if selection mode is interactiv with differed download
        dialog.

        Args:
        idx -- item's index
        """
        if self.al.main.is_interact_with_dialog:
            self.al.main.send_item_to_download_later(self.videos_items[idx])

    def minimise_current(self):
        """Reduce the size of a preview item.

        """
        pos = self.previews[self.current].pos()
        new = self.previews[self.current].new
        self.scene.removeItem(self.previews.pop(self.current))
        item = PreviewItem(self, self.images[self.current],
                            self.current,
                            self.videos_items[self.current].title, 
                            new, self.cfg['mini'], None, self.scene)
        item.setPos(pos.x(), 40)
        self.previews.insert(self.current, item)

    def maximise_current(self):
        """Enlarge the size of a preview item.

        """
        pos = self.previews[self.current].pos()
        new = self.previews[self.current].new
        self.scene.removeItem(self.previews.pop(self.current))
        item = PreviewItem(self, self.images[self.current],
                            self.current,
                            self.videos_items[self.current].title,
                            new, self.cfg['maxi'],  None, self.scene)
        y = (self.scene.height() - item.height_) / 2
        item.setPos(pos.x(), y)
        self.previews.insert(self.current, item)
        self.al.show_pitch(self.videos_items[self.current])

    def center_item(self):
        """Move the current preview item at the center of the viewer area.

        """
        self.centerOn(self.previews[self.current])
        self.al.on_thumbnail_selected(self.videos_items[self.current])
        # Check if video is already in the downloading basket
        #self.ui.select_btn.setEnabled(not self.videos_items[self.current]
                                        #in self.to_download)
        # and if already available
        #self.ui.select_btn.setEnabled(not self.videos_items[self.current].soon)


class PreviewItem(QtGui.QGraphicsPixmapItem):
    def __init__(self, main, img, idx, title, new, width, 
                    parent=None, scene=None):
        super(PreviewItem, self).__init__(parent, scene)
        self.main = main
        self.img = img
        self.idx = idx
        self.title = title
        self.width_ = width
        self.height_ = 0
        self.pix = None
        self.new = new
        self.font = QtGui.QFont()
        self.font.setFamily("Verdana")
        self.font.setPointSize(10)
        self.font.setItalic(True)
        self.font_1 = QtGui.QFont()
        self.font_1.setFamily("Verdana")
        self.font_1.setPointSize(20)
        self.font_1.setWeight(55)
        self.font_1.setItalic(True)
        self.is_double_clicked = False

        self.format_title()
        self.__set_image()
        self.__set_frame()

        if new:
            self.__set_label_new()

        self.setPixmap(self.pix)

    def __set_image(self):
        self.base = QtGui.QImage(self.img).scaledToWidth(self.width_, 
                                QtCore.Qt.SmoothTransformation)

        if self.title is None:
            self.height_ = self.base.height()

        else:
            self.height_ = self.base.height() + (20 * len(self.title))

    def __set_frame(self):
        self.pix = self.__set_pix()
        rect = QtCore.QRectF(0.0, 0.0, self.width_, self.base.height())
        painter = QtGui.QPainter()
        painter.begin(self.pix)
        painter.setRenderHints(QtGui.QPainter.Antialiasing, True)
        self.path = QtGui.QPainterPath()
        self.path.addRoundedRect(rect, 6.0, 6.0)
        painter.drawPath(self.path)
        painter.end()
        self.__fill_path()

    def __fill_path(self):
        """Draw the texture into the shape.

        """
        painter = QtGui.QPainter()
        painter.begin(self.pix)
        painter.setRenderHints(QtGui.QPainter.Antialiasing, True)
        brush = QtGui.QBrush()
        brush.setTexture(self.__set_texture())     
        painter.fillPath(self.path, brush)
        painter.end()

        if self.title is not None:
            self.write_title()

    def __set_texture(self):
        texture = QtGui.QPixmap(QtCore.QSize(self.width_, self.base.height()))
        irect = QtCore.QRect(0, 0, self.width_, self.base.height())
        prect = QtCore.QRect(0, 0, self.width_, self.base.height())
        painter = QtGui.QPainter()
        painter.begin(texture)
        painter.drawImage(prect, self.base, irect)
        painter.end()

        return texture

    def __set_pix(self):
        """Create the pixmap support for the texture.

        Returns:
        QPixmap square filled transparent
        """
        color = QtGui.QColor()
        color.setRgb(0, 0, 0, 0)
        pix = QtGui.QPixmap(QtCore.QSize(self.width_, self.height_))
        pix.fill(color)

        return pix

    def format_title(self):
        if self.title is None:
            self.title = "No Title"
        title = Title(self)
        lines = title.partition_text()

        if lines is None:
            self.title = ["No Title"]

        else:
            self.title = lines

    def write_title(self):
        y = self.base.height() + 15
        painter = QtGui.QPainter()
        painter.begin(self.pix)
        painter.setPen(QtGui.QPen(QtCore.Qt.white, 2,
                                  QtCore.Qt.SolidLine, QtCore.Qt.RoundCap,
                                  QtCore.Qt.MiterJoin))
        painter.setFont(self.font)

        for i in self.title:
            l = self.get_text_length(i)
            x = (self.width_ / 2) - (l / 2)
            painter.drawText(x, y, i)
            y += 15

        painter.end()

    def __set_label_new(self):
        if self.new == -1:
            label = "Soon"
            x = self.width_ - 90

        else:
            label = "New"
            x = self.width_ - 70

        y = self.base.height()
        painter = QtGui.QPainter()
        painter.begin(self.pix)
        painter.setPen(QtGui.QPen(QtCore.Qt.red, 2,
                                  QtCore.Qt.SolidLine, QtCore.Qt.RoundCap,
                                  QtCore.Qt.MiterJoin))
        painter.setFont(self.font_1)
        painter.drawText(x, y, label)
        painter.end()

    def get_text_length(self, t):
        """Get string's lenght with the help of font metrics.

        Keyword arguments:
        t -- text
        
        Returns:
        lenght of text
        """
        metric = QtGui.QFontMetrics(self.font)
        return metric.width(t)

    def mousePressEvent(self, event):
        if event.button() == 1:
            timer = QtCore.QTimer()
            timer.singleShot(300, self.on_item_clicked)
            timer.start()

    def mouseDoubleClickEvent(self, event):
        self.is_double_clicked = True

        if self.new != -1:
            self.main.al.select_video_to_download(self.idx)

    def on_item_clicked(self):
        if not self.is_double_clicked:
            self.main.go_to_item(self.idx)
            self.main.on_item_selected(self.idx)

        self.is_double_clicked = False

    def contextMenuEvent(self, event):
        self.__show_menu(event.screenPos())
        event.accept()

    def __show_menu(self, pos):
        """Build and show context menu.

        Keyword arguments:
        pos -- event.pos()
        """
        self.menu = QtGui.QMenu()
        self.act_add = QtGui.QAction(self.menu)
        self.act_add.setText(_("Add to download list"))
        self.menu.addAction(self.act_add)
        self.act_diff = QtGui.QAction(self.menu)
        self.act_diff.setText(_("Differed download"))
        self.menu.addAction(self.act_diff)
        self.act_add.triggered.connect(self.add_to_download)
        self.act_diff.triggered.connect(self.set_cron_job)

        if self.new == -1:
            self.act_add.setEnabled(False)

        self.menu.setStyleSheet(self.main.ui.menu_style)
        self.menu.popup(pos)

    def add_to_download(self):
        self.main.al.select_video_to_download(self.idx)

    def set_cron_job(self):
        self.main.al.download_later(self.idx)

class Title(QtGui.QGraphicsTextItem):
    def __init__(self, pix, parent=None):
        super(Title, self).__init__(parent)
        self.pix = pix
        self.text_ = pix.title
        self.font = pix.font
        self.width_ = pix.width_ - 20

    def get_text_length(self, t):
        """Get string's lenght with the help of QFontMetrics.

        Keyword arguments:
        t -- text
        
        Returns:
        lenght of text
        """
        metric = QtGui.QFontMetrics(self.font)
        return metric.width(t)

    def partition_text(self):
        """Divide the title in a list of lines.

        Returns:
        list of lines
        """
        def adjust_length(ch):
            while self.get_text_length(ch) >= self.width_:
                ch = ch[:-1]

            return len(ch)

        mtc = self.get_text_length(self.text_)

        if mtc <= self.width_:
            return [self.text_]

        parts = []
        begin = 0
        lc = int(len(self.text_) / (mtc / self.width_))
        chain = self.text_[:lc] 

        while 1:
            end = adjust_length(chain)

            if not self.text_[end] in [" ", "-", "_"]:
                part = self.find_caesura(chain[:end])

            else:
                part = chain[:end]

            parts.append(part)
            self.text_ = self.text_.replace(part, "").lstrip()

            if len(self.text_) >= lc:
                chain = self.text_[:lc]

            else:
                parts.append(self.text_)
                break

        return parts

    def find_caesura(self, chain):
        """Find the appropriate caesura of a string.

        Args:
        chain -- part of video's title (one line)

        Returns:
        Formated text
        """
        count = len(chain) - 1

        while count > 0:
            if chain[count] in [" ", "-", "_"]:
                break
            count -= 1

        if count:
            return chain[:count]

        return chain

    def str_to_unicode(self, obj, encoding='utf-8'):
        if isinstance(obj, basestring):
            if not isinstance(obj, unicode):
                obj = unicode(obj, encoding)
            return obj

        else:
            return False
