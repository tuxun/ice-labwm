# -*- coding: utf-8 -*-

# themes.py
# This file is part of Qarte
#
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2011-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Set of style sheets


from PyQt4 import QtCore, QtGui

class Themes(object):
    def __init__(self, ui):
        self.ui = ui

    def set_theme_dark(self):
        # Common style for QWidget
        self.baseWidget_style = """
                QWidget {background: #404040;
                    color: #FFFFFF;}"""

        # Setting dialog box
        self.settingDialog_style = """
                QWidget {background: #EAEAEA;
                    color: #000000;}"""

        # viewer arte+7
        self.viewerPlus_style = """
                QListView {color: white;
                    background: qlineargradient(
                    x1: 0, y1: 0, x2: 1, y2: 1,
                    stop: 0 #B4B4B4, stop: 1 #000000);
                    border: 2px solid #9C9C9C;
                    border-radius: 6px;}
                QListView::item:hover 
                    {border: 2px solid #9900BB;}"""

        # QListWidget
        self.listView_style = """
                QListView {color: white;
                    background: qlineargradient(
                    x1: 0, y1: 0, x2: 1, y2: 1,
                    stop: 0 #B4B4B4, stop: 1 #000000);
                    color: solid #000000;
                    border: 2px solid #9C9C9C;
                    border-radius: 6px;}
                QListView::item:hover 
                    {border: 2px solid #9900BB;}"""

        # QGraphicsView
        self.viewer_style = """
                QGraphicsView {color: white;
                    background: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #FFFFFF,
                    stop: 0.4 #606060, stop: 0.5 #101010,
                    stop: 1 #000000)}"""

        # Widget bar for buttons
        self.buttonsBar_style = """
                QWidget {background: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #000000, stop: 0.3 #909090, 
                    stop:0.4 #FFFFFF stop:0.6 #202030,
                    stop: 1.0 #000000);}"""

        # QLabel
        self.label_style = """
                QLabel {color: #000000;}"""

        # QLineEdit
        self.lineEdit_style = """
                QLineEdit {border: 2px solid #A0A5B2;
                    border-radius: 6px;
                    background: white;
                    color: black;
                    selection-background-color: darkgray;}"""

        # QComboBox
        self.comboBox_style = """
                QComboBox {border: 2px solid #A0A5B2;
                    border-radius: 6px;
                    background: #FFFFFF;
                    color: #000000;
                    selection-color: #0000FF;
                    selection-background-color: #E8E8F8;}
                QComboBox::drop-down {background: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #FFFFFF, stop: 0.4 #DDDDDD, stop: 0.8 #AAAAAA,
                    stop: 1.0 #999999);
                    border-top: 1px solid #666666;
                    border-right: 1px solid #444444;
                    border-bottom: 1px solid #333333;
                    border-top-right-radius: 4px;
                    border-bottom-right-radius: 4px;}
                QComboBox::down-arrow {image: url(medias/combo_spin.png);}
                QComboBox QAbstractItemView {background-color: #F4F4F4;
                    border: 2px solid #000000;
                    color: #000000;
                    border-radius: 6px;}"""

        # QCheckBox
        self.checkBox_style = """
                QCheckBox {color: #000000;}
                QCheckBox::indicator {
                    width: 20px;
                    height: 20px;}
                QCheckBox::indicator:unchecked {
                    image: url(medias/box_unchecked.png);}
                QCheckBox::indicator:unchecked:hover {
                    image: url(medias/box_unchecked_hover.png);}
                QCheckBox::indicator:checked {
                    image: url(medias/box_checked.png);}
                QCheckBox::indicator:checked:hover {
                    image: url(medias/box_checked_hover.png);}"""

        # QToolButton
        self.toolButton_style = """
                QToolButton {background-color: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #101010, stop: 0.4 #606060,
                    stop: 0.5 #050505, stop: 1.0 #000000);
                    border-radius: 4px;
                    padding: 2px;
                    color: #FFFFFF;}
                QToolButton:hover {border: 2px solid #CC1D00;}
                QToolButton:pressed {background-color: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #000000, stop: 0.4 #050505,
                    stop: 0.5 #606060, stop: 1.0 #101010);}"""

        # QPushButton
        self.pushButton_style = """
                QPushButton {background-color: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #FFFFFF, stop: 0.3 #DDDDDD, stop: 0.5 #BBBBBB,
                    stop: 0.7 #DDDDDD, stop: 1.0 #FFFFFF);
                    border-top: 2px solid #FFFFFF;
                    border-right: 2px solid #A0A5B2;
                    border-bottom: 2px solid #A0A5B2;
                    border-left: 2px solid #FFFFFF;
                    border-radius: 6px;
                    padding: 6px;
                    color: #000000;}
                QPushButton:hover {border: 2px solid #CC1D00;}
                QPushButton:pressed {background-color: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #000000, stop: 0.4 #050505,
                    stop: 0.5 #606060, stop: 1.0 #101010);}"""
        # Note: border-top-color don't works, use border-top

        self.categoryButton_style = """
               QPushButton:checked {border: 2px solid #000000;}"""

        # QRadioButton
        self.radioButton_style = """
                QRadioButton::indicator {
                    width: 20px;
                    height: 20px;}
                QRadioButton::indicator:unchecked {
                    image: url(medias/box_unchecked.png);}
                QRadioButton::indicator:unchecked:hover {
                    image: url(medias/box_unchecked_hover.png);}
                QRadioButton::indicator:checked {
                    image: url(medias/box_checked.png);}
                QRadioButton::indicator:checked:hover {
                    image: url(medias/box_checked_hover.png);}"""

        # QPlainTextEdit
        self.plainTextEdit_style = """
                QPlainTextEdit {background-color: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #FFFFFF, stop: 1.0 #EFEFEF);
                    color: #000000;
                    border: 2px solid #888A85;
                    border-radius: 6px;}"""

        # QScrollBar (vertical)
        self.scrollBar_V_style = """
                 QScrollBar:vertical {border: 2px solid #9C9C9C;
                    border-radius: 6px;
                    background: solid #505460;
                    width: 16px;
                    margin: 0px 0px 40px 0;}
                QScrollBar::handle:vertical {
                    background: qlineargradient(
                    x1: 0, y1: 1, x2: 1, y2: 1,
                    stop: 0 #FFFFFF, stop: 0.7 #304060,
                    stop: 1.0 #000000);
                    border: 1px solid #000000;
                    border-radius: 5px;
                    min-height: 20px;}
                QScrollBar::add-line:vertical {
                    background: qlineargradient(
                    x1: 0, y1: 1, x2: 1, y2: 1,
                    stop: 0 #FFFFFF, stop: 0.7 #304060,
                    stop: 1.0 #000000);
                    border-radius: 4px;
                    height: 16px;
                    subcontrol-position: bottom;
                    subcontrol-origin: margin;
                    border: 1px solid #9C9C9C;}
                QScrollBar::sub-line:vertical {
                    background: qlineargradient(
                    x1: 0, y1: 1, x2: 1, y2: 1,
                    stop: 0 #FFFFFF, stop: 0.7 #304060,
                    stop: 1.0 #000000);
                    border-radius: 4px;
                    height: 16px;
                    subcontrol-position: right bottom;
                    subcontrol-origin: margin;
                    border: 1px solid #9C9C9C;
                    position: absolute;
                    bottom: 20px;}
                QScrollBar:up-arrow:vertical {
                    image: url(medias/scroll_spinup.png);}
                QScrollBar::down-arrow:vertical {
                    image: url(medias/scroll_spindown.png);}
                QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                    background: none;}"""

        # QSlider
        self.slider_style = """
                QSlider::groove:horizontal {border: 2px solid #A0A5B2;
                    border-radius: 2px;
                    height: 10px;
                    background: #E8E8E8;}
                QSlider::handle:horizontal {background: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #FFFFFF, stop: 0.7 #304060,
                    stop: 1.0 #000000);
                    width: 20px;
                    border: 1px solid #000000;
                    border-radius: 2px;}"""

        # QLineEdit
        self.lineEdit_style = """
                QLineEdit {border: 2px solid #A0A5B2;
                    border-radius: 6px;
                    background: white;
                    color: black;
                    selection-background-color: darkgray;}"""

        # QLabel
        self.label_style = """
                QLabel {background: transparent;
                    color: #A0A0A0;}"""

        # QSpinBox
        self.spinBox_style = """
                QSpinBox {background: #FFFFFF;
                    border-radius: 6px;
                    border-top: 1px solid #FFFFFF;
                    border-left: 1px solid #EFEFEF;
                    border-right: 1px solid #EFEFEF;
                    border-bottom: 1px solid #A0A0A0;
                    border-radius: 4px;
                    color: #000508;}
                QSpinBox::up-button {subcontrol-origin: border;
                    subcontrol-position: top right;
                    width: 16px;
                    image: url(medias/spinup.png) 1;
                    border-top-right-radius: 5px;
                    border-top: 1px solid #666666;
                    border-right: 1px solid #444444;
                    border-bottom: none;}
                QSpinBox::down-button {subcontrol-origin: border;
                    subcontrol-position: bottom right;
                    width: 16px;
                    image: url(medias/spindown.png) 1;
                    border-bottom-right-radius: 5px;
                    border-top: none;
                    border-bottom: 1px solid #222222;
                    border-right: 1px solid #444444;}"""

        # QTimeEdit
        self.timeEdit_style = """
                QTimeEdit {background: #FFFFFF;
                    border-radius: 6px;
                    border-top: 1px solid #FFFFFF;
                    border-left: 1px solid #EFEFEF;
                    border-right: 1px solid #EFEFEF;
                    border-bottom: 1px solid #A0A0A0;
                    border-radius: 4px;
                    color: #000508;}
                QTimeEdit::up-button {subcontrol-origin: border;
                    subcontrol-position: top right;
                    width: 16px;
                    image: url(medias/spinup.png) 1;
                    border-top-right-radius: 5px;
                    border-top: 1px solid #666666;
                    border-right: 1px solid #444444;
                    border-bottom: none;}
                QTimeEdit::down-button {subcontrol-origin: border;
                    subcontrol-position: bottom right;
                    width: 16px;
                    image: url(medias/spindown.png) 1;
                    border-bottom-right-radius: 5px;
                    border-top: none;
                    border-bottom: 1px solid #222222;
                    border-right: 1px solid #444444;}"""

        # QDateEdit
        self.dateEdit_style = """
                QDateEdit {background: #FFFFFF;
                    border-radius: 6px;
                    border-top: 1px solid #FFFFFF;
                    border-left: 1px solid #EFEFEF;
                    border-right: 1px solid #EFEFEF;
                    border-bottom: 1px solid #A0A0A0;
                    border-radius: 4px;
                    color: #000508;}
                QDateEdit::drop-down {background: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #FFFFFF, stop: 0.4 #DDDDDD, stop: 0.8 #AAAAAA,
                    stop: 1.0 #999999);
                    border-top: 1px solid #666666;
                    border-right: 1px solid #444444;
                    border-bottom: 1px solid #333333;
                    border-top-right-radius: 4px;
                    border-bottom-right-radius: 4px;}
                QDateEdit::down-arrow {image: url(medias/combo_spin.png);}"""

        # arte+7 basket
        self.basketPlus_style = """
                QListWidget {alternate-background-color: #E9E9E9;
                    background: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #FFFFFF, stop: 1 #F0F0F0);
                    color: solid #000000;
                    border: 2px solid #9C9C9C;
                    border-radius: 6px;}"""

        # arteLiveWeb basket
        self.basketLive_style = """
                QTableView {alternate-background-color: #E9E9E9; 
                    background: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #FFFFFF, stop: 1 #F0F0F0);
                    color: solid #000000;
                    border: 2px solid #9C9C9C;
                    border-radius: 6px;}"""

        # Downloading buttons
        self.dwnlButton_style = """
                QPushButton:hover 
                    {border: 2px solid #9900FF;}"""

        # QStatusBar
        self.statusBar_style = """
                QStatusBar {background: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 0.4,
                    stop: 0 #CCCCCC, stop: 1 #000000);
                    color: white;}"""

        # Site buttons
        self.siteButton_style = """
                QPushButton {border-top: 2px solid #DDDDDD;
                    border-right: 2px solid #FFFFFF;
                    border-bottom: 2px solid #FFFFFF;
                    border-left: 2px solid #DDDDDD;
                    border-radius: 6px;
                    padding: 2px;
                    color: #FFAAFF;
                    background: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 0.4,
                    stop: 0 #CCCCCC, stop: 1 #000000);
                    color: white;}
                QPushButton:hover {border: 2px solid #CC1D00;}
                QPushButton:pressed {background-color: #EEEEEE;}"""
        # Note: border-top-color don't works, use border-top

        # Site buttons active state
        self.siteButtonActive_style = """
                QPushButton {border-top: 2px solid #0000DD;
                    border-right: 2px solid #0000FF;
                    border-bottom: 2px solid #0000FF;
                    border-left: 2px solid #0000DD;
                    border-radius: 6px;
                    padding: 2px;
                    color: #FFAAFF;
                    background: qlineargradient(
                    x1: 0, y1: 0, x2: 0, y2: 0.4,
                    stop: 0 #CCCCCC, stop: 1 #000000);
                    color: white;}
                QPushButton:hover {border: 2px solid #CC1D00;}
                QPushButton:pressed {background-color: #EEEEEE;}"""

        # QMenu, menuBar and context menu
        self.menu_style = """
                QMenu {background: transparent;
                    border: 2px solid #8A8E96;
                    border-radius: 8px;}
                QMenu::item {background: #FFFFFF;
                    padding: 2px 25px 2px 20px;
                    border: 1px solid transparent;}
                QMenu::item:selected {background-color: #E8E8F8;
                    border-color: #0F2D78;
                    border-radius: 4px;
                    color: #0F2D78;}
                QMenu::icon:checked {background: gray;
                    border: 1px inset gray;
                    position: absolute;
                    top: 1px;
                    right: 1px;
                    bottom: 1px;
                    left: 1px;}
                QMenu::separator {height: 2px;
                    background: #BABDD6;}"""


