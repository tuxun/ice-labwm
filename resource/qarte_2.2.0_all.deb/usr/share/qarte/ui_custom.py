# -*- coding: utf-8 -*-

# ui_custom.py
# This file is part of Qarte
#    
# Author : Vincent Vande Vyvre <vincent.vandevyvre@oqapy.eu>
# Copyright: 2012-2014 Vincent Vande Vyvre
# Licence: GPL3
# Home page : https://launchpad.net/qarte
#
# Dialog box for custom search of video

import os
import sys
import re
import urllib2
import time
import gettext
import logging
logger = logging.getLogger(__name__)

from PyQt4 import QtCore, QtGui

from parsers import ExtraParser, VideoItem
from themes import Themes

class CustomSearch(QtGui.QDialog):
    def __init__(self, main, parent=None):
        super(CustomSearch, self).__init__(parent)
        self.main = main # ArteLiveExtra instance
        self.ep = main.ep
        self.lang = main.lang
        self.resize(635, 325)
        self.setWindowTitle("Custom - ArteLiveWeb")
        self.gridLayout = QtGui.QGridLayout(self)
        self.gridLayout.setContentsMargins(4, 4, 4, -1)
        self.gridLayout.setObjectName("gridLayout")
        self.verticalLayout_3 = QtGui.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtGui.QLabel(self)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout_3.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.url_led = QtGui.QLineEdit(self)
        self.url_led.setObjectName("url_led")
        self.horizontalLayout_2.addWidget(self.url_led)
        self.search_btn = QtGui.QPushButton(self)
        self.search_btn.setText("O.K.")
        self.search_btn.setEnabled(False)
        self.search_btn.setObjectName("search_btn")
        self.horizontalLayout_2.addWidget(self.search_btn)
        self.verticalLayout_3.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_2 = QtGui.QLabel(self)
        self.label_2.setObjectName("label_2")
        self.horizontalLayout_3.addWidget(self.label_2)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem1)
        self.verticalLayout_3.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        spacerItem2 = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem2)
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_3 = QtGui.QLabel(self)
        self.label_3.setObjectName("label_3")
        self.verticalLayout.addWidget(self.label_3)
        self.label_4 = QtGui.QLabel(self)
        self.label_4.setObjectName("label_4")
        self.verticalLayout.addWidget(self.label_4)
        self.horizontalLayout_4.addLayout(self.verticalLayout)
        self.verticalLayout_3.addLayout(self.horizontalLayout_4)
        self.line = QtGui.QFrame(self)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName("line")
        self.verticalLayout_3.addWidget(self.line)
        self.horizontalLayout_8 = QtGui.QHBoxLayout()
        self.horizontalLayout_8.setObjectName("horizontalLayout_8")
        self.label_5 = QtGui.QLabel(self)
        self.label_5.setPixmap(QtGui.QPixmap("medias/noPreview_2.png"))
        self.label_5.setObjectName("label_5")
        self.horizontalLayout_8.addWidget(self.label_5)
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout_5 = QtGui.QHBoxLayout()
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.title_lbl = QtGui.QLabel(self)
        self.title_lbl.setObjectName("title_lbl")
        self.horizontalLayout_5.addWidget(self.title_lbl)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_5.addItem(spacerItem3)
        self.verticalLayout_2.addLayout(self.horizontalLayout_5)
        self.horizontalLayout_6 = QtGui.QHBoxLayout()
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.date_lbl = QtGui.QLabel(self)
        self.date_lbl.setObjectName("date_lbl")
        self.horizontalLayout_6.addWidget(self.date_lbl)
        spacerItem4 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_6.addItem(spacerItem4)
        self.verticalLayout_2.addLayout(self.horizontalLayout_6)
        self.horizontalLayout_7 = QtGui.QHBoxLayout()
        self.horizontalLayout_7.setObjectName("horizontalLayout_7")
        self.message_lbl = QtGui.QLabel(self)
        self.message_lbl.setObjectName("message_lbl")
        self.horizontalLayout_7.addWidget(self.message_lbl)
        spacerItem5 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_7.addItem(spacerItem5)
        self.verticalLayout_2.addLayout(self.horizontalLayout_7)
        self.horizontalLayout_8.addLayout(self.verticalLayout_2)
        self.verticalLayout_3.addLayout(self.horizontalLayout_8)
        spacerItem6 = QtGui.QSpacerItem(20, 18, QtGui.QSizePolicy.Minimum, 
                                        QtGui.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem6)
        self.horizontalLayout_9 = QtGui.QHBoxLayout()
        self.horizontalLayout_9.setObjectName("horizontalLayout_9")
        spacerItem7 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, 
                                        QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_9.addItem(spacerItem7)
        self.add_btn = QtGui.QPushButton(self)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("medias/apply.svg"), QtGui.QIcon.Normal, 
                                        QtGui.QIcon.Off)
        self.add_btn.setIcon(icon)
        self.add_btn.setEnabled(False)
        self.add_btn.setObjectName("add_btn")
        self.horizontalLayout_9.addWidget(self.add_btn)
        self.close_btn = QtGui.QPushButton(self)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("medias/close.png"), QtGui.QIcon.Normal, 
                                        QtGui.QIcon.Off)
        self.close_btn.setIcon(icon1)
        self.close_btn.setObjectName("close_btn")
        self.horizontalLayout_9.addWidget(self.close_btn)
        self.verticalLayout_3.addLayout(self.horizontalLayout_9)
        self.gridLayout.addLayout(self.verticalLayout_3, 0, 0, 1, 1)

        self.retranslateUi()
        self.set_style()
        QtCore.QMetaObject.connectSlotsByName(self)
        self.show()

        self.url_led.textChanged.connect(self.on_url_changed)
        self.search_btn.clicked.connect(self.search_video)
        self.add_btn.clicked.connect(self.add_video)
        self.close_btn.clicked.connect(self.accept)

    def on_url_changed(self, url):
        """Url has changed into lineEdit.

        Args:
        url -- QString
        """
        url = str(url)
        self.search_btn.setEnabled(url.startswith('http://') and len(url) > 20)

    def search_video(self):
        """Run the search process.

        Called by the button "O.K."
        """
        self.reset_widgets()
        url = str(self.url_led.text())
        logger.info('Search page: {0}'.format(url))
        idx = None
        page = None

        content = self.ep.get_page(url)
        if content[0] is not None:
            logger.info('Found page')
            page = content[0]

        else:
            logger.info('Page error: {0}'.format(content[1]))
            self.message_lbl.setText('Video not found.')
            return


        event = self.get_event(page)
        if event:
            prop = self.get_properties(event)
            for k, v in prop.items():
                logger.info('Property %s: %s' % (k, v))

            idx = prop['ID']

        if idx is None:
            logger.info('Unable to find the index of the video')
            self.message_lbl.setText('No such video found.')
            return

        self.video = prop
        self.set_thumbnail(prop['pict'])
        self.title_lbl.setText(prop['title'])
        self.date_lbl.setText(prop['date'])
        self.add_btn.setEnabled(True)

    def get_event(self, page):
        """Get the video description.

        Args:
        page -- html content

        Returns:
        Description or False if not found
        """
        EVENT = re.compile('(?<=<meta property=)(.*?/event/.*?/(.*?)-.*?>)', 
                                                                re.DOTALL)
        try:
            return EVENT.search(page).group(1)
        except Exception as why:
            logger.info('Event not found: {0}'.format(why))
            return False

    def get_properties(self, text):
        """Get the properties of the video.

        Args:
        text -- description if the video

        Returns:
        dict(properties)
        """
        prop = {'ID': None, 'title': None, 'date': 'Date:', 'pitch': '',
                 'link': None, 'pict': None, 'soon': False, 'author': ''}
        lines = text.split('<meta property="')

        for line in lines:
            if line.startswith('og:title'):
                tt = line.split('content="')[1].replace('" />', '')
                tt = tt.strip()
                prop['title'] = tt.decode('utf-8', 'replace')

            elif line.startswith('og:image'):
                prop['pict'] = line.split('content="')[1].replace('" />', '')
                prop['ID'] = self.get_index(prop['pict'])

            elif line.startswith('og:url'):
                lk = line.split('content="')[1].replace('" />', '')
                prop['link'] = lk.strip()

        return prop

    def get_index(self, text):
        IDX = re.compile("liveweb/media/event/.*?/(.*?)-.*?", re.DOTALL)
        try:
            return int(IDX.search(text).group(1))
        except Exception as why:
            logger.info('Index error: {0}'.format(why))
            return False

    def set_thumbnail(self, url):
        if url is None:
            return

        name = str(time.time()).replace('.', '')
        path = os.path.join(self.main.prev_fld, name)
        try:
            thmb = urllib2.urlopen(url).read()
        except IOError as why:
            logger.info('Loading image error: {0}'.format(why))
            return

        try:
            with open(path, 'wb') as outf:
                outf.write(thmb)
        except Exception as why:
            logger.warning('Writing image error: {0}'.format(why))
            return

        self.thumb = path
        self.label_5.setPixmap(QtGui.QPixmap(path))

    def reset_widgets(self):
        self.label_5.setPixmap(QtGui.QPixmap("medias/noPreview_2.png"))
        self.title_lbl.setText('')
        self.date_lbl.setText('')
        self.message_lbl.setText('')
        self.add_btn.setEnabled(False)

    def add_video(self):
        self.main.set_personal_video(self.video, self.thumb)
        self.message_lbl.setText('Video added to the downloding basket.')

    def retranslateUi(self):
        self.label.setText(_("Video URL:"))
        self.label_2.setText(_("Examples:"))
        self.label_3.setText("http://liveweb.arte.tv/fr/video/introducing_chairlift_berlin/")
        self.add_btn.setText(_("Add"))
        self.close_btn.setText(_("Close"))

    def set_style(self):
        theme = Themes(self)
        theme.set_theme_dark()
        self.url_led.setStyleSheet(theme.lineEdit_style)
        self.search_btn.setStyleSheet(theme.pushButton_style)
        self.add_btn.setStyleSheet(theme.pushButton_style)
        self.close_btn.setStyleSheet(theme.pushButton_style)
        self.label_3.setStyleSheet('QLabel {color: blue;}')
        self.message_lbl.setStyleSheet('QLabel {color: red;}')

class Main(object):
    """Devel tool"""
    def __init__(self):
        self.new_video = None
        self.lang = 'fr'
        self.partners = None
        self.ep = ExtraParser(self)
        self.cst = CustomSearch(self)

    def set_personal_video(self, item):
        for k, v in item.items():
            print k,v

        video = VideoItem('custom', item)
        print video.order
        print video.title
        print video.date
        print video.link
        print video.pitch
        print video.pix
        print video.author
        print video.soon


if __name__ == "__main__":
    app = QtGui.QApplication(sys.argv)
    mn = Main()
    sys.exit(app.exec_())

